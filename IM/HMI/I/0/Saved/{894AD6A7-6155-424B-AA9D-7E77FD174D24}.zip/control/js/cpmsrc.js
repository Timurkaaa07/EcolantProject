/* cpmtree 3.0.7 File version:   Copyright (C) Siemens AG 2022. All Rights Reserved. */
var CPM = ( CPM || {} );

CPM.svgUtil = ( function () {
    var
     _bBoxSvgTextHeighText = null,
     _bBoxSvgTextHeighTspan = null,
     _bBoxDivElement = null,
     _bBoxSvgElement = null,
     _svgNS = 'http://www.w3.org/2000/svg',
    _xmlNS = 'http://www.w3.org/XML/1998/namespace',
    _createSvgElement = function ( type, params ) {
        var p, value, element, postfix, url, mkId;

        params = params || {};

        postfix = params.postfix;
        url = params.url;
        mkId = params.mkId;

        delete params.postfix;
        delete params.url;
        delete params.mkId;

        // count the svg elements (only for development)
        //  _svgElemeCount += 1;


        element = document.createElementNS( _svgNS, type );
        for ( p in params ) {
            value = params[p];

            switch ( p ) {
                case 'textNode': element.appendChild( document.createTextNode( value ) );
                    break;
                case 'appendTo':
                    value.appendChild( element );
                    break;
                    //case 'id':
                    //    // idComposed = _composeId( item, value, postfix, url, mkId );
                    //    if (idComposed) {
                    //        element.setAttribute('id', idComposed);
                    //    }
                    //    break;
                case 'xml:space':
                    element.setAttributeNS( _xmlNS, p, value );
                    break;
                default: element.setAttribute( p, value );
            }
        }


        return element;
    },
    _createDomElement = function ( type, params ) {
        var p, value,
            element = document.createElement( type );

        for ( p in params ) {
            value = params[p];
            switch ( p ) {
                case 'textNode': element.appendChild( document.createTextNode( value ) );
                    break;
                case 'appendTo': value.appendChild( element );
                    break;
                default: element.setAttribute( p, value );
            }
        }
        return element;
    },
    _createBBoxItems = function ( domNode ) {

        _bBoxDivElement = _createDomElement( 'div', {
            id: 'ID_BBox_DIV',
            style: 'position:absolute; left:0px; top:0px; visibility:hidden;',
            appendTo: domNode
        } );

        _bBoxSvgElement = _createSvgElement( 'svg', {
            'xmlns:xlink': 'http://www.w3.org/1999/xlink',
            id: 'ID_BBox_SVG',
            style: 'pointer-events: none',
            width: '0px',
            height: '0px',
            appendTo: _bBoxDivElement
        } );

        // used to get the TextHeight of SVG elements
        _bBoxSvgTextHeighText = _createSvgElement( 'text', {
            'text-anchor': 'start',
            appendTo: _bBoxSvgElement
        } );

        _bBoxSvgTextHeighTspan = _createSvgElement( 'tspan', {
            appendTo: _bBoxSvgTextHeighText,
            dy: '40px'
        } );

        _bBoxSvgTextHeighTspan.textContent = 'XY';
    },
    _safeFontFamily = function ( fontname ) {
        if ( fontname === 'Arial' ) {
            return 'Arial, Helvetica, sans-serif';
        } else if ( fontname === 'Arial Black' ) {
            return 'Arial Black, Gadget, sans-serif';
        } else if ( fontname === 'Tahoma' ) {
            return 'Tahoma, Geneva, sans-serif';
        } else if ( fontname === 'Lucida Sans Unicode' ) {
            return 'Lucida Sans Unicode, Lucida Grande, sans-serif';
        } else if ( fontname === 'Trebuchet MS' ) {
            return 'Trebuchet MS, Helvetica, sans-serif';
        } else if ( fontname === 'Verdana' ) {
            return 'Verdana, Geneva, sans-serif';
        } else if ( fontname === 'Times New Roman' ) {
            return 'Times New Roman, Times, serif';
        } else if ( fontname === 'Georgia' ) {
            return 'Georgia, Utopia, Charter, serif';
        } else if ( fontname === 'Courier New' ) {
            return 'Courier New, Courier, monospace';
        } else {
            return fontname;
        }
    },
    _setDefaultbBox = function ( fontProps ) {
        var textDecoration,
        text = 'XY';
        _bBoxSvgTextHeighTspan.textContent = text;

        _bBoxSvgTextHeighText.setAttribute( 'font-size', fontProps.Size );
        _bBoxSvgTextHeighText.setAttribute( 'font-style', fontProps.Italic ? 'italic' : 'normal' );
        _bBoxSvgTextHeighText.setAttribute( 'font-weight', fontProps.Weight );
        _bBoxSvgTextHeighText.setAttribute( 'font-family', _safeFontFamily( fontProps.Name ) );

        if ( ( !fontProps.Underline ) && ( !fontProps.StrikeOut ) ) {
            textDecoration = 'none';
        } else {
            textDecoration = ( fontProps.Underline ? 'underline ' : '' ) + ( fontProps.StrikeOut ? 'line-through' : '' );
        }
        _bBoxSvgTextHeighText.setAttribute( 'text-decoration', textDecoration );
    },
    _getTextBBox = function ( fontProps, text ) {
        var bbox;
        if ( text ) {
            _bBoxSvgTextHeighTspan.textContent = text;
        }
        try {
            if ( fontProps.Size ) {
                _bBoxSvgTextHeighText.setAttribute( 'font-size', fontProps.Size );
            }
            if ( fontProps.Weight ) {
                _bBoxSvgTextHeighText.setAttribute( 'font-weight', fontProps.Weight );
            }
            if ( fontProps.Name ) {
                _bBoxSvgTextHeighText.setAttribute( 'font-family', _safeFontFamily( fontProps.Name ) );
            }
            bbox = _bBoxSvgTextHeighText.getBBox();
            //if (bbox.height === 0 && bbox.width !== 0) {
            //    bbox.width = 0; // fix bug in CHROM where space has a width of 45???
            //}
        }
        catch ( err ) {
            //lib.Debug.traceErr( err, 'SVG:getTextBBox() catched exception.' );
        }

        return bbox;
    },
    /*
    * returns offset mouse position Wrt Parent
    * @function
    * @memberOf SHC.Utils
    * @param {evt} Event
    * @param {parent} HTML Element
    * @param {isAdoptToScreen} screen scaling applied or not
    * @param {zoomFactorCB} function callback
    * @returns {point} object - object containing x and y 
    */
    _getMousePoint = function ( evt, parent, isAdoptToScreen, zoomFactorCB ) {
        var matrix = parent.getScreenCTM(),
        point = parent.createSVGPoint(),
        rectPosition = null,
        browserName = navigator.appName,
        target = null,
        zoomFactor = 1;
        if ( isAdoptToScreen && browserName.indexOf( 'Microsoft' ) === -1 ) {
            rectPosition = parent.getBoundingClientRect();
            matrix.e = rectPosition.left;
            matrix.f = rectPosition.top;
        }
        if ( typeof zoomFactorCB === 'function' ) {
            zoomFactor = zoomFactorCB();
        }
        if ( evt.clientX !== undefined && evt.clientX !== null && evt.clientY !== undefined && evt.clientY !== null ) {
            target = evt;
        }
        else if ( evt.changedPointers && evt.changedPointers.length > 0 ) {
            target = evt.changedPointers[0];
        }
        else {
            if ( evt.touches && evt.touches.length > 0 ) {
                target = evt.touches[0];
            }
        }
        if ( target ) {
            point.x = target.clientX;
            point.y = target.clientY;
            point = point.matrixTransform( matrix.inverse() );
            point.x = parseInt( point.x, 10 );
            point.y = parseInt( point.y, 10 );
            if ( isAdoptToScreen && browserName.indexOf( 'Microsoft' ) === -1 && zoomFactor !== 0 ) {
                point.x = point.x / zoomFactor;
                point.y = point.y / zoomFactor;
            }
        }
        return point;
    },
    /**
        * Set attribute of SVG Element.
        * @memberOf PWC.Lib.Canvas.Svg 
        * @param {Object} e Reference of svg element.
        */
    _setAttr = function ( e, a, v ) {
        if ( typeof a === 'object' ) {
            /* apply every attribute individually if an object is passed */
            for ( v in a ) {
                e.setAttribute( v, a[v] );
            }
        }
        else {
            /* set given attribute on node */
            e.setAttribute( a, v );
        }
    },
    _converterBlanks2Nbsps = function ( strValue ) {
        if ( !strValue ) {
            return '';
        }
        return strValue.replace( / /g, '\u00A0' );
    },
    /**
    * Helper for TextWidth for an text according to the font properties and the optional text.
    * If no text is given 'XY' will be used instead.
    * Needed fontProps: Size and Name.
    * Optional fontProps: Italic, Weight, Underline and StrikeOut (defaults: false).
    * @param {Object} fontProps The font properties of the item.
    * @param {String} text The text to check (optional).
    * @returns {Object} the bbox created
    */
    _getTextWidth = function ( fontProps, text ) {
        var canvas, ctx, ctxFont = ( fontProps.Italic ? 'italic ' : 'normal ' ) + fontProps['font-weight'] + ' ' + fontProps['font-size'] + 'px ' + fontProps['font-family'];

        // Initialize the canvas elements used for Converts: TextWidth and TextHeight.
        if ( !ctx ) {
            canvas = CPM.svgUtil.createDomElement( 'canvas', {
            } );
            ctx = canvas.getContext( '2d' );
        }

        text = ( text || 'XY' );
        //Exception handling in Debian Firefox
        try {
            ctx.font = ctxFont;
            return ctx.measureText( text ).width;
        } catch ( err ) {

        }
    },
    /**
    * Truncates a text if the length of the text is greater than its max length.
    * @function
    * @memberOf CPM.Common.HelperUtil
    * @param {strLabel} Text to be truncated.
    * @param {maxLimit} Max limit of the text.
    * @param {fontProps} Font properties of the text.
    */
    _truncateLabel = function ( strLabel, maxLimit, fontProps ) {
        var
        ellipsis = '...',
        dotsLen,
        tempString,
        index,
        maxChLength,
        avgChLength,
        maxLen,
        bBoxWidth;

        dotsLen = _getTextWidth( fontProps, ellipsis );
        tempString = strLabel;
        bBoxWidth = _getTextWidth( fontProps, tempString );
        if ( bBoxWidth > maxLimit ) {
            avgChLength = bBoxWidth / strLabel.length;
            maxLen = maxLimit - dotsLen;
            maxChLength = maxLen / avgChLength;
            tempString = strLabel.substring( 0, maxChLength );

            if ( bBoxWidth > maxLen ) {
                do {
                    tempString = tempString.substring( 0, tempString.length - 1 );
                    if ( tempString.length === 0 ) {
                        break;
                    }
                } while ( _getTextWidth( fontProps, tempString ) > maxLen );

                tempString += ellipsis;
            }
            else {
                if ( bBoxWidth < maxLen ) {
                    index = tempString.length + 1;
                    do {
                        tempString = strLabel.substring( 0, index );
                        index++;
                        if ( _getTextWidth( fontProps, tempString ) > maxLen ) {
                            tempString = tempString.substring( 0, tempString.length - 1 );
                            break;
                        }
                    } while ( _getTextWidth( fontProps, tempString ) < maxLen );
                    tempString += ellipsis;
                }
            }
        }
        fontProps = null;
        return tempString;
    },
     /**
    * Test if parent group exists or creates a new group
    * @function
    * @memberOf CPM.svgUtil
    * @param {parentNode} parent SVG element
    * @param {parentGroup} parent group to be appended
    * @returns {nodeValid} boolean depending on presence of parent
    */
    _testParent = function ( parentNode, parentGroup ) {
        //test if of type object
        var nodeValid = false;
        if ( typeof ( parentNode ) === 'object' && (parentNode.nodeName === 'svg' || parentNode.nodeName === 'g' || parentNode.nodeName === 'svg:svg' || parentNode.nodeName === 'svg:g' )) {
            parentNode.appendChild( parentGroup );
            nodeValid = true;
        }
        else {
            if ( typeof ( parentNode ) === 'string' ) {
                //first test if button group exists
                if ( !document.getElementById( parentNode ) ) {
                    parentGroup.setAttributeNS( null, 'id', parentNode );
                    document.documentElement.appendChild( parentGroup );
                    nodeValid = true;
                }
                else {
                    document.getElementById( parentNode ).appendChild( parentGroup );
                    nodeValid = true;
                }
            }
        }
        return nodeValid;
    };

    return {
        createBBoxItems: _createBBoxItems,
        getTextBBox: _getTextBBox,
        setDefaultbBox: _setDefaultbBox,
        createSVG: _createSvgElement,
        getMousePoint: _getMousePoint,
        setAttr: _setAttr,
        createDomElement: _createDomElement,
        converterBlanks2Nbsps: _converterBlanks2Nbsps,
        truncateLabel: _truncateLabel,
        getTextWidth: _getTextWidth,
        testParent: _testParent
    };

} )();
var CPM = ( CPM || {} );
CPM.Common = ( CPM.Common || {} );

CPM.Common.Tooltip = ( function ( lib ) {
    'use strict';

    // PRIVATE MEMBERS
    var

    /** 
    * Indicates whether the tooltip is suspended (e.g. during interaction) or not.
    * @memberOf PWC.Core.Tooltip 
    */
    _tooltipSuspended = false
    ,

    /** 
    * Indicates whether the 'tooltip suspend' is suspended (e.g. during interaction) or not.
    * @memberOf PWC.Core.Tooltip 
    */
    _tooltipSuspendSuspended = false
    ,

    _desktopLayout,
    /**
    * Hide the tooltip element.
    * @memberOf PWC.Core.Tooltip 
    */
    _hide = function () {
        var ttItems = _getTooltipItems(),
            divTooltip = ttItems.domDivTooltip;

        // tooltip will hide after timeout
        if ( _tooltipSuspendSuspended ) {
            //lib.Debug.consolLog( lib.Debug.enumTraceMode.Info, 'Tooltip.hide() suspend suspended' );
            return;
        }

        //lib.Debug.consolLog( lib.Debug.enumTraceMode.Info, 'Tooltip.hide() hide' );       

        divTooltip.style.visibility = 'hidden';
    },
    _getTooltipItems = function () {
        return _desktopLayout.tooltipItems;
    };

    // end of private stuff

    // PUBLIC MEMBERS
    return {

        /**
        * Create the DOM items for the tooltip support.
        * @memberOf PWC.Core.Tooltip 
        * @param {Object} desktopLayout Reference to the desktopLayout in the data tree.
        */
        createItems: function ( desktopLayout ) {
            var ttItems;
            _desktopLayout = desktopLayout;
            _desktopLayout.tooltipItems = {};
            ttItems = _desktopLayout.tooltipItems;

            ttItems.domDivTooltip = lib.createDomElement( 'div', {
                id: 'ID_Tooltip',
                style: 'pointer-events:none; position:absolute; visibility:hidden; height:auto; width:auto; background-color: white; border: 1px solid black; border-radius: 4px; z-index:65535;',
                appendTo: _desktopLayout.domNode
            } );
            lib.createDomElement( 'p', {
                style: 'color:black; margin: 1px 2px;',
                textNode: '',
                appendTo: ttItems.domDivTooltip
            } );
            ttItems.domDivTooltip.style['userSelect'] = 'none';
            //lib.HmiTypes.Utils.setPrefixedStyle( ttItems.domDivTooltip, 'userSelect', 'none' );
        }
        ,

        /**
        * Show the tooltip of the given item.
        * @memberOf PWC.Core.Tooltip 
        * @param {Object} item Reference to the item (screen item) in the data tree.
        * @param {Number} x X position for the tooltip.
        * @param {Number} y Y position for the tooltip.
        * @param {String} stateText State text to show as tooltip (optional).
        */
        show: function ( x, y, stateText ) {
            var itemTooltipText,
                ttItems = _getTooltipItems(),
                divTooltip = ttItems.domDivTooltip,
                rect, diffHori, diffVert;


            if ( _tooltipSuspended && stateText === undefined ) {
                return;
            }

            // Special handling of state text which is shown as tooltip.
            //if ( stateText ) {
            //    // If there is a timeout running, stop it!
            //    _tooltipSuspendSuspended = true;
            //    if ( _lastToolTipTimer !== null ) {
            //        clearTimeout( _lastToolTipTimer );
            //    }

            //    _lastToolTipTimer = setTimeout( function () {
            //        //lib.Debug.consolLog( lib.Debug.enumTraceMode.Info, 'Tooltip.hide() called by timer' );
            //        _tooltipSuspendSuspended = false;
            //        _lastToolTipTimer = null;
            //        _hide();
            //    }, 1000 );
            //}

            //lib.Debug.consolLog(lib.Debug.enumTraceMode.Info, 'Tooltip.show() x:' + x.toString() + ' y:' + y.toString());

            itemTooltipText = ( stateText ) ? stateText : '';
            //if ( lib.Settings.showDeveloperTooltip ) {
            //    if ( itemTooltipText !== '' ) {
            //        itemTooltipText += '   ';
            //    }
            //    itemTooltipText += '>>>item: ';
            //    itemTooltipText += use_Prop.getPropRaw( item, 'Name' ) || '';
            //    itemTooltipText += ' ' + item.rtoid;
            //}

            //lib.Debug.consolLog( lib.Debug.enumTraceMode.Info, 'Tooltip.show() : ' + ( ( itemTooltipText !== '' ) ? itemTooltipText : 'Empty tooltip will not be shown!!!' ) );
            if ( itemTooltipText !== '' ) {
                divTooltip.firstChild.textContent = lib.converterBlanks2Nbsps( itemTooltipText );

                divTooltip.style.left = ( x + 7 ) + 'px';
                divTooltip.style.top = ( y + 11 ) + 'px';
                divTooltip.style.visibility = 'visible';

                // Shift the div to be fully displayed  
                if ( divTooltip.getBoundingClientRect ) {
                    rect = divTooltip.getBoundingClientRect();

                    diffHori = ( rect.right >= document.documentElement.clientWidth ) ? document.documentElement.clientWidth - rect.right : 7;
                    diffHori = ( rect.left + diffHori > 0 ) ? diffHori : -rect.left + 7;
                    diffHori = ( rect.left <= 0 ) ? -rect.left : diffHori;
                    diffVert = ( rect.bottom >= document.documentElement.clientHeight ) ? document.documentElement.clientHeight - rect.bottom : 11;
                    diffVert = ( rect.top + diffVert > 0 ) ? diffVert : -y + 2;
                    diffVert = ( rect.top <= 0 ) ? -rect.top : diffVert;

                    if ( ( diffHori !== 7 ) || ( diffVert !== 11 ) ) {
                        if ( ( diffHori !== 7 ) && ( diffVert !== 11 ) ) {
                            diffVert = ( diffVert >= -20 ) ? -25 : diffVert;
                        }

                        diffVert = ( rect.top + diffVert >= 5 ) ? diffVert : -rect.top + 7;

                        divTooltip.style.left = ( x + diffHori ) + 'px';
                        divTooltip.style.top = ( y + diffVert ) + 'px';
                    }
                }
            }
        }
        ,

        /**
        * Hide the tooltip element.
        * @memberOf PWC.Core.Tooltip 
        */
        hide: _hide
        ,

        /**
        * Suspend the tooltip functionality.
        * @memberOf PWC.Core.Tooltip 
        */
        suspend: function () {
            _tooltipSuspended = true;
            _hide();
        }
        ,

        /**
        * Resume the tooltip functionality.
        * @memberOf PWC.Core.Tooltip 
        */
        resume: function () {
            _tooltipSuspended = false;
        }

    };

}( CPM.svgUtil ) );

// JavaScript source code
var CPM = ( CPM || {} );
CPM.Style = ( CPM.Style || {} );

CPM.StyleFactory = ( function () {
    return {
        getCurrentStyleProps: function ( currentStyle ) {
            switch ( currentStyle ) {
                case 'FlatStyle_Bright':
                    return new FlatStyleBright();
                case 'FlatStyle_Dark':
                    return new FlatStyleDark();
                case 'ExtendedStyle':
                default:
                    return new ExtendedStyle();
            }
        }
    };
} )();
var FlatStyleBright = function () {
    var brightStyle = CPM.Style;
    brightStyle.Control = {
        OddBackColor: 'rgba(255,255,255,1)',
        EvenBackColor: 'rgba(255,255,255,1)',
        ForeColor: 'rgba(33,41,44,1)',
        ExpCollIconColor: 'rgba(0,0,0,1)',
        NodeIconColor: 'rgba(123,146,162,1)',
        SelectionNodeIconColor: 'rgba(255,255,255,1)',
        SelectionBackColor: 'rgba(38,92,255,1)',
        SelectionForeColor: 'rgba(255,255,255,1)',
        HorizLineColor: 'rgba(223,230,237,1)'
    };
    brightStyle.BreadCrumb = {
        BackColor: 'rgba(223,230,237,1)',
        ForeColor: 'rgba(105,120,129,1)',
        IconColor: 'rgba(105,120,129,1)',
        SelectionForeColor: 'rgba(33,41,44,1)',
        ButtonColor: 'rgba(123,146,162,1)',
        PressedButtonColor: 'rgba(111,139,191,1)',
        PressedIconColor: 'rgba(255,255,255,1)',
        BottomBorderColor: 'none'
    };
    brightStyle.ComboBox = {
        ComboBoxColor: 'rgba(255, 255, 255, 1.0)',
        NormalbuttonColor: 'rgba(123, 146, 162, 1.0)',
        PressedbuttonColor: 'rgba(111, 139, 191, 1.0)',
        FontColor: '#000000',
        RectColor: 'rgba(255,255,255,1)',
        Rx: 0,
        Stroke: 'rgba(123, 146, 162, 1.0)',
        TriangleColor: 'rgba(255, 255, 255, 1.0)',
        OptionsStroke: 'rgba(155,175, 190, 1.0)',
        Line: 'rgba(0, 0, 0, 1.0)',
        ClickableRect: 'rgba(38, 92, 255, 1.0)'
    };
    brightStyle.ScrollBar = {
        BgColor: 'rgba(205, 217, 225, 1.0)',
        ScrollbarColor: 'rgba(205, 217, 225, 1.0)',
        ScrollerColor: 'rgba(123, 146, 162, 1.0)',
        HighlightColor: 'rgba(123, 146, 162, 1.0)',
        DisabledFillColor: '#CDD9E1',
        DisabledStrokeColor: '#cdd9e1',
        TriangleFillColor: 'rgba(105, 120, 129, 0)',
        TriangleStrokeColor: '#697881',
        Opacity: 1,
        LeftPadding: 20,
        ScrollPadding: 25,
        TopPadding: 2,
        Width: 20,
        HeightPadding: 2,
        HorizontalSliderHeight: 20,
        ScrollButton: 'rgba(205, 217, 225, 1.0)',
        TriangleColor: 'rgba(105, 120, 129, 1.0)',
        StrokeWidth: 2
    };
    brightStyle.ToolBar = {
        Fill: 'rgba(123, 146, 162, 1)',
        Hover: 'rgba(123, 146, 162, 0.75)',
        Pressed: 'rgba(111, 139, 191, 1)',
        Disabled: 'rgba(123, 146, 162, 0.6)',
        BottomBorder: 'rgba(0, 0, 0, 1)',
        BorderColor1: 'none',
        Rx: 0,
        BottomLineColor: 'none',
        IconColor: 'rgba(255,255,255,1)'
    };
    brightStyle.TextBox = {
        BackColor: 'rgba(255,255,255,1)',
        BorderColor: 'rgba(123, 146, 162, 1)',
        Rx: 0,
        BottomLineColor: 'rgba(0, 0, 0, 1)',
        LineStroke: '2',
        IconColor: 'rgba(123,146,162,1)',
        SvgWidth: '22',
        ViewBox: '0 0 26 22',
        RectLineColor: 'rgba(223,230,237,1)',
        StrokeWidth: '1',
        IconY: '-7'
    };
    return brightStyle;
};

var FlatStyleDark = function () {
    var darkStyle = CPM.Style;
    darkStyle.Control = {
        OddBackColor: 'rgba(40,45,58,1)',
        EvenBackColor: 'rgba(40,45,58,1)',
        ForeColor: 'rgba(255,255,255,1)',
        ExpCollIconColor: 'rgba(255,255,255,1)',
        NodeIconColor: 'rgba(131,145,160,1)',
        SelectionNodeIconColor: 'rgba(0,0,0,1)',
        SelectionBackColor: 'rgba(83,169,255,1)',
        SelectionForeColor: 'rgba(32,36,45,1)',
        HorizLineColor: 'rgba(58,66,82,1)'
    };
    darkStyle.BreadCrumb = {
        BackColor: 'rgba(58,66,82,1)',
        ForeColor: 'rgba(131,145,160,1)',
        IconColor: 'rgba(131,145,160,1)',
        SelectionForeColor: 'rgba(255,255,255,1)',
        ButtonColor: 'rgba(73,82,101,1)',
        PressedButtonColor: 'rgba(75,99,132,1)',
        PressedIconColor: 'rgba(255,255,255,1)',
        BottomBorderColor: 'none'
    };
    darkStyle.ComboBox = {
        ComboBoxColor: 'rgba(32, 36, 45, 1.0)',
        NormalbuttonColor: 'rgba(73, 82, 101, 1.0)',
        PressedbuttonColor: 'rgba(75, 99, 132, 1.0)',
        FontColor: '#FFFFFF',
        RectColor: 'rgba(32, 36, 45, 1.0)',
        Rx: 0,
        Stroke: 'rgba(73, 82, 101, 1.0)',
        TriangleColor: 'rgba(255, 255, 255, 1.0)',
        OptionsStroke: 'rgba(73, 82, 101, 1.0)',
        Line: 'rgba(131, 145, 160, 1.0)',
        ClickableRect: 'rgba(83, 169, 255, 1.0)'
    };
    darkStyle.ScrollBar = {
        BgColor: 'rgba(58, 66, 82, 1)',
        ScrollbarColor: 'rgba(58, 66, 82, 1.0)',
        ScrollerColor: 'rgba(131, 145, 160, 1.0)',
        HighlightColor: 'rgba(131, 145, 160, 1.0)',//actually   clr in hash
        DisabledFillColor: '#3A4252',
        DisabledStrokeColor: '#3a4252',
        TriangleFillColor: 'rgba(131, 145, 160, 0)',
        TriangleStrokeColor: '#8391A0',
        Opacity: 1,
        LeftPadding: 20,
        ScrollPadding: 25,
        TopPadding: 2,
        Width: 20,
        HeightPadding: 2,
        HorizontalSliderHeight: 20,
        ScrollButton: 'rgba(58, 66, 82, 1.0)',
        TriangleColor: 'rgba(131, 145, 160, 1.0)',
        StrokeWidth: 2
    };
    darkStyle.ToolBar = {
        Fill: 'rgba(73, 82, 101, 1)',
        Hover: 'rgba(73, 82, 101, 0.75)',
        Pressed: 'rgba(75, 99, 132, 1)',
        Disabled: 'rgba(73, 82, 101, 0.6)',
        BottomBorder: 'rgba(131, 145, 160, 1)',
        BorderColor1: 'none',
        Rx: 0,
        BottomLineColor: 'none',
        IconColor: 'rgba(255,255,255,1)'
    };
    darkStyle.TextBox = {
        BackColor: 'rgba(32, 36, 45, 1)',
        BorderColor: 'rgba(73, 82, 101, 1)',
        Rx: 0,
        BottomLineColor: 'rgba(131, 145, 160, 1)',
        LineStroke: '2',
        IconColor: 'rgba(131,145,160,1)',
        SvgWidth: '22',
        ViewBox: '0 0 26 22',
        RectLineColor: 'rgba(58,66,82,1)',
        StrokeWidth: '1',
        IconY: '-7'
    };
    return darkStyle;
};

var ExtendedStyle = function () {
    var extendedStyle = CPM.Style;
    extendedStyle.Control = {
        OddBackColor: '#e6e6eb',
        EvenBackColor: 'rgba(255,255,255,1)',
        ForeColor: 'rgba(0,0,0,1)',
        ExpCollIconColor: 'rgba(0,0,0,1)',
        NodeIconColor: 'rgba(0,0,0,1)',
        SelectionNodeIconColor: 'rgba(0,0,0,1)',
        SelectionBackColor: 'rgba(125,205,245,1)',
        SelectionForeColor: 'rgba(0,0,0,1)',
        HorizLineColor: 'none'
    };
    extendedStyle.BreadCrumb = {
        BackColor: 'rgba(230, 230, 235, 1)',
        ForeColor: 'rgba(0,0,0,1)',
        IconColor: 'gray',
        SelectionForeColor: 'rgba(0,0,0,1)',
        ButtonColor: 'url(#urlNodeGradient)',
        PressedButtonColor: '#878787',
        PressedIconColor: 'gray',
        BottomBorderColor: '#64646A'
    };
    extendedStyle.ComboBox = {
        ComboBoxColor: 'url(#CPM_Gradient_IOFieldNormal_Gradient)',
        NormalbuttonColor: 'url(#CPM_Gradient_ButtonNormal_Gradient)',
        PressedbuttonColor: 'url(#CPM_Gradient_ButtonPressed_Gradient)',
        FontColor: '#000000',
        RectColor: 'rgba(255,255,255,1)',
        Rx: 3,
        Stroke: 'rgba(100, 100, 106, 0.5)',
        TriangleColor: 'rgba(0, 0, 0, 1.0)',
        Line: 'none',
        ClickableRect: '#22aaee'
    };
    extendedStyle.ScrollBar = {
        BgColor: 'rgba(7, 33, 128, 0.54)',
        ScrollbarColor: 'rgba(240, 240, 254, 1.0)',
        ScrollerColor: 'rgba(100, 100, 106, 0.5)',
        HighlightColor: '#BBBBBB',
        DisabledFillColor: '#F6F6F6',
        DisabledStrokeColor: '#f6f6f6',
        TriangleFillColor: 'rgba(100, 100, 106, 0.5)',
        TriangleStrokeColor: 'none',
        Opacity: 0,
        Stroke: 'rgba(100, 100, 106, 1.0)',
        LeftPadding: 22,
        ScrollPadding: 22,
        TopPadding: 0,
        Width: 17,
        HeightPadding: 0,
        HorizontalSliderHeight: 17,
        ScrollButton: 'rgba(240, 240, 254, 1.0)',
        TriangleColor: 'rgba(100, 100, 106, 0.5)',
        StrokeWidth: 0
    };
    extendedStyle.ToolBar = {
        BorderColor1: 'rgba(100,100,106,1)',
        Fill: 'url(#ButtonBgGradient_LigtherDarker_ExpandAll)',
        Rx: 4,
        BottomLineColor: 'gray',
        IconColor: 'rgba(0,0,0,1)'
    };
    extendedStyle.TextBox = {
        BackColor: 'rgba(255, 255, 255, 1)',
        BorderColor: 'rgba(100, 100, 106, 1)',
        Rx: 3,
        BottomLineColor: 'rgba(100, 100, 106, 0.5)',
        LineStroke: '0',
        IconColor: 'rgba(0,0,0,1)',
        SvgWidth: '26',
        ViewBox: '0 0 26 26',
        RectLineColor: 'rgba(58,66,82,1)',
        StrokeWidth: '2',
        IconY: '-3'
    };
    return extendedStyle;
};

var CPM = ( CPM || {} );
CPM.Lib = ( CPM.Lib || {} );

//scrollbutton styles

//id,parentNode,scrollButtonProps,scrollButtonOrientation,currentStyle
CPM.Lib.ScrollButton = function (id, parentNode, scrollButtonProps, scrollButtonOrientation, currentStyle) {

    'use strict';
    // PRIVATE API
    var _id = id,
    _scrollButtonOrientation = scrollButtonOrientation,
     _stylePropObj = CPM.StyleFactory.getCurrentStyleProps(currentStyle),
    _isExtendedStyle = currentStyle === CPM.Enums.StyleName.Extended ? true : false,
    _scrollbarBackColor = _stylePropObj.ScrollBar.BgColor,
    _triangleFillColor = _stylePropObj.ScrollBar.TriangleFillColor,
    _triangleStrokeColor = _stylePropObj.ScrollBar.TriangleStrokeColor,
    _highlightColor = _stylePropObj.ScrollBar.HighlightColor,
    _disabledColor = _stylePropObj.ScrollBar.DisabledFillColor,
    _parentGroup = CPM.svgUtil.createSVG( 'g' ),
    _scrollRect = null,
    _scrollTriangle = null,
    
    //create scrollbutton geometry
    _createScrollbutton = function ( x, y, width, height ) {
        var myTriPath, triangleFourth, cellHeight, offsY = 0, offsX = 0, dataTifType;
        if ( height > width ) {
            offsY = ( height - width ) / 2;
            cellHeight = width;
        } else {
            offsX = ( width - height ) / 2;
            cellHeight = height;
        }
        //this is used to construct the triangles for the buttons
        triangleFourth = cellHeight / 4;
        if (_scrollButtonOrientation === 'vertical_up') {
            dataTifType = 'LineUp';
            if (_isExtendedStyle) {
                myTriPath = 'M' + (x + triangleFourth) + ' ' + (y + offsY + 3 * triangleFourth) + ' L' + (x + cellHeight * 0.5) + ' ' +
                   (y + offsY + triangleFourth) + ' L' + (x + 3 * triangleFourth) + ' ' + (y + offsY + 3 * triangleFourth) + ' Z';
            } else {
                myTriPath = 'M' + (x + triangleFourth) + ' ' + ((y + offsY + 3 * triangleFourth) - 2) + ' L' + (x + cellHeight * 0.5) + ' ' +
               (y + offsY + triangleFourth) + ' L' + (x + 3 * triangleFourth) + ' ' + ((y + offsY + 3 * triangleFourth) - 2);
            }
        } else if (_scrollButtonOrientation === 'vertical_down') {
            dataTifType = 'LineDown';
            if (_isExtendedStyle) {
                myTriPath = 'M' + (x + triangleFourth * 3) + ' ' + (y + offsY + triangleFourth) + ' L' + (x + cellHeight * 0.5) + ' ' +
                   (y + offsY + 3 * triangleFourth) + ' L' + (x + triangleFourth) + ' ' + (y + offsY + triangleFourth) + ' Z';

            } else {

                myTriPath = 'M' + (x + triangleFourth * 3) + ' ' + ((y + offsY + triangleFourth) + 2) + ' L' + (x + cellHeight * 0.5) + ' ' +
                       (y + offsY + 3 * triangleFourth) + ' L' + (x + triangleFourth) + ' ' + ((y + offsY + triangleFourth) + 2);

            }
        } else if (_scrollButtonOrientation === 'horizontal_up') {
            dataTifType = 'LineUp';
            if (_isExtendedStyle) {
                myTriPath = 'M' + (x + triangleFourth) + ' ' + (y + triangleFourth * 2) + ' L' + (x + 3 * triangleFourth) + ' ' +
                    (y + 3 * triangleFourth) + ' L' + (x + 3 * triangleFourth) + ' ' + (y + triangleFourth) + ' Z';
            }
            else {
                myTriPath = 'M' + ((x + 3 * triangleFourth) - 2) + ' ' + (y + triangleFourth) + 'L' + (x + triangleFourth) + ' ' + (y + triangleFourth * 2) + ' L' + ((x + 3 * triangleFourth) - 2) + ' ' +
             (y + 3 * triangleFourth);
            }
        } else {
            dataTifType = 'LineDown';
            if (_isExtendedStyle) {
                myTriPath = 'M' + (x + triangleFourth * 3) + ' ' + (y + 2 * triangleFourth) + ' L' + (x + triangleFourth) + ' ' +
                    (y + triangleFourth) + ' L' + (x + triangleFourth) + ' ' + (y + triangleFourth * 3) + ' Z';
            }
            else {
                myTriPath = 'M' + ((x + triangleFourth) + 2) + ' ' + (y + triangleFourth * 3) + ' L' + (x + triangleFourth * 3) + ' ' + (y + 2 * triangleFourth) + ' L' + ((x + triangleFourth) + 2) + ' ' +
              (y + triangleFourth);

            }
        }
        // rect
        _scrollRect = CPM.svgUtil.createSVG( 'rect', {
            id: _id,
            'data-tif-type': dataTifType,
            x: x,
            y: y,
            width: width,
            height: height,
            'fill-opacity': _stylePropObj.ScrollBar.Opacity,
            appendTo: _parentGroup
        } );
        //_scrollbarBackColor
        _scrollRect.setAttributeNS(null, 'fill', _scrollbarBackColor);
        _scrollTriangle = CPM.svgUtil.createSVG( 'path', {
            d: myTriPath,
            fill: _isExtendedStyle ? _stylePropObj.ScrollBar.TriangleColor : 'none',
            stroke: _stylePropObj.ScrollBar.TriangleColor,
            //'stroke-width': _stylePropObj.ScrollBar.StrokeWidth,
            'stroke-width': 2,
            'pointer-events': 'none',
             appendTo: _parentGroup
        } );
        //_triangleColor
        _scrollTriangle.setAttributeNS(null, 'fill', _triangleFillColor);
        _scrollTriangle.setAttributeNS(null, 'stroke', _triangleStrokeColor);
    };

    // INITIALIZER
    ( function () {
        //create scrollbutton
        if ( CPM.svgUtil.testParent( parentNode, _parentGroup ) ) {
            _createScrollbutton( scrollButtonProps.x, scrollButtonProps.y, scrollButtonProps.width, scrollButtonProps.height );
        }
    } )();

    // PUBLIC API
    return {
        onPointerDown: function () {
            //change appearance of triangle
            //_triangleColor
            _scrollTriangle.removeAttributeNS(null, 'fill');
            _scrollTriangle.removeAttributeNS(null, 'stroke');
            //_hightlightColor
            _scrollTriangle.setAttributeNS(null, 'fill', _highlightColor);
        },
        onPointerUp: function () {
            //change appearance of triangle
            //change appearance of triangle
            //_hightlightColor
            _scrollTriangle.removeAttributeNS(null, 'fill');
            //_trianglecolor
            _scrollTriangle.setAttributeNS(null, 'fill', _triangleFillColor);
            _scrollTriangle.setAttributeNS(null, 'stroke', _triangleStrokeColor);
        },
        updateScrollButton: function ( x, y, width, height ) {
            var myTriPath, triangleFourth, cellHeight, offsY = 0, offsX = 0, setAttributes = CPM.svgUtil.setAttr;
            if ( height > width ) {
                offsY = ( height - width ) / 2;
                cellHeight = width;
            } else {
                offsX = ( width - height ) / 2;
                cellHeight = height;
            }
            triangleFourth = cellHeight / 4;
            if (_scrollButtonOrientation === 'vertical_up') {
                if (_isExtendedStyle) {
                    myTriPath = 'M' + (x + triangleFourth) + ' ' + (y + offsY + 3 * triangleFourth) + ' L' + (x + cellHeight * 0.5) + ' ' +
                       (y + offsY + triangleFourth) + ' L' + (x + 3 * triangleFourth) + ' ' + (y + offsY + 3 * triangleFourth) + ' Z';
                } else {
                    myTriPath = 'M' + (x + triangleFourth) + ' ' + ((y + offsY + 3 * triangleFourth) - 2) + ' L' + (x + cellHeight * 0.5) + ' ' +
                   (y + offsY + triangleFourth) + ' L' + (x + 3 * triangleFourth) + ' ' + ((y + offsY + 3 * triangleFourth) - 2);
                }
            } else if (_scrollButtonOrientation === 'vertical_down') {
                if (_isExtendedStyle) {
                    myTriPath = 'M' + (x + triangleFourth * 3) + ' ' + (y + offsY + triangleFourth) + ' L' + (x + cellHeight * 0.5) + ' ' +
                       (y + offsY + 3 * triangleFourth) + ' L' + (x + triangleFourth) + ' ' + (y + offsY + triangleFourth) + ' Z';

                } else {

                    myTriPath = 'M' + (x + triangleFourth * 3) + ' ' + ((y + offsY + triangleFourth) + 2) + ' L' + (x + cellHeight * 0.5) + ' ' +
                           (y + offsY + 3 * triangleFourth) + ' L' + (x + triangleFourth) + ' ' + ((y + offsY + triangleFourth) + 2);

                }
            } else if (_scrollButtonOrientation === 'horizontal_up') {
                if (_isExtendedStyle) {
                    myTriPath = 'M' + (x + triangleFourth) + ' ' + (y + triangleFourth * 2) + ' L' + (x + 3 * triangleFourth) + ' ' +
                        (y + 3 * triangleFourth) + ' L' + (x + 3 * triangleFourth) + ' ' + (y + triangleFourth) + ' Z';
                }
                else {
                    myTriPath = 'M' + ((x + 3 * triangleFourth) - 2) + ' ' + (y + triangleFourth) + 'L' + (x + triangleFourth) + ' ' + (y + triangleFourth * 2) + ' L' + ((x + 3 * triangleFourth) - 2) + ' ' +
                 (y + 3 * triangleFourth);
                }
            } else {
                if (_isExtendedStyle) {
                    myTriPath = 'M' + (x + triangleFourth * 3) + ' ' + (y + 2 * triangleFourth) + ' L' + (x + triangleFourth) + ' ' +
                        (y + triangleFourth) + ' L' + (x + triangleFourth) + ' ' + (y + triangleFourth * 3) + ' Z';
                }
                else {
                    myTriPath = 'M' + ((x + triangleFourth) + 2) + ' ' + (y + triangleFourth * 3) + ' L' + (x + triangleFourth * 3) + ' ' + (y + 2 * triangleFourth) + ' L' + ((x + triangleFourth) + 2) + ' ' +
                  (y + triangleFourth);

                }
            }
            setAttributes( _scrollRect, {
                x: x,
                y: y,
                width: width,
                height: height
            } );
            setAttributes( _scrollTriangle, {
                d: myTriPath,
                fill: _isExtendedStyle ? _stylePropObj.ScrollBar.TriangleColor : 'none',
                stroke: _stylePropObj.ScrollBar.TriangleColor,
                //'stroke-width': _stylePropObj.ScrollBar.StrokeWidth,
                'stroke-width': 2,
                'pointer-events': 'none'
            } );
        },
        hide: function () {
            _parentGroup.setAttributeNS( null, 'display', 'none' );
        },
        show: function () {
            _parentGroup.setAttributeNS( null, 'display', 'inherit' );
        },
        remove: function () {
            _parentGroup.parentNode.removeChild( _parentGroup );
        },
        enable: function () {
            //_disabledColor
            _scrollRect.removeAttributeNS(null, 'fill');
            //_scrollbarBackColor
            _scrollRect.setAttributeNS(null, 'fill', _scrollbarBackColor);
        },
        disable: function () {
            //_scrollbarBackColor
            _scrollRect.removeAttributeNS(null, 'fill', _scrollbarBackColor);
            //_disabledColor
            _scrollRect.setAttributeNS(null, 'fill', _disabledColor);
        },
        updateColor: function () {
            _scrollRect.setAttributeNS(null, 'fill', _scrollbarBackColor);
        }
    };
};

var CPM = ( CPM || {} );
CPM.Enums = ( CPM.Enums || {} );
CPM.Enums.DataRecievedType = {
    NodeCount: 1010,
    RootOrNode: 1003,
    Hierarchies: 1005,
    SetViewPort: 1006,
    ExpandAll: 1007,
    Scroll: 1008,
    BreadCrumbData: 1011,
    AlarmSummary: 1012,
    ExpandAllForNode: 1013,
    ScreenWindowNode: 1014,
    LanguageChange: 1015
};
/**
* Creates an ENUM of different object count attributes
* @enum
* @desc Enum representing different types of object count attributes
*/
CPM.Enums.ObjectCountAttributes = {
    Requested: 0,
    TreeOrList: 1,
    SystemId: 2,
    ObjectId: 3,
    SelectedNode: 4,
    NameFilter: 5,
    PropertyFilter: 6,
    LanguageId: 7,
    BrowsingMode: 8,
    SortingMode: 9,
    SortByAttribute: 10
};
/**
* Creates an ENUM of different Data attributes
* @enum
* @desc Enum representing different types of Data attributes
*/
CPM.Enums.DataAttributes = {
    Requested: 0,
    TreeOrList: 1,
    StartIndex: 2,
    EndIndex: 3
};
/**
* Creates an ENUM of different types of views
* @enum
* @desc Enum representing different types of views(tree/list)
*/
CPM.Enums.View = {
    Tree: 0,
    List: 1,
    ViewPort: 4
};
/**
* Creates an ENUM of different types of languages
* @enum
* @desc Enum representing different types of languages
*/
CPM.Enums.Language = {
    English: 1033
};
/**
* Creates an ENUM of different types of BrowsingModes
* @enum
* @desc Enum representing different types of BrowsingModes
*/
CPM.Enums.BrowsingMode = {
    Hierarchies: 3,
    ViewRoot: 4,
    ViewNode: 5,
    ExpandAll: 6,
    CollapseAll: 7,
    Scroll: 5,
    AlarmSummary: 9,
    ScreenWindow: 11,
    AlarmOrSHC: 10,
    ScreenFilter: 13,
    ExpandNode: 12,
    RootNode: 15
};

CPM.Enums.Constants = {
    iconToIconGap: 19,
    iconToIconToTextGap: 42,
    horizontalgap: 15,
    polyDimW: 9,
    polyDimH: 5,
    iconDim: 18,
    Gray2: '#64646A',
    topPadding: 8,
    textLeftPadding: 25,
    toolbarHeight: 55,
    urlHeight: 40,
    textBottomPadding: 2,
    toolbarPadding: 4,
    stopColor1: '#F2F4FF',
    stopColor2: '#91939A',
    stopColor3: '#66676C',
    btnBorderColor1: 'rgba(100,100,106,1)',
    btnBorderColor2: 'rgba(100,100,106,0.5)',
    topPaddingAlarmIcon: 5,
    alarmIconWidth: 30,
    alarmIconLeftPadding: 3,
    searchBackRectHeight: 60,
    searchBoxLeftPadding: 15,
    searchBoxTopPadding: 13,
    searchComboBoxMinWidth: 160,
    searchComboBoxPadding: 10
};
CPM.Enums.ToolbarButtons = {
    ExpandAll: 'ExpandAll',
    CollapseAll: 'CollapseAll',
    Filter: 'Filter'
};
CPM.Enums.EventTarget = {
    ExpandCollapse: 0,
    NodeTextRect: 1,
    HScrollBar: 3,
    VScrollBar: 4,
    Slider: 5,
    MainSvg: 6,
    BCVScrollBar: 7,
    SummaryAlarm: 8,
    TreeGroupScroll: 9,
    BreadCrumbScroll: 10,
    BCNodeImage: 11,
    BCNodeText: 12,
    BCStartImage: 13,
    CrumbGroup: 14,
    ExpandAllButton: 15,
    CollapseAllButton: 16,
    FilterComboBox: 17,
    CBVScrollBar: 18,
    ComboBoxScroll: 19,
    TraverseToParent: 20,
    SearchComboBox: 21,
    ClearSearchText: 22,
    SearchInputBox: 23,
    SearchForText: 24,
    BCOverlay: 25
};
CPM.Enums.EventType = {
    panup: 'panup',
    pandown: 'pandown',
    panleft: 'panleft',
    panright: 'panright',
    panstart: 'panstart',
    panend: 'panend'
};
CPM.Enums.CompanionTypes = {
    Alarm: 1,
    'Calendar Control': 2,
    ScreenWindow: 3
};
CPM.Enums.Filter = {
    None: 0,
    NodeWithPendingAlarms: 1,
    NodeWithVisualization: 2
};
CPM.Enums.ComboGradients = {
    IOFieldNormal: 0,
    ButtonNormal: 1,
    ButtonPressed: 2
};
CPM.Enums.StyleName = {
    Extended: 'ExtendedStyle',
    DarkStyle: 'FlatStyle_Dark'
};
CPM.Enums.NavigationType = {
    Static: 0,
    Dynamic: 1
};
var CPM = ( CPM || {} );
CPM.Lib = ( CPM.Lib || {} );


//id,parentNode,x,y,width,height,startValue,endValue,initialWidthPerc,initialOffset,scrollStep,scrollButtonLocations,functionToCall
CPM.Lib.ScrollBar = function (props, currentStyle, horizontalLine) {
    'use strict';
    // PRIVATE API
    var
        // self  = this,
        _id = props.id,
        parentNode = props.parentNode,
        x = props.x,
        y = props.y,
        width = props.width,
        height = props.height,
        initialHeightPerc = props.initialHeightPerc,
        initialOffset = props.initialOffset,
        _startValue = props.startValue,
        _endValue = props.endValue,
        _scrollButtonLocations = props.scrollButtonLocations,
        _stylePropObj = CPM.StyleFactory.getCurrentStyleProps(currentStyle),
        _isExtendedStyle = currentStyle === CPM.Enums.StyleName.Extended ? true : false,
       _scrollbarBackColor = _stylePropObj.ScrollBar.BgColor,
        _scrollerColor = _stylePropObj.ScrollBar.ScrollerColor,
        _highlightColor = _stylePropObj.ScrollBar.HighlightColor,
        _disabledFillColor = _stylePropObj.ScrollBar.DisabledFillColor,
        _disabledStrokeColor = _stylePropObj.ScrollBar.DisabledStrokeColor,
        _functionToCall = props.functionToCall,
        //additional properties to be used later
        _horizOrVertical = 'vertical', //specifies wether scrollbar is horizontal or vertical
        _cellHeight = width, //the height or width of the buttons on top or bottom of the scrollbar
        _scrollStatus = false, //indicates whether scrolling is active  
        _scrollStep = props.scrollStep, //this value indicates how much the slider will scroll when the arrow buttons are pressed, values are in percentage
        _scrollPage,    // This value indicates how much the slider will scroll when the scrollbar is pressed, values are in percentage
        _parentGroup = CPM.svgUtil.createSVG( 'g' ),

        _enabled = true, // Indicates whether the Scrollbar is enabled or not
        _values = { abs: '', perc: initialOffset },        // The offset of the scroller wrt to the scrollbar when scroller moves.
        _scrollbarEvtX, // Stores the x position of the mouse when scroller is moved by clicking the scrollbar
        _scrollbarEvtY, // Stores the y position of the mouse when scroller is moved by clicking the scrollbar

        _scrollbar = null,
        _scrollbarX = 0,
        _scrollbarY = 0,
        _scrollbarWidth = 0,
        _scrollbarHeight = 0,

        _scrollUpperButton = null,
        _scrollLowerButton = null,

        _scroller = null,
        _scrollerX = 0,
        _scrollerY = 0,
        _scrollerHeight = 0,
        _scrollerWidth = 0,
        _scrollerPadding = 3,
        _scrollerMin = 10,
        
        //color shade change
        _colorShadeChange = function ( rgba, lum ) {
            var rsRGB, gsRGB, bsRGB, asRGB = 1;
            rgba = rgba.split( 'rgba(' )[1].split( ',' );
            rsRGB = parseInt( rgba[0] );
            gsRGB = parseInt( rgba[1] );
            bsRGB = parseInt( rgba[2] );
            asRGB = rgba[3];
            rsRGB = Math.round( Math.min( Math.max( 0, rsRGB + ( rsRGB * lum ) ), 255 ) );
            gsRGB = Math.round( Math.min( Math.max( 0, gsRGB + ( gsRGB * lum ) ), 255 ) );
            bsRGB = Math.round( Math.min( Math.max( 0, bsRGB + ( bsRGB * lum ) ), 255 ) );

            return 'rgba(' + rsRGB + ',' + gsRGB + ',' + bsRGB + ',' + asRGB;
        },
        //change or add alpha value
        _changeAlpha = function ( rgba, alpha ) {
            if ( alpha >= 0 && alpha <= 1 ) {
                rgba = rgba.split( 'rgba(' )[1].split( ',' );
                return 'rgba(' + rgba[0] + ',' + rgba[1] + ',' + rgba[2] + ',' + alpha + ')';
            }
        },
        //create scrollbar geometry
        _createScrollbar = function (x, y, width, height, initialHeightPerc, initialOffset, currentStyle ) {
            var scrollUpperRectX, scrollLowerRectX,
                scrollUpperRectY, scrollLowerRectY, scrollBtnProps;
            //If scroller color available then use it.
            //if ( typeof scrollerRGBAColor === 'string' && scrollerRGBAColor.indexOf( 'rgba' ) !== -1 ) {
            //    CPM.Lib.scrollbarStyles.fill = _colorShadeChange( scrollerRGBAColor, 1.4 );
            //    CPM.Lib.highlightStyles.fill = _changeAlpha( scrollerRGBAColor, 0.8 );
            //    CPM.Lib.triangleStyles.fill = CPM.Lib.scrollerStyles.fill = _changeAlpha( scrollerRGBAColor, 0.5 );
            //}
            //first determine if vertical of horizontal
            if ( width > height ) {
                _horizOrVertical = 'horizontal';
                _cellHeight = height;
            }

            if ( _horizOrVertical === 'vertical' ) {
                _parentGroup.setAttribute( 'data-tif-type', 'VScroll' );
                _parentGroup.setAttribute( 'data-tif-id', 'VScroll_' + _id );
                scrollUpperRectX = x;
                scrollLowerRectX = x;
                switch ( _scrollButtonLocations ) {
                    case 'top_top':
                        _scrollbarX = x;
                        _scrollbarY = y + ( 2 * _cellHeight );
                        _scrollbarWidth = width;
                        _scrollbarHeight = height - ( 2 * _cellHeight );
                        scrollUpperRectY = y;
                        scrollLowerRectY = y + _cellHeight;
                        break;
                    case 'bottom_bottom':
                        _scrollbarX = x;
                        _scrollbarY = y;
                        _scrollbarWidth = width;
                        _scrollbarHeight = height - ( 2 * _cellHeight );
                        scrollUpperRectY = y + height - ( 2 * _cellHeight );
                        scrollLowerRectY = y + height - _cellHeight;
                        break;
                    case 'top_bottom':
                        _scrollbarX = x;
                        _scrollbarY = y + _cellHeight - 1;
                        _scrollbarWidth = width;
                        _scrollbarHeight = height - ( 2 * _cellHeight ) + 2;
                        scrollUpperRectY = y;
                        scrollLowerRectY = y + height - _cellHeight;
                        break;
                    default:
                        _scrollbarX = x;
                        _scrollbarY = y;
                        _scrollbarWidth = width;
                        _scrollbarHeight = height;
                        break;
                }
            }
            else {
                if ( _horizOrVertical === 'horizontal' ) {
                    _parentGroup.setAttribute( 'data-tif-type', 'HScroll' );
                    _parentGroup.setAttribute( 'data-tif-id', 'HScroll_' + _id );
                    scrollUpperRectY = y;
                    scrollLowerRectY = y;
                    switch ( _scrollButtonLocations ) {
                        case 'top_top':
                            _scrollbarX = x + ( 2 * _cellHeight );
                            _scrollbarY = y;
                            _scrollbarWidth = width - ( 2 * _cellHeight );
                            _scrollbarHeight = height;
                            scrollUpperRectX = x;
                            scrollLowerRectX = x + _cellHeight;
                            break;
                        case 'bottom_bottom':
                            _scrollbarX = x;
                            _scrollbarY = y;
                            _scrollbarWidth = width - ( 2 * _cellHeight );
                            _scrollbarHeight = height;
                            scrollUpperRectX = x + width - ( 2 * _cellHeight );
                            scrollLowerRectX = x + width - _cellHeight;
                            break;
                        case 'top_bottom':
                            _scrollbarX = x + _cellHeight - 1;
                            _scrollbarY = y;
                            _scrollbarWidth = width - ( 2 * _cellHeight ) + 2;
                            _scrollbarHeight = height;
                            scrollUpperRectX = x;
                            scrollLowerRectX = x + width - _cellHeight;
                            break;
                        default:
                            _scrollbarX = x;
                            _scrollbarY = y;
                            _scrollbarWidth = width;
                            _scrollbarHeight = height;
                            break;
                    }
                }
            }

            if (horizontalLine) {
                CPM.svgUtil.createSVG('line', {
                    x1: 0,
                    x2: props.width + CPM.Enums.Constants.alarmIconWidth + _stylePropObj.ScrollBar.Width, //scrollLowerRectX + (_cellHeight * 2) + 30,
                    y1: scrollLowerRectY,
                    y2: scrollLowerRectY,
                    'stroke-width': 1,
                    stroke: _stylePropObj.Control.HorizLineColor,
                    appendTo: _parentGroup
                });
            }
            _scrollbar = CPM.svgUtil.createSVG( 'rect', {
                id: 'scrollbar_' + _id,
                'data-tif-type': 'Scrollbar',
                x: _scrollbarX,
                y: _scrollbarY,
                'fill-opacity': _stylePropObj.ScrollBar.Opacity,
                width: ( _scrollbarWidth < 0 ) ? 0 : _scrollbarWidth,
                height: ( _scrollbarHeight < 0 ) ? 0 : _scrollbarHeight,
                appendTo: _parentGroup
            } );

            //_scrollbarBackColor
            _scrollbar.setAttributeNS(null, 'fill', _scrollbarBackColor);

            //now create scroller   
            if ( _horizOrVertical === 'vertical' ) {
                _scrollerY = _scrollbarY + ( _scrollbarHeight - _scrollbarHeight * initialHeightPerc ) * initialOffset;
                _scrollerHeight = Math.max( _scrollerMin, _scrollbarHeight * initialHeightPerc );
                _scrollPage = _scrollerHeight / ( _scrollbarHeight - _scrollerHeight );
                if ( ( _scrollerY + _scrollerHeight ) > ( _scrollbarY + _scrollbarHeight ) ) {
                    _scrollerY = _scrollbarY + _scrollbarHeight - _scrollerHeight;
                }

                _scroller = CPM.svgUtil.createSVG( 'rect', {
                    id: 'scroller_' + _id,
                    'data-tif-type': 'Thumber',
                    x: _isExtendedStyle ? _scrollbarX + _scrollerPadding : _scrollbarX,
                    y: _scrollerY,
                    width: _isExtendedStyle ? _scrollbarWidth - ( 2 * _scrollerPadding ) : _scrollbarWidth,
                    ry: _isExtendedStyle ? ( width / 4 ) : 0,
                    height: _scrollerHeight,
                    appendTo: _parentGroup
                } );
            }
            else {
                if ( _horizOrVertical === 'horizontal' ) {
                    _scrollerX = _scrollbarX + ( _scrollbarWidth - _scrollbarWidth * initialHeightPerc ) * initialOffset;
                    _scrollerWidth = Math.max( _scrollerMin, _scrollbarWidth * initialHeightPerc );
                    _scrollPage = _scrollerWidth / ( _scrollbarWidth - _scrollerWidth );
                    if ( ( _scrollerX + _scrollerWidth ) > ( _scrollbarX + _scrollbarWidth ) ) {
                        _scrollerX = _scrollbarX + _scrollbarWidth - _scrollerWidth;
                    }

                    _scroller = CPM.svgUtil.createSVG( 'rect', {
                        id: 'scroller_' + _id,
                        'data-tif-type': 'Thumber',
                        x: _scrollerX,
                        y: _isExtendedStyle ? _scrollbarY + _scrollerPadding : _scrollbarY,
                        width: _scrollerWidth,
                        height: _isExtendedStyle ? (_scrollbarHeight - (2 * _scrollerPadding) < 0) ? 0: _scrollbarHeight - (2 * _scrollerPadding): _scrollbarHeight,
                        ry: _isExtendedStyle ? (height / 4) : 0,
                        appendTo: _parentGroup
                    } );
                }
            }
            //_scrollerColor
            _scroller.setAttributeNS(null, 'fill', _scrollerColor);

            //append scrollbuttons
            if ( _scrollButtonLocations !== 'none_none' ) {
                scrollBtnProps = {
                    x: scrollUpperRectX,
                    y: scrollUpperRectY,
                    width: _cellHeight,
                    height: _cellHeight
                };
                //id,parentNode,scrollBtnProps,scrollButtonOrientation,currentStyle
                _scrollUpperButton = new CPM.Lib.ScrollButton( 'scrollUpperRect_' + _id, _parentGroup, scrollBtnProps, _horizOrVertical + '_up', currentStyle );
                scrollBtnProps = {
                    x: scrollLowerRectX,
                    y: scrollLowerRectY,
                    width: _cellHeight,
                    height: _cellHeight
                };
                //id,parentNode,scrollBtnProps,scrollButtonOrientation,currentStyle
                _scrollLowerButton = new CPM.Lib.ScrollButton('scrollLowerRect_' + _id, _parentGroup, scrollBtnProps, _horizOrVertical + '_down', currentStyle);
            }
        };

    // INITIALIZER
    ( function () {
        //create scrollbar
        if ( CPM.svgUtil.testParent( parentNode, _parentGroup ) ) {
            _createScrollbar(x, y, width, height, initialHeightPerc, initialOffset, currentStyle);
        }
    } )();

    // PUBLIC API
    return {
        onPointerDown: function ( x, y, target ) {
            if ( _enabled ) {
                var callerId = target.getAttributeNS( null, 'id' );
                if ( callerId === 'scroller_' + _id ) {
                    //case the mouse went down on scroller
                    this.scroll( x, y, 'mousedown' );
                }
                else if ( callerId === 'scrollLowerRect_' + _id || callerId === 'scrollUpperRect_' + _id ) {
                    //this part is for scrolling per button
                    this.buttonScrollActive = true;
                    this.scrollDir = 'down';
                    this.scrollStep = _scrollStep;
                    this.currentScrollButton = _scrollLowerButton;

                    if ( callerId === 'scrollUpperRect_' + _id ) {
                        this.scrollDir = 'up';
                        this.currentScrollButton = _scrollUpperButton;
                    }

                    //change appearance of button
                    this.currentScrollButton.onPointerDown();

                    this.scrollPercent( this.scrollDir, this.scrollStep );
                    //setTimeout( function () { self.scrollPerButton( self ); }, 400 );
                }
                else {
                    if ( callerId === 'scrollbar_' + _id ) {
                        //this part is for scrolling when mouse is down on scrollbar                
                        this.scrollbarScrollActive = true;
                        _scrollbarEvtX = x;
                        _scrollbarEvtY = y;
                        this.scrollDir = 'down';
                        this.scrollStep = _scrollStep;
                        if ( _horizOrVertical === 'vertical' ) {
                            if ( y < _scrollerY ) {
                                this.scrollDir = 'up';
                            }
                        }
                        else {
                            if ( _horizOrVertical === 'horizontal' && x < _scrollerX ) {
                                    this.scrollDir = 'up';
                            }
                        }
                        //change styling
                        //_scrollerColor
                        _scroller.removeAttributeNS(null, 'fill');
                        //_highlightColor
                        _scroller.setAttributeNS(null, 'fill', _highlightColor);
                        this.scrollPercent( this.scrollDir, _scrollPage );
                        //setTimeout( function () { self.scrollPerScrollbar( self ); }, 400 );
                    }
                }
            }
        },
        onPointerMove: function ( x, y ) {
            if ( _enabled ) {
                if ( _scrollStatus ) {
                    //this is for scrolling per scroller
                    this.scroll( x, y, 'mousemove' );
                    return true;
                }
            }
            return false;
        },
        onPointerUp: function ( x, y ) {
            if ( _enabled ) {
                //this is for finishing the different scroll modi
                if ( _scrollStatus ) {
                    //finishing scroll per scroller
                    this.scroll( x, y, 'mouseup' );
                }
                if ( this.buttonScrollActive ) {
                    //finishing scroll per button
                    this.buttonScrollActive = false;

                    //change appearance of button
                    this.currentScrollButton.onPointerUp();
                    this.currentScrollButton = undefined;
                }
                if ( this.scrollbarScrollActive ) {
                    //finishing scroll per scrollbar
                    this.scrollbarScrollActive = false;
                    //change styling
                    //_hightlightColor
                    _scroller.removeAttributeNS(null, 'fill');
                    //_scrollerColor
                    _scroller.setAttributeNS(null, 'fill', _scrollerColor);
                }
            }
        },

        scroll: function ( x, y, type ) {
            if ( type === 'mousedown' ) {
                _scrollStatus = true;
                this.panCoords = { x: x, y: y };
                this.fireFunction( 'scrollStart' );
                //change styling
                //_scrollerColor
                _scroller.removeAttributeNS(null, 'fill');
                //_hightlightColor
                _scroller.setAttributeNS(null, 'fill', _highlightColor);
            }
            else if ( type === 'mousemove' ) {
                var diffX = x - this.panCoords.x;
                var diffY = y - this.panCoords.y;
                var scrollerDiff = false;
                if ( _horizOrVertical === 'vertical' ) {
                    var scrollerOrigY = _scrollerY;
                    _scrollerY += diffY;
                    if ( _scrollerY < _scrollbarY ) {
                        _scrollerY = _scrollbarY;
                    }
                    if ( ( _scrollerY + _scrollerHeight ) > ( _scrollbarY + _scrollbarHeight ) ) {
                        _scrollerY = _scrollbarY + _scrollbarHeight - _scrollerHeight;
                    }
                    _scroller.setAttributeNS( null, 'y', _scrollerY );
                    if ( scrollerOrigY !== _scrollerY ) {
                        scrollerDiff = true;
                    }
                }
                if ( _horizOrVertical === 'horizontal' ) {
                    var scrollerOrigX = _scrollerX;
                    _scrollerX += diffX;
                    if ( _scrollerX < _scrollbarX ) {
                        _scrollerX = _scrollbarX;
                    }
                    if ( ( _scrollerX + _scrollerWidth ) > ( _scrollbarX + _scrollbarWidth ) ) {
                        _scrollerX = _scrollbarX + _scrollbarWidth - _scrollerWidth;
                    }
                    _scroller.setAttributeNS( null, 'x', _scrollerX );
                    if ( scrollerOrigX !== _scrollerX ) {
                        scrollerDiff = true;
                    }
                }
                if ( scrollerDiff ) {
                    this.fireFunction( 'scrollChange' );
                }
                this.panCoords = { x: x, y: y };
            }
            else {
                if ( type === 'mouseup' ) {
                    _scrollStatus = false;
                    //change styling
                    //_hightlightColor
                    _scroller.removeAttributeNS(null, 'fill');
                    //_scrollerColor
                    _scroller.setAttributeNS(null, 'fill', _scrollerColor);
                    this.fireFunction( 'scrollEnd' );
                }
            }
        },

        scrollPercent: function ( direction, increment ) {
            var currentValues = this.getValue();
            if ( direction === 'up' ) {
                increment = increment * -1;
            }
            var newPercent = currentValues.perc + increment;
            if ( newPercent < 0 ) {
                newPercent = 0;
            }
            if ( newPercent > 1 ) {
                newPercent = 1;
            }
            this.scrollToPercent( newPercent );
        },

        scrollToPercent: function ( percValue ) {
            var newX, newY;
            if ( percValue >= 0 && percValue <= 1 ) {
                if ( _horizOrVertical === 'vertical' ) {
                    newY = _scrollbarY + ( _scrollbarHeight - _scrollerHeight ) * percValue;
                    _scrollerY = newY;
                    _scroller.setAttributeNS( null, 'y', newY );
                }
                if ( _horizOrVertical === 'horizontal' ) {
                    newX = _scrollbarX + ( _scrollbarWidth - _scrollerWidth ) * percValue;
                    _scrollerX = newX;
                    _scroller.setAttributeNS( null, 'x', newX );
                }

                this.fireFunction( 'scrolledStep' );
            }
        },

        scrollPerButton: function ( self ) {
            if ( self.buttonScrollActive ) {
                self.scrollPercent( self.scrollDir, self.scrollStep );
                setTimeout( function () { self.scrollPerButton( self ); }, 50 );
            }
        },

        scrollPerScrollbar: function ( self ) {
            var scroll = true;
            if ( _horizOrVertical === 'vertical' ) {
                if ( ( self.scrollDir === 'up' && _scrollerY < _scrollbarEvtY ) || ( self.scrollDir === 'down' && _scrollerY + _scrollerHeight > _scrollbarEvtY ) ) {
                    scroll = false;
                }
            } else {
                if ( ( self.scrollDir === 'up' && _scrollerX < _scrollbarEvtX ) || ( self.scrollDir === 'down' && _scrollerX + _scrollerWidth > _scrollbarEvtX ) ) {
                    scroll = false;
                }
            }
            if ( self.scrollbarScrollActive && scroll ) {
                self.scrollPercent( self.scrollDir, _scrollPage );
                setTimeout( function () { self.scrollPerScrollbar( self ); }, 50 );
            }
        },

        scrollToValue: function ( value ) {
            if ( ( value >= _startValue && value <= _endValue ) || ( value <= _startValue && value >= _endValue ) ) {
                var percValue = value / ( _endValue - _startValue );
                this.scrollToPercent( percValue );
            }
        },

        getValue: function () {
            var perc;
            if ( _horizOrVertical === 'vertical' ) {
                perc = ( _scrollerY - _scrollbarY ) / ( _scrollbarHeight - _scrollerHeight );
            }
            if ( _horizOrVertical === 'horizontal' ) {
                perc = ( _scrollerX - _scrollbarX ) / ( _scrollbarWidth - _scrollerWidth );
            }
            var abs = _startValue + ( _endValue - _startValue ) * perc;
            return { 'abs': abs, 'perc': perc };
        },

        fireFunction: function ( changeType ) {
            _values = this.getValue();
            if ( typeof ( _functionToCall ) === 'function' ) {
                _functionToCall( changeType, _values.abs, _values.perc );
                return;
            }
            if ( typeof ( _functionToCall ) === 'object' ) {
                _functionToCall.scrollbarChanged( _id, changeType, _values.abs, _values.perc );
                return;
            }
        },

        updateScrollbar: function ( _x, _y, _width, _height, _initialHeightPerc ) {
            var scrollUpperRectX, scrollLowerRectX,
                scrollUpperRectY, scrollLowerRectY,
                setAttributes = CPM.svgUtil.setAttr;

            if ( _horizOrVertical === 'vertical' ) {

                scrollUpperRectX = _x;
                scrollLowerRectX = _x;
                switch ( _scrollButtonLocations ) {
                    case 'top_top':
                        _scrollbarX = _x;
                        _scrollbarY = _y + ( 2 * _cellHeight );
                        _scrollbarWidth = _width;
                        _scrollbarHeight = _height - ( 2 * _cellHeight );
                        scrollUpperRectY = _y;
                        scrollLowerRectY = _y + _cellHeight;
                        break;
                    case 'bottom_bottom':
                        _scrollbarX = _x;
                        _scrollbarY = _y;
                        _scrollbarWidth = _width;
                        _scrollbarHeight = _height - ( 2 * _cellHeight );
                        scrollUpperRectY = _y + _height - ( 2 * _cellHeight );
                        scrollLowerRectY = _y + _height - _cellHeight;
                        break;
                    case 'top_bottom':
                        _scrollbarX = _x;
                        _scrollbarY = _y + _cellHeight;
                        _scrollbarWidth = _width;
                        _scrollbarHeight = _height - ( 2 * _cellHeight );
                        scrollUpperRectY = _y;
                        scrollLowerRectY = _y + _height - _cellHeight;
                        break;
                    default:
                        _scrollbarX = _x;
                        _scrollbarY = _y;
                        _scrollbarWidth = _width;
                        _scrollbarHeight = _height;
                        break;
                }
            }
            else {
                if ( _horizOrVertical === 'horizontal' ) {

                    scrollUpperRectY = _y;
                    scrollLowerRectY = _y;
                    switch ( _scrollButtonLocations ) {
                        case 'top_top':
                            _scrollbarX = _x + ( 2 * _cellHeight );
                            _scrollbarY = _y;
                            _scrollbarWidth = _width - ( 2 * _cellHeight );
                            _scrollbarHeight = _height;
                            scrollUpperRectX = _x;
                            scrollLowerRectX = _x + _cellHeight;
                            break;
                        case 'bottom_bottom':
                            _scrollbarX = _x;
                            _scrollbarY = _y;
                            _scrollbarWidth = _width - ( 2 * _cellHeight );
                            _scrollbarHeight = _height;
                            scrollUpperRectX = _x + _width - ( 2 * _cellHeight );
                            scrollLowerRectX = _x + _width - _cellHeight;
                            break;
                        case 'top_bottom':
                            _scrollbarX = _x + _cellHeight;
                            _scrollbarY = _y;
                            _scrollbarWidth = _width - ( 2 * _cellHeight );
                            _scrollbarHeight = _height;
                            scrollUpperRectX = _x;
                            scrollLowerRectX = _x + _width - _cellHeight;
                            break;
                        default:
                            _scrollbarX = _x;
                            _scrollbarY = _y;
                            _scrollbarWidth = _width;
                            _scrollbarHeight = _height;
                            break;
                    }
                }
            }

            setAttributes( _scrollbar, {
                x: _scrollbarX,
                y: _scrollbarY,
                width: _scrollbarWidth,
                height: _scrollbarHeight
            } );

            //now update scroller   
            if ( _horizOrVertical === 'vertical' ) {
                _scrollerY = _scrollbarY + ( _scrollbarHeight - _scrollbarHeight * _initialHeightPerc ) * _values.perc;
                _scrollerHeight = Math.max( _scrollerMin, _scrollbarHeight * _initialHeightPerc );
                _scrollPage = _scrollerHeight / ( _scrollbarHeight - _scrollerHeight );
                if ( ( _scrollerY + _scrollerHeight ) > ( _scrollbarY + _scrollbarHeight ) ) {
                    _scrollerY = _scrollbarY + _scrollbarHeight - _scrollerHeight;
                }
                setAttributes( _scroller, {
                    x: _scrollbarX + _scrollerPadding,
                    y: _scrollerY,
                    width: _scrollbarWidth - ( 2 * _scrollerPadding ),
                    height: _scrollerHeight
                } );
            }
            else {
                if ( _horizOrVertical === 'horizontal' ) {
                    _scrollerX = _scrollbarX + ( _scrollbarWidth - _scrollbarWidth * _initialHeightPerc ) * _values.perc;
                    _scrollerWidth = Math.max( _scrollerMin, _scrollbarWidth * _initialHeightPerc );
                    _scrollPage = _scrollerWidth / ( _scrollbarWidth - _scrollerWidth );
                    if ( ( _scrollerX + _scrollerWidth ) > ( _scrollbarX + _scrollbarWidth ) ) {
                        _scrollerX = _scrollbarX + _scrollbarWidth - _scrollerWidth;
                    }

                    setAttributes( _scroller, {
                        x: _scrollerX,
                        y: _scrollbarY + _scrollerPadding,
                        width: _scrollerWidth,
                        height: _scrollbarHeight - ( 2 * _scrollerPadding )
                    } );
                }
            }

            //Update scrollbuttons
            if ( _scrollButtonLocations !== 'none_none' ) {
                //id,parentNode,x,y,width,height,scrollButtonOrientation,functionToCall
                _scrollUpperButton.updateScrollButton( scrollUpperRectX, scrollUpperRectY, _cellHeight, _cellHeight );

                //id,parentNode,x,y,width,height,scrollButtonOrientation,functionToCall
                _scrollLowerButton.updateScrollButton( scrollLowerRectX, scrollLowerRectY, _cellHeight, _cellHeight );
            }
        },

        hide: function () {
            _parentGroup.setAttributeNS( null, 'display', 'none' );
        },

        show: function () {
            _parentGroup.setAttributeNS( null, 'display', 'inherit' );
        },

        remove: function () {
            _parentGroup.parentNode.removeChild( _parentGroup );
        },

        scrollbarHeight: function () {
            return _scrollbarHeight;
        },

        scrollbarWidth: function () {
            return _scrollbarWidth;
        },

        enable: function () {
            _enabled = true;
            //change appearance of scroller and scrollbar
            //DisabledColor
            _scroller.removeAttributeNS(null, 'fill');
            _scroller.removeAttributeNS(null, 'stroke');
            //_ScrollerColor
            _scroller.setAttributeNS(null, 'fill', _scrollerColor);
            //_DisabledColor
            _scrollbar.removeAttributeNS(null, 'fill');
            _scrollbar.removeAttributeNS(null, 'stroke');
            //_scrollbarBackColor
            _scrollbar.setAttributeNS(null, 'fill', _scrollbarBackColor);
            _scrollUpperButton.enable();
            _scrollLowerButton.enable();
        },

        disable: function () {
            _enabled = false;
            //change appearance of scroller and scrollbar
            //_ScrollerColor
            _scroller.removeAttributeNS(null, 'fill');
            //_DisabledColor
            _scroller.setAttributeNS(null, 'fill', _disabledFillColor);
            _scroller.setAttributeNS(null, 'stroke', _disabledStrokeColor);
            //_scrollbarBackColor
            _scrollbar.removeAttributeNS(null, 'fill');
            //_disabledColor
            _scrollbar.setAttributeNS(null, 'fill', _disabledFillColor);
            _scrollbar.setAttributeNS(null, 'stroke', _disabledStrokeColor);
            _scrollUpperButton.disable();
            _scrollLowerButton.disable();
        },

        getState: function () {
            return _enabled;
        },

        updateScrollerColor: function ( scrollerRGBAColor ) {
            if ( typeof scrollerRGBAColor === 'string' && scrollerRGBAColor.indexOf( 'rgba' ) !== -1 ) {
                _scrollbarBackColor = _colorShadeChange(scrollerRGBAColor, 1.4);
                _highlightColor = _changeAlpha(scrollerRGBAColor, 0.8);
                if (_scrollbar) {
                    _scrollbar.setAttributeNS(null, 'fill', _scrollbarBackColor);
                }
                if (_scroller) {
                    _scroller.setAttributeNS(null, 'fill', _scrollerColor);
                }
                if ( _scrollUpperButton ) {
                    _scrollUpperButton.updateColor();
                }
                if ( _scrollLowerButton ) {
                    _scrollLowerButton.updateColor();
                }
            }
        }
    };
};
/**
* @fileOverview timeslicehandler.js.
* @author Ambika Jadhav
* @author Rama Reddy
*/
/**
* Namespace for TimesliceHandler.
* @namespace CPM.Control
*/
var CPM = CPM || {};
CPM.Control = CPM.Control || {};
/**
* Creates an instance of TimesliceHandler.
* @class
* @desc Class representing the timeslicehandler object.
* @constructor
*/
CPM.Control.ScrollHandler = function () {
    'use strict';
    /**
    * Private members.
    */
    var _settings = null,
        _bgRect = null,
        _isHorizontal,
        _stylePropObj,
        _scrollBarRef = {
            id: null,
            width: 0,
            height: 0,
            x: 0,
            y: 0,
            instance: null,
            visible: false,
            columnStartIndex: 0,
            borderLine: null,
            scrolledValue: 0,
            scrollEnd: 0,
            isScrollMove: false,
            parentNode: null,
            startValue: 0,
            endValue: 0,
            initialHeightPerc: 0,
            initialOffset: 0,
            scrollStep: 0,
            scrollButtonLocations: '',
            functionToCall: null
        },
        _createBgRect = function () {
            _bgRect = CPM.svgUtil.createSVG( 'rect', {
                x: _scrollBarRef.x,
                y: _scrollBarRef.y,
                height: _scrollBarRef.height,
                width: _settings.width,
                fill: _stylePropObj.ScrollBar.BgColor,
                'shape-rendering': 'crispEdges',
                stroke: 'none',
                'fill-opacity': 0,
                appendTo: _scrollBarRef.parentNode
            } );
        };
    this.createScrollBar = function (areaSettings, left, top, parent, scrollbarCallBack, isHorizontal, horizontalLine) {
        _settings = areaSettings;
        _scrollBarRef.parentNode = parent;
        _isHorizontal = isHorizontal;
        _stylePropObj = CPM.StyleFactory.getCurrentStyleProps( areaSettings.currentStyle );
        _scrollBarRef.x = left;
        _scrollBarRef.y = top;
        if ( isHorizontal ) {
            _scrollBarRef.width = _settings.width;
            _scrollBarRef.height = _settings.height;
            _scrollBarRef.id = 'hScrollbar';

            _scrollBarRef.startValue = 0;
            _scrollBarRef.endValue = _settings.endValue;//areaSettings.cellSettings.actualCount - areaSettings.cellSettings.countForEachRow;
            _scrollBarRef.initialHeightPerc = _settings.initialHeightPerc;//areaSettings.cellSettings.countForEachRow / areaSettings.cellSettings.actualCount;
            _scrollBarRef.initialOffset = 0;
            if ( _settings.initialScrollOffset ) {
                _scrollBarRef.initialOffset = _settings.initialScrollOffset;//areaSettings.verticalScrollIndex / _scrollBarRef.endValue;
            }
            //_scrollBarRef.initialOffset = _scrollBarRef.scrolledValue;
            _scrollBarRef.scrollStep = _settings.scrollStep;// / ( areaSettings.cellSettings.actualCount - areaSettings.cellSettings.countForEachRow );
            _scrollBarRef.scrollButtonLocations = 'top_bottom';
        }
        else {
            //_scrollBarRef.width = _settings.horizontalSliderHeight;
            _scrollBarRef.width = _settings.width;
            _scrollBarRef.height = _settings.height;
            _scrollBarRef.id = _settings.id + 'vScrollbar';

            _scrollBarRef.startValue = 0;
            _scrollBarRef.endValue = _settings.endValue;//areaSettings.rowCount - areaSettings.maxRowCount;

            _scrollBarRef.initialOffset = 0;
            if ( _settings.initialScrollOffset ) {
                _scrollBarRef.initialOffset = _settings.initialScrollOffset;//areaSettings.verticalScrollIndex / _scrollBarRef.endValue;
            }

            //_scrollBarRef.initialOffset = areaSettings.verticalScrollIndex;
            _scrollBarRef.initialHeightPerc = _settings.initialHeightPerc;//( areaSettings.maxRowCount / areaSettings.rowCount );
            _scrollBarRef.scrollStep = _settings.scrollStep;// / ( areaSettings.rowCount - areaSettings.maxRowCount );
            _scrollBarRef.scrollButtonLocations = 'top_bottom';
            _scrollBarRef.isScrollMove = true;

        }
        _scrollBarRef.functionToCall = scrollbarCallBack;
        _createBgRect();
        _scrollBarRef.instance = new CPM.Lib.ScrollBar(_scrollBarRef, _settings.currentStyle, horizontalLine);
    };
    this.onScrollEvent = function ( mousePosWrtArea, targetGroup, evt, targetNode ) {
        var x = mousePosWrtArea.x,
        y = mousePosWrtArea.y;
        switch ( evt.type ) {
            case 'panstart':
            case 'mousedown':
            case 'touchstart':
                _scrollBarRef.instance.onPointerDown( x, y, targetNode );
                break;
            case 'pan':
            case 'panright':
            case 'panleft':
            case 'panup':
            case 'pandown':
            case 'mousemove':
                if ( ( _isHorizontal && ( evt.type !== 'panup' && evt.type !== 'pandown' ) ) ) {
                    _scrollBarRef.instance.onPointerMove( x, y, targetNode );
                }
                else {
                    if ( ( !_isHorizontal && ( evt.type !== 'panright' && evt.type !== 'panleft' ) ) ) {
                        _scrollBarRef.instance.onPointerMove( x, y, targetNode );
                    }
                }
                break;
            case 'panend':
            case 'mouseup':
            case 'touchend':
                _scrollBarRef.instance.onPointerUp( x, y );
                break;
            default:
                break;
        }
    };
    this.onScrollClickEvent = function ( mousePosWrtArea, targetGroup, evt, targetNode ) {
        var x = _scrollBarRef.x + mousePosWrtArea.x,
       y = _scrollBarRef.y + mousePosWrtArea.y;
        switch ( evt.type ) {
            case 'panstart':
            case 'touchstart':
            case 'mousedown':
                _scrollBarRef.instance.onPointerDown( x, y, targetNode );
                break;
            case 'panend':
            case 'touchend':
            case 'mouseup':
                _scrollBarRef.instance.onPointerUp( x, y );
                break;
            default:
                break;
        }
    };
    this.remove = function () {
        _scrollBarRef.parentNode.removeChild( _bgRect );
        //_bgRect.remove();
        _scrollBarRef.instance.remove();
    };
};
var CPM = (CPM || {});

/**
* Creates an instance of ComboBox.
* @class
* @desc Class representing the svg combo box.
* @constructor
*/
CPM.ComboBoxHandler = function (svgParent) {
    var _svgParent = svgParent;
    this.styleGuideGradGroup = null;
    this.getControlName = 'CPM_';
    this.id = 'CPM_Gradient_';
    this.getGuideStyles = function ( styleGuideGradient ) {

        var createSVGElement = CPM.svgUtil.createSVG,
            linearGrad,
            stopElement,
            styleGuideGradients = CPM.Enums.ComboGradients,
            id = '';

        this.styleGuideGradPresent = ( this.styleGuideGradPresent || {} );
        if (!this.styleGuideGradGroup) {
            this.styleGuideGradGroup = createSVGElement('g', {
                'id': this.getControlName + 'StyleGuideGradientGroup'
            });
            createSVGElement('defs',
                {
                    'id': 'defs_' + this.getControlName + 'StyleGuideGradientGroup', 'appendTo': this.styleGuideGradGroup
                });
            _svgParent.appendChild(this.styleGuideGradGroup);
        }
        switch ( styleGuideGradient ) {
            case styleGuideGradients.IOFieldNormal:
                if ( this.styleGuideGradPresent.IOFieldNormal ) {
                    id = this.styleGuideGradPresent.IOFieldNormal;
                } else {
                    id = this.styleGuideGradPresent.IOFieldNormal = this.id + '_IOFieldNormal_Gradient';
                    linearGrad = createSVGElement( 'linearGradient' );
                    linearGrad.setAttributeNS( null, 'id', id );
                    linearGrad.setAttributeNS( null, 'x1', '0%' );
                    linearGrad.setAttributeNS( null, 'x2', '0%' );
                    linearGrad.setAttributeNS( null, 'y1', '0%' );
                    linearGrad.setAttributeNS( null, 'y2', '100%' );

                    stopElement = createSVGElement( 'stop' );
                    stopElement.setAttributeNS( null, 'offset', '0%' );
                    stopElement.setAttributeNS( null, 'stop-color', '#E6E6EB' );
                    linearGrad.appendChild( stopElement );

                    stopElement = createSVGElement( 'stop' );
                    stopElement.setAttributeNS( null, 'offset', '15%' );
                    stopElement.setAttributeNS( null, 'stop-color', '#FFFFFF' );
                    linearGrad.appendChild( stopElement );

                    stopElement = createSVGElement( 'stop' );
                    stopElement.setAttributeNS( null, 'offset', '85%' );
                    stopElement.setAttributeNS( null, 'stop-color', '#FFFFFF' );
                    linearGrad.appendChild( stopElement );

                    stopElement = createSVGElement( 'stop' );
                    stopElement.setAttributeNS( null, 'offset', '100%' );
                    stopElement.setAttributeNS( null, 'stop-color', '#E6E6EB' );
                    linearGrad.appendChild( stopElement );

                    this.styleGuideGradGroup.appendChild( linearGrad );
                }
                break;
            case styleGuideGradients.ButtonNormal:
                if ( this.styleGuideGradPresent.ButtonNormal ) {
                    id = this.styleGuideGradPresent.ButtonNormal;
                } else {
                    id = this.styleGuideGradPresent.ButtonNormal = this.id + '_ButtonNormal_Gradient';
                    linearGrad = createSVGElement( 'linearGradient' );
                    linearGrad.setAttributeNS( null, 'id', id );
                    linearGrad.setAttributeNS( null, 'x1', '0%' );
                    linearGrad.setAttributeNS( null, 'x2', '0%' );
                    linearGrad.setAttributeNS( null, 'y1', '0%' );
                    linearGrad.setAttributeNS( null, 'y2', '100%' );

                    stopElement = createSVGElement( 'stop' );
                    stopElement.setAttributeNS( null, 'offset', '0%' );
                    stopElement.setAttributeNS( null, 'stop-color', '#F2F4FF' );
                    linearGrad.appendChild( stopElement );

                    stopElement = createSVGElement( 'stop' );
                    stopElement.setAttributeNS( null, 'offset', '100%' );
                    stopElement.setAttributeNS( null, 'stop-color', '#91939A' );
                    linearGrad.appendChild( stopElement );

                    this.styleGuideGradGroup.appendChild( linearGrad );
                }
                break;
            case styleGuideGradients.ButtonPressed:
                if ( this.styleGuideGradPresent.ButtonPressed ) {
                    id = this.styleGuideGradPresent.ButtonPressed;
                } else {
                    id = this.styleGuideGradPresent.ButtonPressed = this.id + '_ButtonPressed_Gradient';
                    linearGrad = createSVGElement( 'linearGradient' );
                    linearGrad.setAttributeNS( null, 'id', id );
                    linearGrad.setAttributeNS( null, 'x1', '0%' );
                    linearGrad.setAttributeNS( null, 'x2', '0%' );
                    linearGrad.setAttributeNS( null, 'y1', '0%' );
                    linearGrad.setAttributeNS( null, 'y2', '100%' );

                    stopElement = createSVGElement( 'stop' );
                    stopElement.setAttributeNS( null, 'offset', '0%' );
                    stopElement.setAttributeNS( null, 'stop-color', '#91939A' );
                    linearGrad.appendChild( stopElement );

                    stopElement = createSVGElement( 'stop' );
                    stopElement.setAttributeNS( null, 'offset', '100%' );
                    stopElement.setAttributeNS( null, 'stop-color', '#F2F4FF' );
                    linearGrad.appendChild( stopElement );
                    this.styleGuideGradGroup.appendChild( linearGrad );
                }
                break;
            default:
                id = '';
                break;
        }
        return 'url(#' + id + ')';
    };
};
var CPM = ( CPM || {} );

/**
* Creates an instance of ComboBox.
* @class
* @desc Class representing the svg combo box.
* @constructor
*/
CPM.ComboBox = function ( id, functionToCall, getNodes, comboBoxStyles, currentStyle ) {
    'use strict';

    var _id = id + '_ComboBox',
        _stylePropObj = CPM.StyleFactory.getCurrentStyleProps( currentStyle ),
        _isExtendedStyle = currentStyle.includes( CPM.Enums.StyleName.Extended ) ? true : false,
        _styles = {
            rx: _stylePropObj.ComboBox.Rx,
            'stroke-width': 0.5,
            stroke: _stylePropObj.ComboBox.Stroke
        },
        _strokeWidth,
        _comboButtonId = _id + '_ComboButton',
        _comboRectId = _id + '_ComboBoxRect',
        _optionsRectId = _id + '_ComboBoxOptionsRect',
        _clickableRectId = _id + '_OptionNumber_',
        _svgNodeId = _id + '_SvgOptionNode_',
        _clipPathId = _id + 'clippath',
        OPTIONS_RECT_PULLBACK = 1, // The options rect is pulled back up behind the comboBox rect so that no divide is seen between the comboBox and the options rect.
        _svgParent,
        _comboBoxDim = {},
    // Maximum height allowed for the dropdown.
        _maxOptionsHeight,
        _initialOptionsWidth,
        _ctrlHeight,
        _topCbOptions,
        _visibleRowLimit,
        _functionToCall = functionToCall,
        _getNodes = getNodes || _createTextNodes,
        _options = [],
        _selectedOption = '',
        _comboBoxGroup,
        _comboBoxButtonGroup,
        _selectedNodeGroup,
        _selctedNodeSVG,
        _selectedNode,
        _selectedNodeId = _clickableRectId + 'SelectedNode',
        _highlightedNode,
        _comboBoxOptionsGroup,
        _comboBoxContentGroup,
        _comboOptionsTranslateGroup,
        _clipPath,
        _clipRect,
        _cbClickableRectsGroup,
        _comboBoxRect,
        _comboBoxLine,
        _optionsRect,
        _optionsRectDim = {},
        _nodes = [],
        _svgOptionNodes = [],
        _cbScrollVerticalHandler,
        _isScrollbarCreated = false,
        _cbClickableRects = { nodes: [], selectedNode: undefined },
        _fontProps = {
            'font-family': 'Siemens Sans',
            'font-size': 14,
            'font-style': 'none',
            'font-weight': 400,
            'text-decoration': '',
            'stroke-width': 0,
            'fill': _stylePropObj.ComboBox.FontColor
        },
        _textHeight = CPM.svgUtil.getTextBBox( _fontProps, 'AA' ) === undefined ? 15 : CPM.svgUtil.getTextBBox( _fontProps, 'AA' ).height,   //Debian firefox returns undefined
        self = this,
        _comboBoxOpen = false,

        _display = true,

        _scrollbarStyles = { stroke: _stylePropObj.ScrollBar.Stroke },
        _highlightScrollbarStyles = { stroke: _isExtendedStyle ? _stylePropObj.ScrollBar.ScrollerColor : 'none' },
        _triangleStyles = { fill: _stylePropObj.ComboBox.TriangleColor },
        _scrollRect = null,
        _scrollTriangle = null,

    //Scrollbar - Sb
        _optionsSb,
        _optionsSbId = _id + '_Scrollbar',
    // Scrollbar coordinates.
        _optionsSbTop,
        _optionsSbLeft,
        _optionsSbOffset,
        SCROLLBAR_WIDTH = 17,

    /**
    * Initializes styles for the combo box elements.
    * @function
    * @memberOf CPM.ComboBox
    * @param {styles} Styles to be applied to the combo box elements.
    */
        _initializeStyles = function ( styles ) {
            var attrib;
            if ( styles ) {
                if ( styles.comboBoxStyles ) {
                    for ( attrib in styles.comboBoxStyles ) {
                        _styles[attrib] = styles.comboBoxStyles[attrib];
                    }
                }
                _scrollbarStyles.rx = _styles.rx;
                _scrollbarStyles['stroke-width'] = _styles['stroke-width'];
                if ( styles.normalbuttonStyles ) {
                    for ( attrib in styles.normalbuttonStyles ) {
                        _scrollbarStyles[attrib] = styles.normalbuttonStyles[attrib];
                    }
                }
                if ( styles.pressedbuttonStyles ) {
                    for ( attrib in styles.pressedbuttonStyles ) {
                        _highlightScrollbarStyles[attrib] = styles.pressedbuttonStyles[attrib];
                    }
                }
            }
            _strokeWidth = _styles['stroke-width'];
        },

        _createTextNodes = function () {
            var i, length = _options.length, createSVGElement = CPM.svgUtil.createSVG, displayText, textNode, textNodes = { nodes: [] };
            _fontProps.x = 5;
            _fontProps.y = _comboBoxDim.height / 2 + _textHeight * 0.25;
            for ( i = 0; i < length; i++ ) {
                _fontProps.optiontext = _options[i];
                textNode = createSVGElement( 'text', _fontProps );
                if ( _comboBoxDim.width < _initialOptionsWidth ) {
                    displayText = CPM.svgUtil.truncateLabel( _options[i], _optionsRectDim.width, _fontProps );
                } else {
                    displayText = _options[i];
                }
                textNode.textContent = displayText;
                textNodes.nodes.push( textNode );
                // _fontProps.y += _textHeight*0.75;
            }
            textNodes.rectHeight = _comboBoxDim.height * length;
            //_fontProps.y = _optionsRectDim.height/2 + _textHeight * 0.25;
            textNodes.selectedNode = createSVGElement( 'text', _fontProps );
            textNodes.selectedNode.textContent = CPM.svgUtil.truncateLabel( _selectedOption, _comboBoxDim.width - 40, _fontProps ); //_selectedOption;
            return textNodes;
        },
        _createComboBoxBorder = function () {
            var createSVGElement = CPM.svgUtil.createSVG;
            _comboBoxLine = createSVGElement( 'line',
                {
                    x1: _comboBoxDim.left - 0.25,
                    x2: _comboBoxDim.left + _comboBoxDim.width + 0.25,
                    y1: _comboBoxDim.top + _comboBoxDim.height,
                    y2: _comboBoxDim.top + _comboBoxDim.height,
                    stroke: _stylePropObj.ComboBox.Line,
                    'stroke-width': '2px',
                    'id': 'ComboBoxLineId',
                    'appendTo': _comboBoxGroup
                } );
        },
    /**
    * Calculates the scrollbutton geometry.
    * @function
    * @memberOf CPM.ComboBox
    * @param {x} x position of the button.
    * @param {y} y position of the button
    * @param {width} Width of button.
    * @param {height} Height of the button.
    */
        _createScrollbutton = function ( x, y, width, height ) {
            var myTriPath, triangleEigth, attrib,
                cellHeight, offsY = 0, dataTifType;

            if ( height > width ) {
                offsY = ( height - width ) / 2;
                cellHeight = width;
            }
            else {
                cellHeight = height;
            }

            //this is used to construct the triangles for the buttons
            triangleEigth = cellHeight / 8;

            dataTifType = 'LineDown';
            myTriPath = 'M' + ( x + triangleEigth * 5 ) + ' ' + ( y + offsY + triangleEigth * 3 ) +
                    ' L' + ( x + cellHeight * 0.5 ) + ' ' + ( y + offsY + 5 * triangleEigth ) +
                    ' L' + ( x + triangleEigth * 3 ) + ' ' + ( y + offsY + triangleEigth * 3 ) + ' Z';

            // rect
            _scrollRect = CPM.svgUtil.createSVG( 'rect', {
                id: _comboButtonId,
                'data-tif-type': dataTifType,
                x: x,
                y: y,
                width: width,
                height: height,
                appendTo: _comboBoxButtonGroup
            } );
            for ( attrib in _scrollbarStyles ) {
                _scrollRect.setAttributeNS( null, attrib, _scrollbarStyles[attrib] );
            }
            // triangle
            _scrollTriangle = CPM.svgUtil.createSVG( 'path', {
                d: myTriPath,
                'pointer-events': 'none',
                appendTo: _comboBoxButtonGroup
            } );
            for ( attrib in _triangleStyles ) {
                _scrollTriangle.setAttributeNS( null, attrib, _triangleStyles[attrib] );
            }
        },

    /**
    * Updates the scrollbutton geometry.
    * @function
    * @memberOf CPM.ComboBox
    * @param {x} New x position of the button.
    * @param {y} New y position of the button
    * @param {width} New width of button.
    * @param {height} New height of the button.
    */
        _updateScrollButton = function ( x, y, width, height ) {
            var myTriPath, triangleEigth, cellHeight, offsY = 0,
            setAttributes = CPM.svgUtil.setAttr;

            if ( height > width ) {
                offsY = ( height - width ) / 2;
                cellHeight = width;
            }
            else {
                cellHeight = height;
            }

            //this is used to construct the triangles for the buttons
            triangleEigth = cellHeight / 8;

            myTriPath = 'M' + ( x + triangleEigth * 5 ) + ' ' + ( y + offsY + triangleEigth * 3 ) +
            ' L' + ( x + cellHeight * 0.5 ) + ' ' + ( y + offsY + 5 * triangleEigth ) +
            ' L' + ( x + triangleEigth * 3 ) + ' ' + ( y + offsY + triangleEigth * 3 ) + ' Z';

            // rect
            setAttributes( _scrollRect, {
                x: x,
                y: y,
                width: width,
                height: height
            } );

            // triangle
            setAttributes( _scrollTriangle, {
                d: myTriPath,
                'pointer-events': 'none'
            } );
        },

    /**
    * Function that handles the scrolling of the combo box scrollbar.
    * @function
    * @memberOf CPM.ComboBox
    * @param {changeType} Type of event - scrollStart, scrollChange, scrollEnd. (Redundant in scenario.)
    * @param {absValue} Absolute value of scroller position. (Redundant in scenario.)
    * @param {percValue} Percentage value of scroller position.
    */
        _onScrollEvent = function ( changeType, absValue, percValue ) {
            var originalRange = _optionsRectDim.height,
                currentRange = _maxOptionsHeight,
                rangeDifference = originalRange - currentRange;
            self.optionsMatrix.f = -1 * rangeDifference * percValue;
            _optionsSbOffset = percValue;
        },

    /**
    * Creates/updates the clipping by creating the clipRect. ClipRect cannot be simply updated with setAttributeNS as IE doesn't update the elements linked with the clipPath.
    * @function
    * @memberOf CPM.ComboBox
    */
        _createClipping = function () {
            if ( _clipPath.lastChild ) {
                _clipPath.removeChild( _clipPath.lastChild );
            } else {
                if ( !_clipRect ) {
                    _comboBoxContentGroup.setAttributeNS( null, 'clip-path', 'url(#' + _clipPathId + ')' );
                }
            }
            _clipRect = CPM.svgUtil.createSVG( 'rect',
                    {
                        'x': _optionsRectDim.left - _strokeWidth / 2,
                        'y': _optionsRectDim.top - _strokeWidth / 2,
                        'width': _optionsRectDim.width + _strokeWidth,
                        'height': _maxOptionsHeight + _strokeWidth,
                        'appendTo': _clipPath
                    } );
        },
    /**
    * Creates vertical scrollbar for combobox when height is less than control height.
    * @function
    * @memberOf CPM.ComboBox
    */
        _createVerticalScrollBar = function () {
            var
            left = _comboBoxDim.left + _comboBoxDim.width - _stylePropObj.ScrollBar.LeftPadding,
            top = _comboBoxDim.top + _comboBoxDim.height + _stylePropObj.ScrollBar.TopPadding,
            settings = {}, totalHeight, viewPortHeight;
            totalHeight = _options.length * _comboBoxDim.height;
            viewPortHeight = _ctrlHeight - _topCbOptions;
           ////Do not create vertical scrollbar if total height of tree is within viewport height or if viewport height is lesser than the node height i.e. height of one tree node.
            if ( viewPortHeight > totalHeight ) {
                if ( _isScrollbarCreated ) {
                    _cbScrollVerticalHandler.remove();
                    _isScrollbarCreated = false;
                }
                return;
            }
            settings.currentStyle = currentStyle;
            settings.width = _stylePropObj.ScrollBar.Width;
            settings.height = viewPortHeight + 10;//offset
            settings.height = settings.height < 0 ? 0 : settings.height;
            settings.height = settings.height - _stylePropObj.ScrollBar.HeightPadding;            
            settings.id = 'cb_';
            settings.startValue = 0;
            settings.endValue = 36;
            settings.initialScrollOffset = 0;
            settings.initialHeightPerc = 1 / _options.length;
            settings.scrollStep = 1 / _options.length;
            settings.horizontalSliderHeight = _stylePropObj.ScrollBar.HorizontalSliderHeight;
            _isScrollbarCreated = true;
            _cbScrollVerticalHandler.createScrollBar( settings, left, top, _svgParent, _onScrollEvent, false, currentStyle );
        },

    /**
    * Removes clipping.
    * @function
    * @memberOf CPM.ComboBox
    */
        _removeClipping = function () {
            _comboBoxContentGroup.removeAttributeNS( null, 'clip-path' );
            _clipRect.parentNode.removeChild( _clipRect );
            _clipRect = null;
        };

    /**
    * Vertical scrollbar for combobox
    * @function
    * @memberOf CPM.ComboBox
    */
    this.cbScrollVerticalHandler = null;

    /**
    * Sets the options of the combo box if nodes are not used. (TO BE EXTENDED)
    * @function
    * @memberOf CPM.ComboBox
    * @param {options} Array of texts/strings.
    */
    this.setOptions = function ( options ) {
        _options = options;
    };

    /**
    * Returns the maximum width the combobox should have based on the longest option.
    * @function
    * @memberOf CPM.ComboBox
    */
    this.getMaxWidth = function () {
        var i, maxWidth = 0, width = 0;
        for ( i = 0; i < _options.length; i++ ) {
            width = CPM.svgUtil.getTextWidth( _fontProps, _options[i] );
            if ( width > maxWidth ) {
                maxWidth = width;
            }
        }
        return maxWidth + 45;//Including the combobox icon also.
    };

    /**
    * Sets the selected option of the combo box.
    * @function
    * @memberOf CPM.ComboBox
    * @param {option} Texts/string.
    */
    this.setSelectedOption = function ( option ) {
        var selectedNode, displayText, displayWidth;
        displayWidth = _comboBoxDim.width - 40;
        _selectedOption = option;
        _fontProps.y = _comboBoxDim.height / 2 + _textHeight * 0.25;
        _fontProps.x = 5;
        selectedNode = CPM.svgUtil.createSVG( 'text', _fontProps );
        if ( displayWidth < _initialOptionsWidth ) {
            displayText = CPM.svgUtil.truncateLabel( _selectedOption, displayWidth, _fontProps );
        }
        else {
            displayText = _selectedOption;
        }
        selectedNode.textContent = displayText;
        this.setSelectedNode( selectedNode );
    };

    /**
    * Clears the options of the combo box if nodes are not used. (TO BE EXTENDED)
    * @function
    * @memberOf CPM.ComboBox
    */
    this.clearOptions = function () {
        _options = [];
    };

    /**
    * Removes a certain option of the combo box. (TO BE EXTENDED)
    * @function
    * @memberOf CPM.ComboBox
    * @param {option} Texts/string to be removed.
    */
    this.removeOption = function ( option ) {
        var index = _options.indexOf( option );
        if ( index  > -1 ) {
            _options.splice( index, 1 );
        }
    };

    /**
    * Adds a certain option of the combo box. (TO BE EXTENDED)
    * @function
    * @memberOf CPM.ComboBox
    * @param {option} Texts/string to be removed.
    */
    this.addOption = function ( option, index ) {
        if ( _options.indexOf( option ) === -1 ) {
            if ( index === undefined || index > ( _options.length - 1 ) ) {
                _options.push( option );
            } else {
                _options.splice( index, 0, option );
            }
        }
    };

    /**
    * Set a visible row limit after which a scrollbar is to be used. (TO BE EXTENDED)
    * @function
    * @memberOf CPM.ComboBox
    * @param {visibleRowLimit} Number of rows to be visible.
    */
    this.setVisibleRowLimit = function ( visibleRowLimit ) {
        _visibleRowLimit = visibleRowLimit;
    };

    /**
    * Draws the combo box.
    * @function
    * @memberOf CPM.ComboBox
    * @param {parentNode} Parent node of the combo box.
    * @param {cbRect} Rect with coordinates of the combo box.
    * @param {optionsBottomLimit} Bottom limit till where space is available for the scrollbar to be drawn.
    */
    this.draw = function ( parentNode, cbRect, optionsBottomLimit ) {
        var createSVGElement = CPM.svgUtil.createSVG, attrib, defs;

        _svgParent = parentNode;
        _cbScrollVerticalHandler = new CPM.Control.ScrollHandler();
        this.cbScrollVerticalHandler = _cbScrollVerticalHandler;
        _comboBoxDim.left = cbRect.left;
        _comboBoxDim.top = cbRect.top;
        _comboBoxDim.height = cbRect.height;
        _comboBoxDim.width = cbRect.width;
        _initialOptionsWidth = cbRect.width;
        _ctrlHeight = cbRect.ctrlHeight;
        _topCbOptions = cbRect.topCbOptions;

        _optionsRectDim.left = cbRect.optionsLeft;
        _optionsRectDim.top = cbRect.top + cbRect.height - OPTIONS_RECT_PULLBACK;
        _optionsRectDim.width = cbRect.optionsWidth;
        _optionsRectDim.height = cbRect.height + OPTIONS_RECT_PULLBACK;

        _optionsSbTop = cbRect.top + cbRect.height;
        _optionsSbLeft = cbRect.optionsLeft + cbRect.optionsWidth - SCROLLBAR_WIDTH;

        _maxOptionsHeight = optionsBottomLimit - _optionsRectDim.top;

        _comboBoxGroup = createSVGElement( 'g', {
            'id': /*_id + */'_comboBoxElementsGroup',
            'display': _display ? 'initial' : 'none',
            'appendTo': _svgParent
        } );
        _comboBoxGroup.addEventListener( 'mouseout', self.onPointerMoveOut );

        defs = createSVGElement( 'defs' );

        _clipPath = createSVGElement( 'clipPath',
                            {
                                'id': _clipPathId,
                                'appendTo': defs
                            } );

        _svgParent.appendChild( defs );
        _comboBoxContentGroup = createSVGElement( 'g', {
            'id': _id + '_comboBoxContentGroup',
            display: 'none',
            stroke: 'none',
            'appendTo': _comboBoxGroup
        } );

        _optionsRect = createSVGElement( 'rect',
                                            {
                                                //'fill': backColor,
                                                //'fill-opacity': 1,
                                                x: _optionsRectDim.left,
                                                y: _optionsRectDim.top,
                                                height: _optionsRectDim.height,
                                                width: _optionsRectDim.width,
                                                fill: 'rgba(255,255,255,1)',
                                                stroke: 'black',
                                                'id': _optionsRectId,
                                                'appendTo': _comboBoxContentGroup
                                            } );
        for ( attrib in _styles ) {
            _optionsRect.setAttributeNS( null, attrib, _styles[attrib] );
            if( !_isExtendedStyle ){
                _optionsRect.setAttribute( 'stroke', _stylePropObj.ComboBox.OptionsStroke );
                _optionsRect.setAttribute( 'stroke-width', '1px' );
            }
        }

        // Translate group contains the elements that will move along with scrolling.
        _comboOptionsTranslateGroup = createSVGElement( 'g', {
            'id': _id + '_comboOptionsTranslateGroup',
            'transform': 'translate(0,0)',
            'appendTo': _comboBoxContentGroup
        } );
        this.optionsMatrix = _comboOptionsTranslateGroup.transform.baseVal.getItem( 0 ).matrix;
        _comboBoxRect = createSVGElement( 'rect',
                                            {
                                                //'fill': backColor,
                                                //'fill-opacity': 1,
                                                x: _comboBoxDim.left,
                                                y: _comboBoxDim.top,
                                                height: _comboBoxDim.height,
                                                width: _comboBoxDim.width,
                                                'stroke': 'black',
                                                'id': _comboRectId,
                                                'appendTo': _comboBoxGroup
                                            } );
        for ( attrib in _styles ) {
            _comboBoxRect.setAttributeNS( null, attrib, _styles[attrib] );
        }
        _selectedNodeGroup = createSVGElement( 'g', {
            'id': _id + '_SelectedNodeGroup',
            'appendTo': _comboBoxGroup
        } );
        _selctedNodeSVG = createSVGElement( 'svg', {
            'id': _id + '_SelectedNodeSVG',
            x: _comboBoxDim.left,
            y: _comboBoxDim.top,
            height: _comboBoxDim.height,
            width: _comboBoxDim.width,
            'appendTo': _selectedNodeGroup
        } );
        _cbClickableRects.selectedNode = createSVGElement( 'rect',
                                            {
                                                x: _comboBoxDim.left,
                                                y: _comboBoxDim.top,
                                                height: _comboBoxDim.height,
                                                width: _comboBoxDim.width,
                                                'stroke': 'none',
                                                'fill-opacity': 0,
                                                id: _selectedNodeId,
                                                'appendTo': _selectedNodeGroup
                                            } );
        if ( _selectedNode ) {
            while ( _selctedNodeSVG.firstChild ) {
                _selctedNodeSVG.removeChild( _selctedNodeSVG.firstChild );
            }
            _selctedNodeSVG.appendChild( _selectedNode );
        }

        _comboBoxButtonGroup = createSVGElement( 'g', {
            'id': _id + '_ComboBoxButtonGroup',
            'appendTo': _comboBoxGroup
        } );

        _createScrollbutton( cbRect.left + cbRect.width - cbRect.height, cbRect.top, cbRect.height, cbRect.height );
        if ( !_isExtendedStyle ) {
            _createComboBoxBorder();
        }
        _comboBoxOptionsGroup = createSVGElement( 'g', {
            'id': _id + '_comboBoxOptionsGroup',
            'appendTo': _comboOptionsTranslateGroup
        } );
        _cbClickableRectsGroup = createSVGElement( 'g', {
            'id': _id + '_CbClickableRectsGroup',
            'appendTo': _comboOptionsTranslateGroup
        } );
        cbRect = null;
    };

    /**
    * Updates the combo box.
    * @function
    * @memberOf CPM.ComboBox
    * @param {cbRect} Rect with coordinates of the combo box.
    * @param {optionsBottomLimit} Bottom limit till where space is available for the scrollbar to be drawn.
    * @param {updateSelectedOption} Indicates whether the current selected option of the combobox also needs to be updated.
    */
    this.update = function ( cbRect, optionsBottomLimit, updateSelectedOption ) {
        var setAttributes = CPM.svgUtil.setAttr, i, length, rectTop, rectHeight, maxOptionsHeight = _maxOptionsHeight;
        _stylePropObj = CPM.StyleFactory.getCurrentStyleProps( currentStyle );
        _isExtendedStyle = currentStyle.includes( CPM.Enums.StyleName.Extended ) ? true : false;
        if ( _comboBoxGroup.parentNode ) {
            _comboBoxGroup.parentNode.removeChild( _comboBoxGroup );
            _svgParent.appendChild( _comboBoxGroup );
        }
        _comboBoxDim.left = cbRect.left;
        _comboBoxDim.top = cbRect.top;
        _comboBoxDim.height = cbRect.height;
        _comboBoxDim.width = cbRect.width;
        //For some reason in IE, _data.Width is 0 when the control is initialized. Hence _initialOptionsWidth become a -ve value in that case in the above draw method.
        //The _initialOptionsWidth is updated again here when the resize call is received immediately after initialization. In resize call, the _data.Width value is correct.
        if ( _initialOptionsWidth < 0 ) {
            _initialOptionsWidth = cbRect.width;
        }
        _ctrlHeight = cbRect.ctrlHeight;
        _topCbOptions = cbRect.topCbOptions;

        _updateScrollButton( cbRect.left + cbRect.width - cbRect.height, cbRect.top, cbRect.height, cbRect.height );

        setAttributes( _comboBoxRect,
            {
                x: _comboBoxDim.left,
                y: _comboBoxDim.top,
                fill: _stylePropObj.ComboBox.RectColor,
                height: _comboBoxDim.height,
                width: _comboBoxDim.width
            } );
        if ( !_isExtendedStyle ) {
            setAttributes( _comboBoxLine,
            {
                x1: _comboBoxDim.left - 0.25,
                x2: _comboBoxDim.left + _comboBoxDim.width + 0.25,
                y1: _comboBoxDim.top + _comboBoxDim.height,
                y2: _comboBoxDim.top + _comboBoxDim.height,
                stroke: _stylePropObj.ComboBox.Line,
                'stroke-width': '2px'
            } );
        }
        setAttributes( _selctedNodeSVG,
            {
                x: _comboBoxDim.left,
                y: _comboBoxDim.top,
                height: _comboBoxDim.height,
                width: _comboBoxDim.width
            } );
        setAttributes( _cbClickableRects.selectedNode,
            {
                x: _comboBoxDim.left,
                y: _comboBoxDim.top,
                height: _comboBoxDim.height,
                width: _comboBoxDim.width
            } );

        _optionsRectDim.left = cbRect.optionsLeft;
        _optionsRectDim.top = cbRect.top + cbRect.height - OPTIONS_RECT_PULLBACK;
        _optionsRectDim.width = cbRect.optionsWidth;

        _optionsSbTop = cbRect.top + cbRect.height;
        _optionsSbLeft = cbRect.optionsLeft + cbRect.optionsWidth - SCROLLBAR_WIDTH;

        _maxOptionsHeight = optionsBottomLimit - _optionsRectDim.top;

        if ( _comboBoxOpen ) {
            setAttributes( _optionsRect,
            {
                x: _optionsRectDim.left,
                y: _optionsRectDim.top
            } );
            length = _svgOptionNodes.length;
            rectTop = _optionsSbTop;
            rectHeight = ( _optionsRectDim.height - OPTIONS_RECT_PULLBACK ) / length;
            for ( i = 0; i < length; i++ ) {
                setAttributes( _svgOptionNodes[i], {
                    x: _optionsRectDim.left,
                    y: rectTop
                } );
                setAttributes( _cbClickableRects.nodes[i], {
                    x: _optionsRectDim.left,
                    y: rectTop
                } );
                rectTop += rectHeight;
            }
            // If dropdown height is greater than allowed, clip contents and restrict height to maximum allowed; add scrollbar.
            if ( _maxOptionsHeight < _optionsRectDim.height ) {
                if ( maxOptionsHeight !== _maxOptionsHeight ) {
                    setAttributes( _optionsRect, {
                        height: _maxOptionsHeight
                    } );
                }
                // [NOTE]: Scrollbar is removed and created again since the update method provided does not allow for alteration of the scroller height.
                if ( _optionsSb ) {
                    _optionsSb.remove();
                    _optionsSb = null;
                }
                if ( _optionsSbOffset > 0 ) {
                    this.optionsMatrix.f = -1 * ( _optionsRectDim.height - _maxOptionsHeight ) * _optionsSbOffset;
                }
                _createVerticalScrollBar();
                //_optionsSb = new PWC.Lib.Canvas.ScrollBar( _optionsSbId, _comboBoxContentGroup, _optionsSbLeft, _optionsSbTop, SCROLLBAR_WIDTH, _maxOptionsHeight - OPTIONS_RECT_PULLBACK, 0, 500, ( _maxOptionsHeight / _optionsRectDim.height ), _optionsSbOffset, 0.1, 'top_bottom', _onScrollEvent, _scrollbarStyles.stroke );
                _createClipping();
            } else {
                if ( _optionsSb ) {
                    // If scrollbar exists when not required, remove scrollbar and set dropdown height as per calculations.
                    _optionsSb.remove();
                    _optionsSb = null;
                    this.optionsMatrix.f = 0;
                    _optionsSbOffset = 0;
                    setAttributes( _optionsRect, {
                        height: _optionsRectDim.height
                    } );
                    _removeClipping();
                }
            }
        } else {
            _optionsRectDim.height = cbRect.height + OPTIONS_RECT_PULLBACK;
            setAttributes( _optionsRect,
            {
                x: _optionsRectDim.left,
                y: _optionsRectDim.top,
                height: _optionsRectDim.height,
                width: _optionsRectDim.width
            } );
        }
        if ( updateSelectedOption ) {
            self.setSelectedOption( _selectedOption );
        }
        cbRect = null;
    };
    this.updateComboBoxStyle = function ( updatedStyle, styles ) {
        var attrib;
        currentStyle = updatedStyle;
        _stylePropObj = CPM.StyleFactory.getCurrentStyleProps( updatedStyle );
        _isExtendedStyle = updatedStyle.includes( CPM.Enums.StyleName.Extended ) ? true : false;

        _styles = {
            rx: _stylePropObj.ComboBox.Rx,
            'stroke-width': 0.5,
            stroke: _stylePropObj.ComboBox.Stroke
        };
        _scrollbarStyles = { stroke: _stylePropObj.ScrollBar.Stroke };
        _highlightScrollbarStyles = { stroke: _isExtendedStyle ? _stylePropObj.ScrollBar.ScrollerColor : 'none' };
        _triangleStyles = { fill: _stylePropObj.ComboBox.TriangleColor };

        _initializeStyles( styles );

        _fontProps.fill = _stylePropObj.ComboBox.FontColor;
        _selctedNodeSVG.firstChild.setAttribute( 'fill', _fontProps.fill );

        for ( attrib in _scrollbarStyles ) {
            if ( _scrollbarStyles.hasOwnProperty( attrib ) ) {
                _scrollRect.setAttributeNS( null, attrib, _scrollbarStyles[attrib] );
            }
        }
        for ( attrib in _triangleStyles ) {
            if ( _triangleStyles.hasOwnProperty( attrib ) ) {
                _scrollTriangle.setAttributeNS( null, attrib, _triangleStyles[attrib] );
            }
        }
        for ( attrib in _styles ) {
            if ( _styles.hasOwnProperty( attrib ) ) {
                _optionsRect.setAttributeNS( null, attrib, _styles[attrib] );
                if ( !_isExtendedStyle ) {
                    _optionsRect.setAttribute( 'x', _optionsRectDim.left );
                    _optionsRect.setAttribute( 'y', _optionsRectDim.top );
                    _optionsRect.setAttribute( 'height', _optionsRectDim.height );
                    _optionsRect.setAttribute( 'width', _optionsRectDim.width );
                    _optionsRect.setAttribute( 'stroke', _stylePropObj.ComboBox.OptionsStroke );
                    _optionsRect.setAttribute( 'stroke-width', '1px' );
                }
            }
        }
        for ( attrib in _styles ) {
            if ( _styles.hasOwnProperty( attrib ) ) {
                _comboBoxRect.setAttributeNS( null, attrib, _styles[attrib] );
            }
        }
        _comboBoxRect.setAttribute( 'fill', _stylePropObj.ComboBox.RectColor );
        if ( _comboBoxLine ) {
            _comboBoxLine.setAttribute( 'stroke', _stylePropObj.ComboBox.Line );
        } else {
            _createComboBoxBorder();
        }
    };
    /**
    * Checks if event occurred on a combo box element.
    * @function
    * @memberOf CPM.ComboBox
    * @param {targetId} Id of event's target.
    */
    this.idMatch = function ( targetId ) {
        return ( ( targetId === _comboButtonId ) || ( targetId === _comboRectId ) || ( targetId.indexOf( _clickableRectId ) > -1 ) );
    };

    /**
    * Checks if event occurred on the combo box scrollbar.
    * @function
    * @memberOf CPM.ComboBox
    * @param {targetId} Id of event's target.
    */
    this.sbIdMatch = function ( targetId ) {
        return ( targetId.indexOf( _optionsSbId ) > -1 );
    };

    /**
    * Returns the combo box scrollbar.
    * @function
    * @memberOf CPM.ComboBox
    * @returns {object} Scrollbar object.
    */
    this.getScrollBar = function () {
        return _optionsSb;
    };

    /**
    * Executes actions on the pointer down event.
    * @function
    * @memberOf CPM.ComboBox
    * @param {targetId} Id of event's target.
    * @returns {bool} State of the combo box options display.
    */
    this.onPointerDown = function ( targetId ) {
        var splitClickableId = targetId.split( _clickableRectId ), selectedIndex, attrib;
        if ( targetId === _comboButtonId || targetId === _selectedNodeId ) {
            for ( attrib in _highlightScrollbarStyles ) { // Only set the properties in _highlightScrollbarStyles which are available in _scrollbarStyles.
                if ( _scrollbarStyles.hasOwnProperty( attrib ) ) {
                    _scrollRect.removeAttributeNS( null, attrib );
                    _scrollRect.setAttributeNS( null, attrib, _highlightScrollbarStyles[attrib] );

                }
            }
        } else {
            if ( splitClickableId.length > 1 ) {
                selectedIndex = parseInt( splitClickableId[1], 0 );
                // self.setSelectedNode( _svgOptionNodes[selectedIndex].firstChild.cloneNode( true ) ); Cannot use this as the height of the combobox is not the same as height of the options. Fix the svg of selected node to the correct height ?
                _functionToCall( selectedIndex );
            }
        }
        this.toggleOptions();
        return _comboBoxOpen;
    };

    /**
    * Executes actions on the pointer up event.
    * @function
    * @memberOf CPM.ComboBox
    */
    this.onPointerUp = function () {
        var attrib;
        for ( attrib in _highlightScrollbarStyles ) {
            if ( _scrollbarStyles.hasOwnProperty( attrib ) ) {
                _scrollRect.removeAttributeNS( null, attrib );
                _scrollRect.setAttributeNS( null, attrib, _scrollbarStyles[attrib] );

            }
        }
    };

    /**
    * Executes actions on the pointer move event.
    * @function
    * @memberOf CPM.ComboBox
    * @param {targetId} Id of event's target.
    */
    this.onPointerMove = function ( targetId ) {
        var splitClickableId = targetId.split( _clickableRectId ), selectedIndex;
        if ( ( splitClickableId.length > 1 ) && targetId !== _selectedNodeId ) {
            selectedIndex = parseInt( splitClickableId[1], 0 );
            if ( _highlightedNode ) {
                if ( _highlightedNode === _cbClickableRects.nodes[selectedIndex] ) {
                    return;
                } else {
                    _highlightedNode.setAttribute( 'fill-opacity', 0 );
                    _highlightedNode = null;
                }
            }
            _highlightedNode = _cbClickableRects.nodes[selectedIndex];
            _highlightedNode.setAttribute( 'fill-opacity', 0.5 );
        } else {
            if ( _highlightedNode ) {
                _highlightedNode.setAttribute( 'fill-opacity', 0 );
                _highlightedNode = null;
            }
        }
    };

    /**
    * Executes actions on the pointer move out event.
    * @function
    * @memberOf CPM.ComboBox
    */
    this.onPointerMoveOut = function () {
        if ( _highlightedNode ) {
            _highlightedNode.setAttribute( 'fill-opacity', 0 );
            _highlightedNode = null;
        }
        CPM.Common.Tooltip.hide();
    };

    /**
    * Toggles the display/visibility of the combo box options.
    * @function
    * @memberOf CPM.ComboBox
    */
    this.toggleOptions = function () {
        if ( _comboBoxOpen ) {
            if ( !_isExtendedStyle ) {
                _comboBoxLine.setAttribute( 'y1', _comboBoxDim.top + _comboBoxDim.height );
                _comboBoxLine.setAttribute( 'y2', _comboBoxDim.top + _comboBoxDim.height );
            }
            if ( _highlightedNode ) {
                _highlightedNode.setAttribute( 'fill-opacity', 0 );
                _highlightedNode = null;
            }
            this.closeComboBox();
        } else {
            _comboBoxOpen = true;
            if ( !_isExtendedStyle ) {
                _comboBoxLine.setAttribute( 'y1', _comboBoxDim.top );
                _comboBoxLine.setAttribute( 'y2', _comboBoxDim.top );
            }
            if ( _getNodes ) {
                self.setNodes( _getNodes() );
            }
            else {
                self.setNodes( _createTextNodes() );
            }
            _comboBoxContentGroup.setAttribute( 'display', 'initial' );
            this.optionsMatrix.f = 0;
            _optionsSbOffset = 0;
        }
    };

    /**
    * Closes the combo box options.
    * @function
    * @memberOf CPM.ComboBox
    */
    this.closeComboBox = function () {
        _comboBoxOpen = false;
        if ( !_isExtendedStyle ) {
            _comboBoxLine.setAttribute( 'y1', _comboBoxDim.top + _comboBoxDim.height );
            _comboBoxLine.setAttribute( 'y2', _comboBoxDim.top + _comboBoxDim.height );
        }
        if ( _isScrollbarCreated ) {
            _cbScrollVerticalHandler.remove();
            _isScrollbarCreated = false;
        }
        if ( _optionsSb ) {
            _optionsSb.remove();
            _optionsSb = null;
        }
        if ( _clipRect ) {
            _removeClipping();
        }
        _comboBoxContentGroup.setAttribute( 'display', 'none' );
        this.optionsMatrix.f = 0;
        _optionsSbOffset = 0;
    };

    /**
    * Makes the combo box visible.
    * @function
    * @memberOf CPM.ComboBox
    */
    this.show = function () {
        _display = true;
        if ( _comboBoxGroup ) {
            _comboBoxGroup.setAttributeNS( null, 'display', 'initial' );
            this.optionsMatrix.f = 0;
            _optionsSbOffset = 0;
        }
    };

    /**
    * Hides the combo box.
    * @function
    * @memberOf CPM.ComboBox
    */
    this.hide = function () {
        _display = false;
        if ( _comboBoxOpen ) {
            this.closeComboBox();
        }
        if ( _comboBoxGroup ) {
            _comboBoxGroup.setAttributeNS( null, 'display', 'none' );
        }
    };

    /**
    * Sets the nodes of the combo box.
    * @function
    * @memberOf CPM.ComboBox
    * @param {nodeDetails} Object containing the nodes, height of the all the options to be displayed and the selected node.
    */
    this.setNodes = function ( nodeDetails ) {
        var i, length = _nodes.length, rectHeight, rectTop, createSVGElement = CPM.svgUtil.createSVG, setAttributes = CPM.svgUtil.setAttr, svgNode, drawScrollbar = false;
        for ( i = 0; i < length; i++ ) {
            if ( _nodes[i].parentNode ) {
                _nodes[i].parentNode.removeChild( _nodes[i] );
            }
        }
        if ( nodeDetails.rectHeight !== ( _optionsRectDim.height - OPTIONS_RECT_PULLBACK ) ) {
            _optionsRectDim.height = nodeDetails.rectHeight + OPTIONS_RECT_PULLBACK;
            if ( _maxOptionsHeight < _optionsRectDim.height ) {
                drawScrollbar = true;
                rectHeight = _maxOptionsHeight;
            } else {
                rectHeight = _optionsRectDim.height;
            }
            setAttributes( _optionsRect,
                {
                    height: rectHeight
                } );
        } else {
            if ( _maxOptionsHeight < _optionsRectDim.height ) {
                drawScrollbar = true;
            }
        }
        if ( drawScrollbar ) {
            if ( _optionsSb ) {
                _optionsSb.remove();
                _optionsSb = null;
            }
            _createVerticalScrollBar();
            // _optionsSb = new PWC.Lib.Canvas.ScrollBar( _optionsSbId, _comboBoxContentGroup, _optionsSbLeft, _optionsSbTop, SCROLLBAR_WIDTH, _maxOptionsHeight - OPTIONS_RECT_PULLBACK, 0, 500, ( _maxOptionsHeight / _optionsRectDim.height ), 0, 0.1, 'top_bottom', _onScrollEvent, _scrollbarStyles.stroke );
            _createClipping();
        }

        _nodes = nodeDetails.nodes;
        length = _nodes.length;
        rectHeight = ( _optionsRectDim.height - OPTIONS_RECT_PULLBACK ) / length;
        rectTop = _optionsRectDim.top + OPTIONS_RECT_PULLBACK;
        for ( i = 0; i < length; i++ ) {
            if ( _svgOptionNodes[i] ) {
                svgNode = _svgOptionNodes[i];
                setAttributes( svgNode, {
                    x: _optionsRectDim.left,
                    y: rectTop,
                    height: rectHeight,
                    width: _optionsRectDim.width,
                    id: _svgNodeId + i,
                    display: 'initial',
                    'appendTo': _comboBoxOptionsGroup
                } );
            } else {
                svgNode = createSVGElement( 'svg',
                                            {
                                                x: _optionsRectDim.left,
                                                y: rectTop,
                                                height: rectHeight,
                                                width: _optionsRectDim.width,
                                                id: _svgNodeId + i,
                                                'appendTo': _comboBoxOptionsGroup
                                            } );
                _svgOptionNodes.push( svgNode );
            }
            svgNode.appendChild( _nodes[i] );
            if ( _cbClickableRects.nodes[i] ) {
                setAttributes( _cbClickableRects.nodes[i], {
                    x: _optionsRectDim.left,
                    y: rectTop,
                    height: rectHeight,
                    width: _optionsRectDim.width,
                    id: _clickableRectId + i,
                    display: 'initial',
                    'appendTo': _cbClickableRectsGroup
                } );
            } else {
                _cbClickableRects.nodes.push( createSVGElement( 'rect',
                                            {
                                                x: _optionsRectDim.left,
                                                y: rectTop,
                                                height: rectHeight,
                                                width: _optionsRectDim.width,
                                                'stroke': 'none',
                                                'fill-opacity': 0,
                                                fill: _stylePropObj.ComboBox.ClickableRect,
                                                id: _clickableRectId + i,
                                                'appendTo': _cbClickableRectsGroup
                                            } ) );
            }
            rectTop += rectHeight;

        }
        while ( length < _comboBoxOptionsGroup.childNodes.length ) {
            _comboBoxOptionsGroup.removeChild( _comboBoxOptionsGroup.lastChild );
            length++;
        }
        length = _nodes.length;
        while ( length < _cbClickableRectsGroup.childNodes.length ) {
            _cbClickableRectsGroup.removeChild( _cbClickableRectsGroup.lastChild );
            length++;
        }
        if ( nodeDetails.selectedNode ) {
            this.setSelectedNode( nodeDetails.selectedNode );
        }
    };

    /**
    * Sets the selected node of the combo box.
    * @function
    * @memberOf CPM.ComboBox
    * @param {selectedNode} The group containing the selected node.
    */
    this.setSelectedNode = function ( selectedNode ) {
        _selectedNode = selectedNode;
        if ( _selctedNodeSVG ) {
            while ( _selctedNodeSVG.firstChild ) {
                _selctedNodeSVG.removeChild( _selctedNodeSVG.firstChild );
            }
            _selctedNodeSVG.appendChild( _selectedNode );
        }
    };

    /**
    * Cleans up the combo box.
    * @function
    * @memberOf CPM.ComboBox
    */
    this.cleanUp = function () {
        while ( _svgParent && _svgParent.lastChild ) {
            _svgParent.removeChild( _svgParent.lastChild );
        }
        _cbClickableRects.selectedNode =
        _cbClickableRects.nodes = null;
        this.optionsMatrix =
        _svgParent =
        _functionToCall =
        _getNodes =
        _options =
        _comboBoxGroup =
        _comboBoxButtonGroup =
        _selectedNodeGroup =
        _comboBoxOptionsGroup =
        _comboBoxContentGroup =
        _comboOptionsTranslateGroup =
        _cbClickableRectsGroup =
        _clipPath =
        _clipRect =
        _selctedNodeSVG =
        _selectedNode =
        _highlightedNode =
        _comboBoxRect =
        _comboBoxLine =
        _optionsRect =
        _optionsRectDim =
        _nodes =
        _svgOptionNodes =
        _cbClickableRects =
        _optionsSb =
        self = null;
    };

    _initializeStyles( comboBoxStyles );
};
var CPM = ( CPM || {} );

CPM.EventManager = function ( parentSvg, eventHandlers, divParent ) {
    'use strict';
    /**
    * Private members.
    */
    var
    /**    
    * @memberOf CPM.Control.EventManager
    * If data is cleaned and gridModel changed before Hammer is loaded, that particular instance of Hammer manager will not be cleared. This flag keeps track of whether hammer instance to be ignored or not.
    */
     _loadHammerEvents = true,
    /**    
    * @memberOf CPM.Control.EventManager
    * Holds information of touch enable for device or not
    */
    _isTouchEnabled = false,
    /**    
    * @memberOf CPM.Control.EventManager
    * Holds reference to area parent
    */
    _areaParent,
     /**    
    * @memberOf CPM.Control.EventManager
    * Holds recent mouse position on mouse move
    */
    _mousPosWrtParentSvg = null,
    /**    
    * @memberOf PWC.Components.Grid.EventManager
    * Holds reference of hammer instance
    */
    _hammerObj = null,
    /**    
    * @memberOf PWC.Components.Grid.EventManager
    * Holds information about pan started or not
    */
    _isPanStarted = false,
    /**    
    * @memberOf PWC.Components.Grid.EventManager
    * Holds information about mouse down state
    */
    _isMouseDown = false,
    /* @memberOf PWC.Components.Grid.EventManager
    * Holds information about mouse down state
    */
    _isMouseRelease = true,
    /**
    /**    
    * @memberOf PWC.Components.Grid.EventManager
    * Holds information about target group
    */
    _targetGroup = null,
     /**    
    * @memberOf PWC.Components.Grid.EventManager
    * Act as timer to skip few pan events on scroll in touch devices
    */
    _timesVPanEvtFired = 0,
    _timesHPanEvtFired = 0,
    _prevPanEvent = null,
    _currPanEvent = null,
    _timesBCPanEvtFired = 0,
    _prevBCPanEvent = null,
    _currBCPanEvent = null,
    _timesCBPanEvtFired = 0,
    _prevCBPanEvent = null,
    _currCBPanEvent = null,
     /**    
    * @memberOf PWC.Components.Grid.EventManager
    * Holds reference to target node
    */
    _targetNode = null,
    /**    
    * @memberOf PWC.Components.Grid.EventManager
    * Holds touch start coordinates. In touch devices touch end coordinates are not coming. use same coordinates for handling row/cell selection
    */
    _touchStartCoordinates,
   _comboBoxStates = { open: false, clicked: false }, // Object of combo box flags to track its state.

   _isComboBoxClicked = false,

     /*
    * Add event listeners to calendar control components
    * @function
    * @memberOf CPM.Control.EventManager
    */
    _addEventListeners = function () {
        //_areaParent = calenderArea.getAreaParent(); 
        divParent.addEventListener( 'mousedown', _eventHandler );
        parentSvg.addEventListener( 'mouseup', _eventHandler );
        parentSvg.addEventListener( 'mouseover', _eventHandler );
        divParent.addEventListener( 'mousemove', _eventHandler );
        parentSvg.addEventListener( 'mouseleave', _eventHandler );
        parentSvg.addEventListener( 'contextmenu', _handleContextMenu );
        divParent.addEventListener( 'touchstart', _eventHandler );
        parentSvg.addEventListener( 'touchend', _eventHandler );
        divParent.addEventListener( 'mousewheel', _mouseWheelScroll );
        divParent.addEventListener( 'DOMMouseScroll', _mouseWheelScroll );
        document.body.addEventListener( 'keydown', _handleKeyDown );
        divParent.addEventListener( 'keyup', _handleKeyUp );
        //if ( calenderArea ) {
        //    calenderArea.attachMouseWheelEvent();
        //}
        _addHammerEvents();
        //_isPanEventsAllowedOnShift = viewDefaultProps.areaSettings.isShiftModificationAllowed;
    },
    /*
    * Add hammer event listeners to calendar control components
    * @function
    * @memberOf CPM.Control.EventManager
    */
    _addHammerEvents = function () {
        // require( ['Hammer'], function ( hammer ) {
        var hammer = Hammer;
        if ( parentSvg && _loadHammerEvents ) {
            _hammerObj = new hammer.Manager( parentSvg, { domEvents: true } );
            _hammerObj.add( new hammer.Tap( { event: 'doubletap', taps: 2 } ) );
            _hammerObj.add( new hammer.Tap( { event: 'singletap', taps: 1 } ) );
            _hammerObj.get( 'doubletap' ).recognizeWith( 'singletap' );
            _hammerObj.get( 'singletap' ).requireFailure( 'doubletap' );
            _hammerObj.on( 'doubletap', _doubleClickHandler );
            _hammerObj.on( 'singletap', _singleClickHandler );
            _hammerObj.add( new hammer.Pan( { event: 'pan', pointers: 1, direction: hammer.DIRECTION_ALL, threshold: 1 } ) );
            _hammerObj.on( 'panstart', _panEventHandler );
            _hammerObj.on( 'panup', _panEventHandler );
            _hammerObj.on( 'pandown', _panEventHandler );
            _hammerObj.on( 'panleft', _panEventHandler );
            _hammerObj.on( 'panright', _panEventHandler );
            _hammerObj.on( 'panend', _panEventHandler );
        }
        // } );
    },
    /*
    * Remove event listeners from calendar control components
    * @function
    * @memberOf CPM.Control.EventManager
    */
    _removeEventListeners = function () {
        divParent.removeEventListener( 'mousedown', _eventHandler );
        parentSvg.removeEventListener( 'mouseup', _eventHandler );
        parentSvg.removeEventListener( 'mouseover', _eventHandler );
        divParent.removeEventListener( 'mousemove', _eventHandler );
        parentSvg.removeEventListener( 'mouseleave', _eventHandler );
        parentSvg.removeEventListener( 'contextmenu', _handleContextMenu );
        divParent.removeEventListener( 'touchstart', _eventHandler );
        parentSvg.removeEventListener( 'touchend', _eventHandler );
        divParent.removeEventListener( 'mousewheel', _mouseWheelScroll );
        divParent.removeEventListener( 'DOMMouseScroll', _mouseWheelScroll );
        document.body.removeEventListener( 'keydown', _handleKeyDown );
        divParent.removeEventListener( 'keyup', _handleKeyUp );
        if ( _hammerObj ) {
            _hammerObj.off( 'doubletap' );
            _hammerObj.off( 'singletap' );
            _hammerObj.remove( 'doubletap' );
            _hammerObj.remove( 'singletap' );
            _hammerObj.off( 'panstart' );
            _hammerObj.off( 'panup' );
            _hammerObj.off( 'pandown' );
            _hammerObj.off( 'panleft' );
            _hammerObj.off( 'panright' );
            _hammerObj.off( 'panend' );
            _hammerObj.remove( 'pan' );
            _hammerObj.destroy();
            _hammerObj = null;
        } else {
            _loadHammerEvents = false;
        }
    },
    /*
    * disable contextmenu on right click
    * @function
    * @memberOf CPM.Control.EventManager
    * @params{evt}eventObject
    */
    _handleContextMenu = function ( evt ) {
        _targetGroup = null;
        _targetNode = null;
        evt.stopPropagation();
        evt.preventDefault();
        return false;
    },
    /* 
    * Registered as a call back for mousedown,mouseup,touchstart and touchend events
    * @function
    * @memberOf CPM.Control.EventManager
    * @params{evt}eventObject
    */
    _eventHandler = function ( evt ) { 
        if ( evt.type === 'touchstart' || evt.type === 'touchend' ) {
            if ( !_isTouchEnabled ) {
                _isTouchEnabled = true;
            }
            _routeEvent( evt );
        }

        if ( !_isTouchEnabled ) {
            if ( evt.type === 'mousedown' || evt.type === 'mouseup' ) {
                _routeEvent( evt );
            }
            else if ( evt.type === 'mouseover' || evt.type === 'mouseleave' ) {
                _routeEvent( evt );
            }
            else {
                if ( evt.type === 'mousemove' ) {
                    _routeEvent( evt );
                }
            }
        }
    },
    /* 
    * validates event target
    * @function
    * @memberOf CPM.Control.EventManager
    * @params{evt}eventObject
    */
    _validateEventTarget = function ( evt ) {
        var fireEvent = null;
        if ( _targetGroup === null ) {
            fireEvent = _setEventSourceGroup( evt );
        }
        return fireEvent;
    },
    /* 
    * Sets event source group based on mouse position wrto SVG
    * @function
    * @memberOf CPM.Control.EventManager
    * @params{evt}eventObject
    * @params{mousePos}mouse position
    */
    _setEventSourceGroup = function ( evt ) {
        var target = evt.target || evt.srcElement;
        if ( target && ( target.tagName === 'path' || target.tagName === 'rect' ) && target.id.indexOf( 'traverseToParentIcon' ) !== -1 ) {
            _targetGroup = CPM.Enums.EventTarget.TraverseToParent;
            _targetNode = target;
        }
        if ( target && ( target.tagName === 'path' || target.tagName === 'rect' ) && target.id.indexOf( 'expandCollapseIcon' ) !== -1 ) {
            _targetGroup = CPM.Enums.EventTarget.ExpandCollapse;
            _targetNode = target;
        }
        else if ( ( target && target.tagName === 'rect' && target.id.indexOf( 'nodeBgRect' ) !== -1 ) || ( target && target.tagName === 'text' && target.id.indexOf( 'nodeText' ) !== -1 ) ) {
            _targetGroup = CPM.Enums.EventTarget.NodeTextRect;
            _targetNode = target;
        }
        else if ( target && target.tagName === 'rect' && target.id.indexOf( '_hScrollbar' ) !== -1 ) {
            _targetGroup = CPM.Enums.EventTarget.HScrollBar;
            _targetNode = target;
        }
        else if ( target && target.tagName === 'rect' && target.id.indexOf( 'tree_vScrollbar' ) !== -1 ) {
            _targetGroup = CPM.Enums.EventTarget.VScrollBar;
            _targetNode = target;
        }
        else if ( target && target.tagName === 'rect' && target.id.indexOf( 'bc_vScrollbar' ) !== -1 ) {
            _targetGroup = CPM.Enums.EventTarget.BCVScrollBar;
            _targetNode = target;
        }
        else if ( target && target.tagName === 'rect' && target.id.indexOf( 'cb_vScrollbar' ) !== -1 ) {
            _targetGroup = CPM.Enums.EventTarget.CBVScrollBar;
            _targetNode = target;
        }
        else if ( target && target.tagName === 'rect' && target.id.indexOf( '_slider' ) !== -1 ) {
            _targetGroup = CPM.Enums.EventTarget.Slider;
            _targetNode = target;
        }
        else if ( target && target.tagName === 'svg' && target.id.indexOf( 'Main_SVG' ) !== -1 ) {
            _targetGroup = CPM.Enums.EventTarget.MainSvg;
            _targetNode = target;
        }
        else if ( ( target && target.tagName === 'g' || target && target.tagName === 'svg' || target && target.tagName === 'path' || target && target.tagName === 'rect' ) && target.id.indexOf( 'summaryAlarm' ) !== -1 ) {
            _targetGroup = CPM.Enums.EventTarget.SummaryAlarm;
            _targetNode = target;
        }
        else if ( target && ( target.tagName === 'g' || target.tagName === 'svg' || target.tagName === 'path' || target.tagName === 'rect' ) && target.id.indexOf( 'NodeImage' ) !== -1 ) {
            _targetGroup = CPM.Enums.EventTarget.BCNodeImage;
            _targetNode = target;
        }
        else if ( target && ( target.tagName === 'g' || target.tagName === 'svg' || target.tagName === 'path' || target.tagName === 'rect' ) && target.id.indexOf( 'StartImage' ) !== -1 ) {
            _targetGroup = CPM.Enums.EventTarget.BCStartImage;
            _targetNode = target;
        }
        else if ( target && ( target.tagName === 'g' || target.tagName === 'text' || target.tagName === 'rect' ) && target.id.indexOf( 'NodeText' ) !== -1 ) {
            _targetGroup = CPM.Enums.EventTarget.BCNodeText;
            _targetNode = target;
        }
        else if ( target && ( target.tagName === 'g' || target.tagName === 'svg' || target.tagName === 'text' || target.tagName === 'rect' || target.tagName === 'path' ) && target.id.indexOf( 'crumbGroup' ) !== -1 ) {
            _targetGroup = CPM.Enums.EventTarget.CrumbGroup;
            _targetNode = target;
        }
        else if ( target && ( target.tagName === 'g' || target.tagName === 'svg' || target.tagName === 'polygon' || target.tagName === 'rect' ) && target.id.indexOf( 'ExpandAll' ) !== -1 ) {
            _targetGroup = CPM.Enums.EventTarget.ExpandAllButton;
            _targetNode = target;
        }
        else if ( target && ( target.tagName === 'g' || target.tagName === 'svg' || target.tagName === 'polygon' || target.tagName === 'rect' ) && target.id.indexOf( 'CollapseAll' ) !== -1 ) {
            _targetGroup = CPM.Enums.EventTarget.CollapseAllButton;
            _targetNode = target;
        }
        else if ( target && ( target.tagName === 'g' || target.tagName === 'svg' || target.tagName === 'polygon' || target.tagName === 'rect' ) && target.id.indexOf( 'FilterButton' ) !== -1 ) {
            _targetGroup = CPM.Enums.EventTarget.SearchComboBox;
            _targetNode = target;
        }
        else if ( target && ( target.tagName === 'g' || target.tagName === 'svg' || target.tagName === 'path' || target.tagName === 'rect' || target.tagName === 'polygon' ) && target.id.indexOf( 'treeGroup' ) !== -1 ) {
            _targetGroup = CPM.Enums.EventTarget.TreeGroupScroll;
            _targetNode = target;
        }
        else if ( target && ( target.tagName === 'g' || target.tagName === 'text' || target.tagName === 'path' || target.tagName === 'rect' ) && target.id.indexOf( 'breadcrumbGroup' ) !== -1 ) {
            _targetGroup = CPM.Enums.EventTarget.BreadCrumbScroll;
            _targetNode = target;
        }
        else if ( target && ( target.tagName === 'g' || target.tagName === 'text' || target.tagName === 'path' || target.tagName === 'rect' ) && target.id.indexOf( '_comboBoxElementsGroup' ) !== -1 ) {
            _targetGroup = CPM.Enums.EventTarget.ComboBoxScroll;
            _targetNode = target;
        }
        else if ( target && target.tagName === 'INPUT' && target.id.indexOf( 'searchBox' ) !== -1 ) {
            _targetGroup = CPM.Enums.EventTarget.SearchInputBox;
            _targetNode = target;
        }
        else if ( target && ( target.tagName === 'path' || target.tagName === 'rect' || target.tagName === 'svg' ) && target.id.indexOf( '_closeIcon' ) !== -1 ) {
            _targetGroup = CPM.Enums.EventTarget.ClearSearchText;
            _targetNode = target;
        }
        else if ( target && ( target.tagName === 'path' || target.tagName === 'rect' || target.tagName === 'svg' ) && target.id.indexOf( '_searchIcon' ) !== -1 ) {
            _targetGroup = CPM.Enums.EventTarget.SearchForText;
            _targetNode = target;
        } 
        else if ( target && target.tagName === 'rect' && target.id.indexOf( 'overlayBreadCrumbRect' ) !== -1 ) {
            _targetGroup = CPM.Enums.EventTarget.BCOverlay;
            _targetNode = target;
        }
        else {
            if ( eventHandlers.filterComboBox && eventHandlers.filterComboBox.idMatch( target.id ) ) {
                _targetGroup = CPM.Enums.EventTarget.FilterComboBox;
                _targetNode = target;
            }
        }
    },
     //_getMousePos = function ( evt ) {
     //    var point = {};
     //    if ( evt.changedTouches ) {
     //        point.x = evt.changedTouches[0].clientX;
     //        point.y = evt.changedTouches[0].clientY;
     //    } else {
     //        point.x = evt.clientX;
     //        point.y = evt.clientY;
     //    }
     //    return point;
     //},
    /*
    * Function to close combobox if it was in opened state
    */
    _closeComboBox = function () {
        if ( _comboBoxStates.open ) {
            eventHandlers.filterComboBox.onPointerUp(); //Set the combobox button to normal state
            eventHandlers.filterComboBox.closeComboBox();
            _comboBoxStates.open = false;
        }
    },

    /*
    * Function to handle scrollbar events
    * @function
    * @memberOf CPM.Control.EventManager
    * @params{mousePosWrtParentSvg} MousePoint with respect to parent SVG
    * @param {EventObject} evt
    */
    _handleScrollBarEvent = function ( mousePosWrtParentSvg, evt ) {
        var isHandled = true;

        if ( _targetGroup === CPM.Enums.EventTarget.HScrollBar ) {
            eventHandlers.handleHScrollBar( mousePosWrtParentSvg, _targetGroup, evt, _targetNode );
            //calenderArea.hScrollHandler.onScrollClickEvent( mousePosWrtParentSvg, _targetGroup, evt, _targetNode );
            //CPM.Layout.StatusBar.toggleStatusBarOff();
        }
        else if ( _targetGroup === CPM.Enums.EventTarget.VScrollBar ) {
            eventHandlers.handleVScrollBar( mousePosWrtParentSvg, _targetGroup, evt, _targetNode );
        }
        else if ( _targetGroup === CPM.Enums.EventTarget.BCVScrollBar ) {
            eventHandlers.handleBCVScrollBar( mousePosWrtParentSvg, _targetGroup, evt, _targetNode );
        }
        else if ( _targetGroup === CPM.Enums.EventTarget.CBVScrollBar ) {
            eventHandlers.handleCBVScrollBar( mousePosWrtParentSvg, _targetGroup, evt, _targetNode );
        }
        else {
            isHandled = false;
        }

        return isHandled;
    },
    /*
    * Handles left click of mouse
    * @param {evt} eventObject
    */
    _onLeftMouseClick = function ( evt ) {
        var mousePosWrtParentSvg = _mousPosWrtParentSvg, node;
        _validateEventTarget( evt );
        if ( _targetGroup === CPM.Enums.EventTarget.HScrollBar ) {
            eventHandlers.handleHScrollBar( mousePosWrtParentSvg, _targetGroup, evt, _targetNode );
            _closeComboBox();
        }
        else if ( _targetGroup === CPM.Enums.EventTarget.VScrollBar ) {
            eventHandlers.handleVScrollBar( mousePosWrtParentSvg, _targetGroup, evt, _targetNode );
            _closeComboBox();
        }
        else if ( _targetGroup === CPM.Enums.EventTarget.BCVScrollBar ) {
            eventHandlers.handleBCVScrollBar( mousePosWrtParentSvg, _targetGroup, evt, _targetNode );
            _closeComboBox();
        }
        else if ( _targetGroup === CPM.Enums.EventTarget.CBVScrollBar ) {
            eventHandlers.handleCBVScrollBar( mousePosWrtParentSvg, _targetGroup, evt, _targetNode );
        }
        else if ( _targetGroup === CPM.Enums.EventTarget.BCNodeImage ) {
            eventHandlers.displayImmediateChildren( '', _targetNode, true );
            eventHandlers.setBgColor( evt.type, _targetNode );
            _closeComboBox();
        }
        else if ( _targetGroup === CPM.Enums.EventTarget.BCNodeText || _targetGroup === CPM.Enums.EventTarget.BCStartImage ) {
            node = eventHandlers.getBCNode( _targetNode );
            eventHandlers.onURLClick( node );
            if ( _targetGroup === CPM.Enums.EventTarget.BCStartImage ) {
                eventHandlers.setBgColor( evt.type, _targetNode );
            }
            _closeComboBox();
        }
        else if ( _targetGroup === CPM.Enums.EventTarget.SummaryAlarm ) {
            node = eventHandlers.getNodeData( _targetNode );
            if ( node ) {
                eventHandlers.sendSummaryInfo( node );
                eventHandlers.selectNode( node, false, false );
            }
            _closeComboBox();
        }
        else if ( _targetGroup === CPM.Enums.EventTarget.ExpandCollapse ) {
            node = eventHandlers.getNodeData( _targetNode );
            if ( node ) {
                eventHandlers.toggleVisibility( node, undefined, false );
            }
            _closeComboBox();
        }
        else if ( _targetGroup === CPM.Enums.EventTarget.CrumbGroup ) {
            node = eventHandlers.getCrumbNode( _targetNode );
            eventHandlers.setSelectedFromBC( node );
            _closeComboBox();
        }
        else if ( _targetGroup === CPM.Enums.EventTarget.FilterComboBox ) {
            _isComboBoxClicked = true;
            if ( _comboBoxStates.clicked && _comboBoxStates.open ) {
                _comboBoxStates.open = eventHandlers.filterComboBox.onPointerDown( _targetNode.id );
                eventHandlers.filterComboBox.onPointerUp();//Set the combobox button to normal state when the combobox is closed
                _comboBoxStates.clicked = false;
            } else {
                _comboBoxStates.open = eventHandlers.filterComboBox.onPointerDown( _targetNode.id );
                _comboBoxStates.clicked = true;
            }
        }
        else if ( _targetGroup === CPM.Enums.EventTarget.ExpandAllButton ) {
            eventHandlers.expandAll();
            eventHandlers.updateToolbarColor( evt );
            _closeComboBox();
        }
        else if ( _targetGroup === CPM.Enums.EventTarget.CollapseAllButton ) {
            eventHandlers.collapseAll();
            eventHandlers.updateToolbarColor( evt );
            _closeComboBox();
        }
        else if ( _targetGroup === CPM.Enums.EventTarget.SearchComboBox ) {
            eventHandlers.toggleFilterButton();
            eventHandlers.updateToolbarColor( evt );
            _closeComboBox();
        }
        else if ( _targetGroup === CPM.Enums.EventTarget.ClearSearchText ) {
            eventHandlers.clearSearch( false );
        }
        else if ( _targetGroup === CPM.Enums.EventTarget.SearchForText ) {
            eventHandlers.searchForText( true );
        }
        else {
            if ( _targetGroup !== CPM.Enums.EventTarget.CBVScrollBar ) {
                _closeComboBox();
            }
        }
        if ( _isTouchEnabled ) {
            _touchStartCoordinates = mousePosWrtParentSvg;
        }
        _isMouseDown = true;
    },
    /* 
    *routes event based on event type and based on validation
    * @function
    * @memberOf CPM.Control.EventManager
    * @params{evt}eventObject
    */
    _routeEvent = function ( evt ) {
        var mousePosWrtParentSvg = CPM.svgUtil.getMousePoint( evt, parentSvg ), node;
        _mousPosWrtParentSvg = mousePosWrtParentSvg;
        switch ( evt.type ) {
            case 'mousedown':
            case 'touchstart':
                _isMouseRelease = false;
                if ( evt.type === 'mousedown' && ( evt.which === 3 || evt.button === 1 ) ) {// Handle Right mouse Click
                    return;
                }
                else {
                    _onLeftMouseClick( evt );
                }
                _targetGroup = null;
                _targetNode = null;
                break;
            case 'mouseup':
            case 'touchend':
                _isMouseRelease = true;
                if ( _isPanStarted ) {
                    _isPanStarted = false;
                }
                else {
                    _validateEventTarget( evt );
                    if ( !_handleScrollBarEvent( mousePosWrtParentSvg, evt ) ) {
                        if ( _targetGroup === CPM.Enums.EventTarget.BCNodeImage ) {
                            eventHandlers.displayImmediateChildren( '', _targetNode, true );
                            eventHandlers.setBgColor( evt.type, _targetNode );
                        }
                        else if ( _targetGroup === CPM.Enums.EventTarget.BCNodeText || _targetGroup === CPM.Enums.EventTarget.BCStartImage ) {
                            node = eventHandlers.getBCNode( _targetNode );
                            eventHandlers.onURLClick( node );
                        }
                        else if ( _targetGroup === CPM.Enums.EventTarget.ExpandAllButton ) {
                            eventHandlers.updateToolbarColor( evt );
                            eventHandlers.expandAll();
                        }
                        else {
                            if ( _targetGroup === CPM.Enums.EventTarget.CollapseAllButton ) {
                                eventHandlers.updateToolbarColor( evt );
                                eventHandlers.collapseAll();
                        }
                    }
                }
                    _targetGroup = null;
                    _targetNode = null;
            }
                _isMouseDown = false;

                break;
            case 'mouseover':
                _validateEventTarget( evt );
                if ( _targetGroup === CPM.Enums.EventTarget.BCNodeImage || _targetGroup === CPM.Enums.EventTarget.BCStartImage ) {
                    eventHandlers.setBgColor( evt.type, _targetNode );
                    if ( _targetNode.id.indexOf( '_NodeText' ) !== -1 ) {
                        eventHandlers.displayImmediateChildren( '', _targetNode );
                }
                }
                else if ( _targetGroup === CPM.Enums.EventTarget.ExpandAllButton || _targetGroup === CPM.Enums.EventTarget.CollapseAllButton || _targetGroup === CPM.Enums.EventTarget.SearchComboBox ) {
                    eventHandlers.updateToolbarColor( evt );
                }
                else if ( _targetGroup !== CPM.Enums.EventTarget.BreadCrumbScroll || _targetGroup !== CPM.Enums.EventTarget.CrumbGroup ) {
                    eventHandlers.unloadBreadCrumb();
                }
                else {
                    if ( ( !_isMouseRelease && _targetGroup === CPM.Enums.EventTarget.HScrollBar ) || ( !_isMouseRelease && _targetGroup === CPM.Enums.EventTarget.VScrollBar ) || ( !_isMouseRelease && _targetGroup === CPM.Enums.EventTarget.BCVScrollBar ) || ( !_isMouseRelease && _targetGroup === CPM.Enums.EventTarget.CBVScrollBar ) ) {
                        _isMouseRelease = true;
                }
            }
                _targetGroup = null;
                break;
            case 'mousemove':
                _validateEventTarget( evt );
                if ( !_isMouseRelease && _targetGroup === CPM.Enums.EventTarget.VScrollBar ) {
                    eventHandlers.handleVScrollBar( mousePosWrtParentSvg, _targetGroup, evt, _targetNode );
                }
                else if ( !_isMouseRelease && _targetGroup === CPM.Enums.EventTarget.BCVScrollBar ) {
                    eventHandlers.handleBCVScrollBar( mousePosWrtParentSvg, _targetGroup, evt, _targetNode );
                }
                else if ( !_isMouseRelease && _targetGroup === CPM.Enums.EventTarget.CBVScrollBar ) {
                    eventHandlers.handleCBVScrollBar( mousePosWrtParentSvg, _targetGroup, evt, _targetNode );
                }
                else if ( !_isMouseRelease && _targetGroup === CPM.Enums.EventTarget.HScrollBar ) {
                    eventHandlers.handleHScrollBar( mousePosWrtParentSvg, _targetGroup, evt, _targetNode );
                }
                else if ( _targetGroup === CPM.Enums.EventTarget.SearchInputBox ) {
                    eventHandlers.showInputTextToolTip( _getMousePos() );
                }
                else if ( _targetGroup === CPM.Enums.EventTarget.BCOverlay ) {
                    eventHandlers.unloadBreadCrumb();
                }
                else {
                    if ( _targetGroup === CPM.Enums.EventTarget.FilterComboBox ) {
                        eventHandlers.filterComboBox.onPointerMove( _targetNode.id );
                        eventHandlers.showToolTip( _targetNode, _getMousePos( evt ) );
                }
            }
                _targetGroup = null;
                break;
            case 'mouseleave':
                _validateEventTarget( evt );
               if ( _targetGroup === CPM.Enums.EventTarget.MainSvg ) {
                    eventHandlers.updateNodeImage();
                    _closeComboBox();
               }
               else {
                    if ( _targetGroup === CPM.Enums.EventTarget.BCNodeImage ) {
                        eventHandlers.setBgColor( evt.type, _targetNode );
               }
            }
                _targetGroup = null;
                break;
            default:
                break;
        }
    },
        /*
        * Handles scroll events 
        * @param {currPanEvent} currentPanEvent object
        * @param {timesPanEvtFired} timesPanEventFired object
        */
    _scrollbarHandler = function ( currPanEvent, timesPanEvtFired ) {
        var swipeVelocity, length;
        swipeVelocity = Math.abs( currPanEvent.overallVelocity );
        //If swipe velocity is more than 1, then scroll in the respective direction 3 times
        if ( swipeVelocity > 1 ) {
            length = Math.floor( swipeVelocity * 3 );
            for ( var i = 0; i < length; i++ ) {
                _fireEvent( currPanEvent, _targetGroup );
        }
            return;
    }
        if ( currPanEvent.type === CPM.Enums.EventType.panup || currPanEvent.type === CPM.Enums.EventType.pandown ) {
            if ( timesPanEvtFired < 5 ) {
                timesPanEvtFired++;
            } else {
                if ( timesPanEvtFired === 5 ) {
                    _scrollOnPan( _targetGroup );
            }
        }
        } else {
            if ( currPanEvent.type === CPM.Enums.EventType.panleft || currPanEvent.type === CPM.Enums.EventType.panright ) {
                if ( timesPanEvtFired < 5 ) {
                    timesPanEvtFired++;
                } else {
                    if ( timesPanEvtFired === 5 ) {
                        _scrollOnPan( CPM.Enums.EventTarget.TreeGroupScroll );
                }
            }
        }
    }
    },
        /*
        * Registered as a callback for pan events
        * @param {EventObject} evt
        */
    _panEventHandler = function ( evt ) {
        var mousePosWrtParentSvg = CPM.svgUtil.getMousePoint( evt, parentSvg );
        if ( evt.type === CPM.Enums.EventType.panstart ) {
            _isPanStarted = true;
    }
        evt.preventDefault();

        if ( _isPanStarted && ( evt.type === CPM.Enums.EventType.panstart || evt.type === CPM.Enums.EventType.panleft || evt.type === CPM.Enums.EventType.panright || evt.type === CPM.Enums.EventType.panup || evt.type === CPM.Enums.EventType.pandown ) ) {

            if ( !_handleScrollBarEvent( mousePosWrtParentSvg, evt ) ) {
                if ( _targetGroup === CPM.Enums.EventTarget.TreeGroupScroll || _targetGroup === CPM.Enums.EventTarget.ExpandCollapse || _targetGroup === CPM.Enums.EventTarget.NodeTextRect ) {
                    _currPanEvent = evt;
                    _scrollbarHandler( _currPanEvent, _timesHPanEvtFired );
                }
                else if ( _targetGroup === CPM.Enums.EventTarget.BreadCrumbScroll ) {
                    _currBCPanEvent = evt;
                    _scrollbarHandler( _currBCPanEvent, _timesBCPanEvtFired );
                }
                else {
                    if ( _targetGroup === CPM.Enums.EventTarget.ComboBoxScroll ) {
                        _currCBPanEvent = evt;
                        _scrollbarHandler( _currCBPanEvent, _timesCBPanEvtFired );
                }
            }
        }
        }

        else {
            if ( evt.type === CPM.Enums.EventType.panend ) {

                if ( !_handleScrollBarEvent( mousePosWrtParentSvg, evt ) ) {
                    if ( _targetGroup === CPM.Enums.EventTarget.TreeGroupScroll || _targetGroup === CPM.Enums.EventTarget.ExpandCollapse || _targetGroup === CPM.Enums.EventTarget.NodeTextRect ) {
                        _currPanEvent = _prevPanEvent = null;
                        _timesVPanEvtFired = 0;
                        _timesHPanEvtFired = 0;
                    }
                    else if ( _targetGroup === CPM.Enums.EventTarget.BreadCrumbScroll ) {
                        _timesBCPanEvtFired = 0;
                        _prevBCPanEvent = _currBCPanEvent = null;
                    }
                    else {
                        if ( _targetGroup === CPM.Enums.EventTarget.ComboBoxScroll ) {
                            _timesCBPanEvtFired = 0;
                            _prevCBPanEvent = _currCBPanEvent = null;
                    }
                }
            }
                _targetGroup = null;
                _targetNode = null;
        }
    }
    },

        /*
        * Function to perform tree or breadcrumb scroll for pan events
        * @function
        * @memberOf CPM.Control.EventManager
        * @params{target}target element
        */
        _scrollOnPan = function ( target ) {
            if ( target === CPM.Enums.EventTarget.TreeGroupScroll ) {
                if ( _prevPanEvent ) {
                    if ( ( _currPanEvent.type === CPM.Enums.EventType.panup || _currPanEvent.type === CPM.Enums.EventType.pandown ) && ( Math.abs( _currPanEvent.deltaY - _prevPanEvent.deltaY ) > 3 ) ) {
                        _timesVPanEvtFired = 0;
                        _fireEvent( _currPanEvent, target );
                    }
                    else {
                        if ( ( _currPanEvent.type === CPM.Enums.EventType.panleft || _currPanEvent.type === CPM.Enums.EventType.panright ) && ( Math.abs( _currPanEvent.deltaX - _prevPanEvent.deltaX ) > 3 ) ) {
                            _timesHPanEvtFired = 0;
                            _fireEvent( _currPanEvent, target );
                    }
                }
                    _prevPanEvent = _currPanEvent;
                } else {
                    _prevPanEvent = _currPanEvent;
            }
            } else if ( target === CPM.Enums.EventTarget.BreadCrumbScroll ) {
                if ( _prevBCPanEvent ) {
                    if ( ( Math.abs( _currBCPanEvent.deltaY - _prevBCPanEvent.deltaY ) > 3 ) ) {
                        _timesBCPanEvtFired = 0;
                        _fireEvent( _currBCPanEvent, target );
                }
                    _prevBCPanEvent = _currBCPanEvent;
                } else {
                    _prevBCPanEvent = _currBCPanEvent;
            }
            } else {
                if ( target === CPM.Enums.EventTarget.ComboBoxScroll ) {
                    if ( _prevCBPanEvent ) {
                        if ( ( Math.abs( _currCBPanEvent.deltaY - _prevCBPanEvent.deltaY ) > 3 ) ) {
                            _timesCBPanEvtFired = 0;
                            _fireEvent( _currCBPanEvent, target );
                    }
                        _prevCBPanEvent = _currCBPanEvent;
                    } else {
                        _prevCBPanEvent = _currCBPanEvent;
                }
            }
        }
    },

        /*
        * Function to perform tree or breadcrumb scroll for mousewheel events
        * @function
        * @memberOf CPM.Control.EventManager
        * @params{evt}event
        */
        _mouseWheelScroll = function ( evt ) {
            var delta = 0, mozDelta = 0, direction, isShiftKey = evt.shiftKey;

            if ( ( evt.wheelDelta !== undefined || evt.detail !== undefined ) ) {
                delta = evt.wheelDelta;
                mozDelta = evt.detail;
                if ( delta < 0 || mozDelta > 0 ) {
                    direction = true;
                }
                else {
                    if ( delta > 0 || mozDelta < 0 ) {
                        direction = false;
                }
            }
        }
            if ( !isShiftKey && ( evt.target.id.indexOf( 'breadcrumbGroup' ) !== -1 || evt.target.id.indexOf( 'bc_vScrollbar' ) !== -1 ) ) {
                eventHandlers.onScroll( direction, 'bcVScroll' );
            } else if ( !isShiftKey && ( evt.target.id.indexOf( 'treeGroup' ) !== -1 || evt.target.id.indexOf( 'tree_vScrollbar' ) !== -1 ) ) {
                eventHandlers.onScroll( direction, 'VScroll' );
            } else if ( isShiftKey && ( evt.target.id.indexOf( 'treeGroup' ) !== -1 || evt.target.id.indexOf( 'hScrollbar' ) !== -1 ) ) {
                eventHandlers.onScroll( direction, 'HScroll' );
            } else {
                if ( isShiftKey && ( evt.target.id.indexOf( '_comboBoxElementsGroup' ) !== -1 || evt.target.id.indexOf( 'cb_vScrollbar' ) !== -1 ) ) {
                    eventHandlers.onScroll( direction, 'cbVScroll' );
            }
        }
            evt.preventDefault();
    },

        /*
        * Function to perform tree or breadcrumb scroll for pan events
        * @function
        * @memberOf CPM.Control.EventManager
        * @params{evt}event
        * @params{target}breadcrumb or treegroup element
        */
        _fireEvent = function ( evt, target ) {
            if ( target === CPM.Enums.EventTarget.BreadCrumbScroll ) {
                if ( evt.type === CPM.Enums.EventType.panup ) {
                    eventHandlers.onScroll( true, 'bcVScroll' );
                } else {
                    if ( evt.type === CPM.Enums.EventType.pandown ) {
                        eventHandlers.onScroll( false, 'bcVScroll' );
                }
            }
            } else if ( target === CPM.Enums.EventTarget.TreeGroupScroll ) {
                if ( evt.type === CPM.Enums.EventType.panup ) {
                    eventHandlers.onScroll( true, 'VScroll' );
                } else if ( evt.type === CPM.Enums.EventType.pandown ) {
                    eventHandlers.onScroll( false, 'VScroll' );
                } else if ( evt.type === CPM.Enums.EventType.panleft ) {
                    eventHandlers.onScroll( true, 'HScroll' );
                } else {
                    if ( evt.type === CPM.Enums.EventType.panright ) {
                        eventHandlers.onScroll( false, 'HScroll' );
                }
            }
            } else {
                if ( target === CPM.Enums.EventTarget.ComboBoxScroll ) {
                    if ( evt.type === CPM.Enums.EventType.panup ) {
                        eventHandlers.onScroll( true, 'cbVScroll' );
                    } else {
                        if ( evt.type === CPM.Enums.EventType.pandown ) {
                            eventHandlers.onScroll( false, 'cbVScroll' );
                    }
                }
            }
        }
    },

        /*
        * Registered as a callback on single tap 
        * @param {EventObject} evt
        */
        _singleClickHandler = function ( evt ) {
            var node;
            _validateEventTarget( evt );
            if ( _targetGroup === CPM.Enums.EventTarget.TraverseToParent ) {
                node = eventHandlers.getNodeData( _targetNode );
                if ( node ) {
                    eventHandlers.setNavigatedNodeId( node.ParentId );
                    node = eventHandlers.getParent( node.ParentId );
                    eventHandlers.selectNode( node, false, false );
                }
                _closeComboBox();
            } else if ( _targetGroup === CPM.Enums.EventTarget.NodeTextRect ) {
                if ( _isComboBoxClicked ) {
                    _isComboBoxClicked = false;
                    return;
                }
                node = eventHandlers.getNodeData( _targetNode );
                if ( node ) {
                    eventHandlers.selectNode( node, false, false );
                } else {
                    eventHandlers.unloadBreadCrumb();
                }
                _closeComboBox();
            } else if ( _targetGroup === CPM.Enums.EventTarget.SummaryAlarm ) {
                node = eventHandlers.getNodeData( _targetNode );
                if ( node ) {
                    eventHandlers.sendSummaryInfo( node );
                    eventHandlers.selectNode( node, false, false );
                }
                _closeComboBox();
            }
            else {
                if ( _targetGroup === CPM.Enums.EventTarget.CrumbGroup ) {
                    node = eventHandlers.getCrumbNode( _targetNode );
                    eventHandlers.setSelectedFromBC( node );
                    _closeComboBox();
                }
            }
            _targetGroup = null;
            _targetNode = null;
            evt.preventDefault();
    },
        /*
        * Registered as a callback on double tap 
        * @param {EventObject} evt
        */
        _doubleClickHandler = function ( evt ) {

            var node;
            _validateEventTarget( evt );
            if ( _targetGroup === CPM.Enums.EventTarget.NodeTextRect ) {
                node = eventHandlers.getNodeData( _targetNode );
                if ( node ) {
                    eventHandlers.toggleVisibility( node, undefined, true );
            }
            }
            else if ( _targetGroup === CPM.Enums.EventTarget.SummaryAlarm ) {
                node = eventHandlers.getNodeData( _targetNode );
                if ( node ) {
                    eventHandlers.sendSummaryInfo( node );
                    eventHandlers.selectNode( node, false, false );
            }
            } else {
                if ( _targetGroup !== CPM.Enums.EventTarget.CBVScrollBar ) {
                    _closeComboBox();
            }
        }
            _targetGroup = null;
            _targetNode = null;
            evt.preventDefault();

    },
        /*
        * Handle key actions(keyboard events)
        * @param {evt} event 
        */
        _handleKeyDown = function ( evt ) {
            var preventDefault = true,
            target = evt.target || evt.srcElement;

            if ( target && target.tagName === 'INPUT' && target.id.indexOf( 'searchBox' ) !== -1 ) {
                preventDefault = false;
        }
            if ( evt.keyCode === 40 || evt.keyCode === 34 ) { // Down arrow keyCode = 40, Page Down keyCode = 34
                eventHandlers.onScroll( true, 'VScroll', evt );
            } else {
                if ( evt.keyCode === 38 || evt.keyCode === 33 ) { // Up arrow keyCode = 38, Page Up keyCode = 33
                    eventHandlers.onScroll( false, 'VScroll', evt );
                }
                else {
                    if ( evt.keyCode === 13 && !preventDefault ) {  // For Search box ENTER key press
                        eventHandlers.handleSearchText( evt.target.value );
                        evt.target.blur();
                }
            }
        }
            if ( preventDefault ) {
                evt.preventDefault();
        }
    },

        _handleKeyUp = function ( evt ) {
            if ( evt.target.value !== undefined && evt.target.value !== '' ) {
                eventHandlers.showClearIcon();
            } else {
                eventHandlers.hideClearIcon();
        }
    },

        _getMousePos = function () {
            return _mousPosWrtParentSvg;
    },
        /*
        * Cleans EventManager
        * @function
        * @memberOf CPM.Control.EventManager
        */
        _clean = function () {
            _removeEventListeners();
            _areaParent = null;
            _mousPosWrtParentSvg = null;
            _targetGroup = null;
            _targetNode = null;
    };
    return {
            addEventListeners: _addEventListeners,
            handleKeyDown: _handleKeyDown,
            getMousePos: _getMousePos,
            clean: _clean,
            singleClickHandler: _singleClickHandler
    };
};
var CPM = ( CPM || {} );

CPM.svgNode = function ( data ) {
    var _bgRect,
        _rectColor,
        _currRectColor,
        _nodeText,
        _rootIcon,
        _alarmSeparatorVertLine,
        _arrowIconGrp,
        _alarmIconGrp,
        _alarmIconSeparatorRect,
        _alarmIconSeparatorGrp,
        _alarmSeparatorHorLine,
        _iconGroup,
        _nodeGroup,
        _openFolderIcon,
        _closedFolderIcon,
        _linkedNodeGrpIcon,
        _traverseNodeGrpIcon,
        _mainIconSvg,
        _expandCollapseIcon,
        _horizSeparatorLine,
        _alarmSvgIcon,
        _attrs,
        _createAlarmIcon = function ( nodeHeight ) {
            var alarmIconSvg = CPM.svgUtil.createSVG( 'svg', {
                id: 'treeGroup_summaryAlarm_Svg_' + data.index,
                height: nodeHeight,
                width: CPM.Enums.Constants.alarmIconWidth,
                viewBox: '5 5 20 20',
                fill: 'red',
                appendTo: _alarmIconGrp,
                cursor: 'pointer'
            } );
            CPM.svgUtil.createSVG( 'rect', {
                width: '100%',
                height: '100%',
                appendTo: alarmIconSvg,
                x: 5,
                y: 0,
                fill: 'red',
                'fill-opacity': 0,
                id: 'treeGroup_summaryAlarm_Rect_' + data.index
            } );

            _alarmSvgIcon = CPM.svgUtil.createSVG( 'path', {
                d: 'M18.7,16.1l-5.3-9.5c-0.3-0.5-0.7-0.5-1,0l-5.1,9.5c-0.3,0.5,0,0.9,0.5,0.9h10.3C18.8,17,19,16.6,18.7,16.1z M14,16h-2 v-2h2V16z M14,13h-2V9h2V13z',
                fill: 'black',
                appendTo: alarmIconSvg,
                id: 'treeGroup_summaryAlarm_Path_' + data.index
            } );
        },
        _createAlarmIconSeparator = function ( attrs ) {
            _alarmIconSeparatorRect = CPM.svgUtil.createSVG( 'rect', {
                x: 0,
                y: 0,
                width: 2 * CPM.Enums.Constants.alarmIconWidth,
                height: attrs.height,
                fill: attrs.fill,
                'opacity': 1,
                position: 'fixed',
                style: 'cursor: pointer',
                id: 'alarm_nodeRect' + data.index,
                appendTo: _alarmIconSeparatorGrp
            } );
            _alarmSeparatorVertLine = CPM.svgUtil.createSVG( 'line', {
                x1: 0,
                x2: 0,
                y1: 0,
                y2: attrs.height,
                stroke: attrs.stroke,
                'stroke-width': '1px',
                id: 'alarm_line' + data.index,
                appendTo: _alarmIconSeparatorGrp
            } );
            _alarmSeparatorHorLine = CPM.svgUtil.createSVG( 'line', {
                x1: 0,
                x2: 50,
                y1: attrs.height,
                y2: attrs.height,
                stroke: attrs.stroke,
                'stroke-width': '1px',
                appendTo: _alarmIconSeparatorGrp
            } );
        },
        _show = function ( element ) {
            element.setAttribute( 'display', 'block' );
        },
        _hide = function ( element ) {
            element.setAttribute( 'display', 'none' );
        },
        _createRootIcon = function ( nodeIconSvg, x, y, nodeIconColor ) {
            var _rootGrp1, _rootGrp2, _rootGrp3;
            _rootIcon = CPM.svgUtil.createSVG( 'svg', {
                x: x, y: y,
                width: '26', height: '22',
                viewBox: '0 0 26 22',
                appendTo: nodeIconSvg,
                id: 'rootIcon',
                fill: nodeIconColor
            } );
            _rootGrp1 = CPM.svgUtil.createSVG( 'g', {
                appendTo: _rootIcon
            } );
            CPM.svgUtil.createSVG( 'path', {
                d: 'M13,9L9.5,5.5L13,2l3.5,3.5L13,9z M10.6,5.5L13,7.9l2.4-2.4L13,3.1L10.6,5.5z',
                id: 'treeGroup__rootGrp1_path',
                appendTo: _rootGrp1
            } );
            CPM.svgUtil.createSVG( 'polygon', {
                points: '13,2.6 13,8.4 15.9,5.5',
                id: 'treeGroup__rootGrp1_polygon',
                appendTo: _rootGrp1
            } );
            _rootGrp2 = CPM.svgUtil.createSVG( 'g', {
                appendTo: _rootIcon
            } );
            CPM.svgUtil.createSVG( 'path', {
                d: 'M7,20l-3.5-3.5L7,13l3.5,3.5L7,20z M4.6,16.5L7,18.9l2.4-2.4L7,14.1L4.6,16.5z',
                id: 'treeGroup__rootGrp2_path',
                appendTo: _rootGrp2
            } );
            CPM.svgUtil.createSVG( 'polygon', {
                points: '7,13.6 7,19.4 9.9,16.5',
                id: 'treeGroup__rootGrp2_polygon',
                appendTo: _rootGrp2
            } );
            _rootGrp3 = CPM.svgUtil.createSVG( 'g', {
                appendTo: _rootIcon
            } );
            CPM.svgUtil.createSVG( 'path', {
                d: 'M19,20l-3.5-3.5L19,13l3.5,3.5L19,20z M16.6,16.5l2.4,2.4l2.4-2.4L19,14.1L16.6,16.5z',
                id: 'treeGroup__rootGrp3_path',
                appendTo: _rootGrp3
            } );
            CPM.svgUtil.createSVG( 'polygon', {
                points: '19,13.6 19,19.4 21.9,16.5',
                id: 'treeGroup__rootGrp3_polygon',
                appendTo: _rootGrp3
            } );

            CPM.svgUtil.createSVG( 'rect', {
                x: '12', y: '8',
                width: '2',
                height: '4',
                appendTo: _rootIcon
            } );
            CPM.svgUtil.createSVG( 'rect', {
                x: '6', y: '10',
                width: '14',
                height: '2',
                appendTo: _rootIcon
            } );
            CPM.svgUtil.createSVG( 'rect', {
                x: '6', y: '10',
                width: '2',
                height: '4',
                appendTo: _rootIcon
            } );
            CPM.svgUtil.createSVG( 'rect', {
                x: '18', y: '10',
                width: '2',
                height: '4',
                appendTo: _rootIcon
            } );
        },
        _createOpenFolderIcon = function () {
            // Plant object folder opened 
            var expandedGrp = CPM.svgUtil.createSVG( 'g', {
                appendTo: _openFolderIcon
            } );
            CPM.svgUtil.createSVG( 'path', {
                d: 'M18,11l-3.5,3.5L18,18l3.5-3.5Zm-2.09,3.5L18,12.41v4.17Z',
                id: 'treeGroup_expandedGrp_path1',
                appendTo: expandedGrp
            } );
            CPM.svgUtil.createSVG( 'path', {
                d: 'M24.5,10.5,22,8l-2.5,2.5L22,13Zm-3.59,0L22,9.41v2.17Z',
                id: 'treeGroup_expandedGrp_path2',
                appendTo: expandedGrp
            } );
            CPM.svgUtil.createSVG( 'path', {
                d: 'M19.5,18.5,22,21l2.5-2.5L22,16Zm1.41,0L22,17.41v2.17Z',
                id: 'treeGroup_expandedGrp_path3',
                appendTo: expandedGrp
            } );
            CPM.svgUtil.createSVG( 'path', {
                d: 'M5.9,10H16V8H9.4L7.5,6H2V17l3.1-6.4A.76.76,0,0,1,5.9,10Z',
                id: 'treeGroup_expandedGrp_path4',
                appendTo: expandedGrp
            } );
            CPM.svgUtil.createSVG( 'polygon', {
                points: '12.52 14.5 13.51 13.51 16.02 11 6.4 11 3.4 17 15.02 17 13.51 15.49 12.52 14.5',
                id: 'treeGroup_expandedGrp_polygon',
                appendTo: expandedGrp
            } );

            CPM.svgUtil.createSVG( 'rect', {
                width: '26',
                height: '22',
                fill: 'none',
                appendTo: expandedGrp
            } );
        },
    _createClosedFolderIcon = function () {
        // Plant object folder closed     
        var collapsedGrp = CPM.svgUtil.createSVG( 'g', {
            appendTo: _closedFolderIcon
        } );
        CPM.svgUtil.createSVG( 'polygon', {
            points: '16 8 9.4 8 7.5 6 2 6 2 10 16 10 16 8',
            id: 'treeGroup_collapsedGrp_polygon',
            appendTo: collapsedGrp
        } );
        CPM.svgUtil.createSVG( 'path', {
            d: 'M18,11l-3.5,3.5L18,18l3.5-3.5Zm0,5.59L15.91,14.5,18,12.41Z',
            id: 'treeGroup_collapsedGrp_path1',
            appendTo: collapsedGrp
        } );
        CPM.svgUtil.createSVG( 'path', {
            d: 'M24.5,10.5,22,8l-2.5,2.5L22,13ZM22,9.41v2.17L20.91,10.5Z',
            id: 'treeGroup_collapsedGrp_path2',
            appendTo: collapsedGrp
        } );
        CPM.svgUtil.createSVG( 'path', {
            d: 'M19.5,18.5,22,21l2.5-2.5L22,16ZM22,19.59,20.91,18.5,22,17.41Z',
            id: 'treeGroup_collapsedGrp_path3',
            appendTo: collapsedGrp
        } );
        CPM.svgUtil.createSVG( 'polygon', {
            points: '12.52 14.5 13.51 13.51 16.02 11 2 11 2 17 15.02 17 13.51 15.49 12.52 14.5',
            id: 'treeGroup_collapsedGrp_path4',
            appendTo: collapsedGrp
        } );

        CPM.svgUtil.createSVG( 'rect', {
            width: '26',
            height: '22',
            fill: 'none',
            appendTo: collapsedGrp
        } );
    },
    _createlinkedNodeGrpIcon = function () {
        // Linked node 
        var linkedNodeGrp = CPM.svgUtil.createSVG( 'g', {
            appendTo: _linkedNodeGrpIcon
        } );
        CPM.svgUtil.createSVG( 'path', {
            d: 'M10,7,5.5,11.5,10,16l4.5-4.5ZM6.91,11.5,10,8.41v6.17Z',
            id: 'treeGroup_linkedNodeGrp_path1',
            appendTo: linkedNodeGrp
        } );
        CPM.svgUtil.createSVG( 'path', {
            d: 'M18.5,6.5,15,3,11.5,6.5,15,10Zm-5.59,0L15,4.41V8.59Z',
            id: 'treeGroup_linkedNodeGrp_path2',
            appendTo: linkedNodeGrp
        } );
        CPM.svgUtil.createSVG( 'path', {
            d: 'M11.5,16.5,15,20l3.5-3.5L15,13Zm1.41,0L15,14.41v4.17Z',
            id: 'treeGroup_linkedNodeGrp_path3',
            appendTo: linkedNodeGrp
        } );
        CPM.svgUtil.createSVG( 'rect', {
            width: '26',
            height: '22',
            fill: 'none',
            appendTo: linkedNodeGrp
        } );
    },

    _setNodeOpacity = function ( elements, value ) {
        var i,
        length = elements.length;

        for ( i = 0; i < length; i++ ) {
            _setElementProp( elements[i], 'fill-opacity', value );
        }
    },

    _setElementProp = function ( element, prop, value ) {
        if ( element ) {
            element.setAttribute( prop, value );
        }
    };

    this.create = function ( attrs ) {
        _attrs = attrs;
        _nodeGroup = CPM.svgUtil.createSVG( 'g', {
            id: 'treeGroup_nodegroup_' + data.index,
            appendTo: attrs.appendTo,
            'data-tif-id': 'CPMNodeGroup_' + data.index,
            'data-tif-type': 'WSI:CpmTreeNode'
        } );
        _nodeGroup.TifProperties = {
            tif: {},
            item: {
                nodes: [],
                expanded: false,
                selected: false,
                text: null,
                nodeId: null,
                tifId: _nodeGroup.getAttribute( 'data-tif-id' )
            }
        };
        _bgRect = CPM.svgUtil.createSVG( 'rect', {
            width: attrs.width,
            height: attrs.height,
            appendTo: _nodeGroup,
            x: attrs.x,
            y: attrs.y,
            fill: attrs.fill,
            id: 'treeGroup_nodeBgRect_' + data.index
        } );
        _horizSeparatorLine = CPM.svgUtil.createSVG( 'line', {
            x1: attrs.x,
            x2: attrs.width,
            y1: attrs.y + attrs.height,
            y2: attrs.y + attrs.height,
            stroke: attrs.stroke,
            'stroke-width': '1px',
            appendTo: _nodeGroup
        } );
        _rectColor = attrs.fill;
        _currRectColor = attrs.fill;
    };

    this.createAlarmIconGroup = function ( attrs ) {
        _alarmIconSeparatorGrp = CPM.svgUtil.createSVG( 'g', {
            appendTo: attrs.appendTo,
            display: 'none',
            id: 'alarmSeparator_Grp_' + data.index
        } );
        //alarm icon
        _alarmIconGrp = CPM.svgUtil.createSVG( 'g', {
            appendTo: attrs.appendTo,
            display: 'none',
            id: 'alarmIcon_Grp_' + data.index
        } );
        _createAlarmIconSeparator( attrs );
        _createAlarmIcon( attrs.height );
    };

    this.updateAlarmIcon = function ( node, y, width ) {
        var alarmIconX;
        if ( node ) {
            alarmIconX = width - CPM.Enums.Constants.alarmIconWidth;
            _show( _alarmIconSeparatorGrp );
            _alarmIconSeparatorGrp.setAttribute( 'transform', 'translate(' + ( alarmIconX ) + ',' + ( y ) + ')' );
            _show( _alarmIconGrp );
            _alarmIconGrp.setAttribute( 'transform', 'translate(' + ( alarmIconX + CPM.Enums.Constants.alarmIconLeftPadding ) + ',' + ( y + CPM.Enums.Constants.topPaddingAlarmIcon ) + ')' );
        } else {
            _hide( _alarmIconGrp );
        }
    };

    this.update = function ( node, left, y ) {
        var x, iconSvg;
        if ( node ) {
            if ( _traverseNodeGrpIcon && ( node.isSelected || node.childSelected ) && node.ParentId && node.isNodeNavigated ) {
                x = ( node.depth * CPM.Enums.Constants.iconToIconGap ) + CPM.Enums.Constants.horizontalgap;// - (2*left);
            } else{
                x = ( node.depth * CPM.Enums.Constants.iconToIconGap ) + CPM.Enums.Constants.horizontalgap - (2*left);
            }
            _show( _iconGroup );
            _iconGroup.setAttribute( 'transform', 'translate(' + x + ',' + y + ' )' ); //TODO: remove y update

            _nodeGroup.TifProperties = {
                tif: {},
                item: {
                    nodes: node.Children ? node.Children : [],
                    expanded: node.IsExpanded,
                    text: node.Name,
                    nodeId: node.Id,
                    tifId: _nodeGroup.getAttribute( 'data-tif-id' )
                }
            };
            if ( _traverseNodeGrpIcon && ( node.isSelected || node.childSelected ) && node.ParentId && node.isNodeNavigated ) {
                _show( _iconGroup.childNodes[3] );
            } else {
                if ( _traverseNodeGrpIcon ) {
                    _hide( _iconGroup.childNodes[3] );
                }
            }
            if ( node.IsLeaf || node.ChildCount === 0 ) {
                _hide( _iconGroup.childNodes[1] );
                if ( node.IsLinked ) {
                    iconSvg = _linkedNodeGrpIcon;
                }
                else if ( !node.ParentId ) {
                    iconSvg = _rootIcon;
                }
                else {
                    iconSvg = _openFolderIcon;
                }
            } else {
                _show( _iconGroup.childNodes[1] );
                if ( node.IsLinked ) {
                    iconSvg = _linkedNodeGrpIcon;
                }
                else if ( !node.ParentId ) {
                    iconSvg = _rootIcon;
                }
                else if ( node.IsExpanded ) {
                    iconSvg = _openFolderIcon;
                }
                else {
                    iconSvg = _closedFolderIcon;
                }

                if ( node.IsExpanded ) {
                    _iconGroup.childNodes[1].childNodes[0].childNodes[0].setAttribute( 'points', '5 7 11.5 14 18 7 5 7' );
                } else {
                    _iconGroup.childNodes[1].childNodes[0].childNodes[0].setAttribute( 'points', '9 3 9 16 16 9.5 9 3' );
                }
            }
            if ( iconSvg ) {
                _mainIconSvg.removeChild( _mainIconSvg.firstChild );
                _mainIconSvg.appendChild( iconSvg );
            }
        }
        else {
            if ( _iconGroup ) {
                _hide( _iconGroup );
            }
            if ( _nodeText ) {
                _nodeText.textContent = '';
            }
            if ( _currRectColor === data.selectionColor ) { //Remove the selection color from the bgRect if the node data is not present.
                _bgRect.setAttribute( 'fill', _rectColor );
                _currRectColor = _rectColor;
            }
        }
    };
    this.setStyleForNode = function ( nodeProps, stylePropObj, i ) {
        var opacity = 1;

        _nodeGroup.TifProperties.item.selected = nodeProps.isSelected;
        if ( nodeProps.isSelected ) {
            if ( stylePropObj.SelectionBackColor ) {
                data.selectionColor = stylePropObj.SelectionBackColor;
            }
            if ( _nodeText && stylePropObj.SelectionForeColor ) {
                data.selectionForeColor = stylePropObj.SelectionForeColor;
            }
            _currRectColor = data.selectionColor;
            _setElementProp( _nodeText, 'fill', stylePropObj.SelectionForeColor );
            _setElementProp( _rootIcon, 'fill', stylePropObj.SelectionNodeIconColor );
            _setElementProp( _openFolderIcon, 'fill', stylePropObj.SelectionNodeIconColor );
            _setElementProp( _closedFolderIcon, 'fill', stylePropObj.SelectionNodeIconColor );
            _setElementProp( _linkedNodeGrpIcon, 'fill', stylePropObj.SelectionNodeIconColor );
            _setElementProp( _expandCollapseIcon, 'fill', stylePropObj.SelectionNodeIconColor );
            _setElementProp( _traverseNodeGrpIcon, 'fill', stylePropObj.SelectionNodeIconColor );
        } else {
            if ( i % 2 !== 0 ) {
                _rectColor = stylePropObj.grey3;
            } else {
                _rectColor = stylePropObj.white;
            }
            _currRectColor = _rectColor;
            _setElementProp( _nodeText, 'fill', stylePropObj.ForeColor );
            _setElementProp( _rootIcon, 'fill', stylePropObj.NodeIconColor );
            _setElementProp( _openFolderIcon, 'fill', stylePropObj.NodeIconColor );
            _setElementProp( _closedFolderIcon, 'fill', stylePropObj.NodeIconColor );
            _setElementProp( _linkedNodeGrpIcon, 'fill', stylePropObj.NodeIconColor );
            _setElementProp( _expandCollapseIcon, 'fill', stylePropObj.ForeColor );
            _setElementProp( _traverseNodeGrpIcon, 'fill', stylePropObj.ForeColor );
        }

        if ( !nodeProps.hasSearchText ) {
            opacity = 0.5;
        }

        _setNodeOpacity( [_nodeText, _rootIcon, _openFolderIcon, _closedFolderIcon, _linkedNodeGrpIcon, _expandCollapseIcon], opacity );

        _setElementProp( _bgRect, 'fill', _currRectColor );
        _setElementProp( _horizSeparatorLine, 'stroke', stylePropObj.HorizLineColor );

    };

    this.setStyleForAlarmNode = function ( isSelected, stylePropObj, i ) {
        if ( isSelected ) {
            if ( stylePropObj.SelectionBackColor ) {
                data.selectionColor = stylePropObj.SelectionBackColor;
            }
            _currRectColor = data.selectionColor;
            _setElementProp( _alarmSvgIcon, 'fill', stylePropObj.SelectionNodeIconColor );
        } else {
            if ( i % 2 !== 0 ) {
                _rectColor = stylePropObj.grey3;
            } else {
                _rectColor = stylePropObj.white;
            }
            _currRectColor = _rectColor;
            _setElementProp( _alarmSvgIcon, 'fill', stylePropObj.ForeColor );
        }
        _setElementProp( _alarmIconSeparatorRect, 'fill', _currRectColor );
        _setElementProp( _alarmSeparatorHorLine, 'stroke', stylePropObj.HorizLineColor );
        _setElementProp( _alarmSeparatorVertLine, 'stroke', stylePropObj.HorizLineColor );
    };

    this.createNodeIcon = function ( obj, viewportIndex ) {
        var nodeIconSvg, x = 0;
        if ( !_iconGroup ) {
            _iconGroup = CPM.svgUtil.createSVG( 'g', {
                id: 'treeGroup_iconGroup_' + data.index,
                appendTo: obj.nodeTextGroup,
                display: 'none'
            } );

            //Expand collapse icon
            CPM.svgUtil.createSVG( 'rect', {
                height: '25',
                width: '25',
                x: '-5',
                y: '0',
                stroke: 'none',
                fill: 'gray',
                'fill-opacity': '0.01',
                style: 'cursor: pointer',
                id: 'treeGroup_rect_expandCollapseIcon_' + data.index,
                appendTo: _iconGroup
            } );
            nodeIconSvg = CPM.svgUtil.createSVG( 'svg', {
                x: x,
                y: '8',
                appendTo: _iconGroup
            } );
            _arrowIconGrp = CPM.svgUtil.createSVG( 'g', {
                appendTo: nodeIconSvg
            } );

            _expandCollapseIcon = CPM.svgUtil.createSVG( 'polygon', {
                fill: _attrs.expandCollIconColor,
                style: 'cursor: pointer',
                id: 'treeGroup_path_expandCollapseIcon_' + data.index,
                appendTo: _arrowIconGrp
            } );
            CPM.svgUtil.createSVG( 'rect', {
                width: '24',
                height: '20',
                fill: 'black',
                'fill-opacity': 0,
                style: 'cursor: pointer',
                id: 'treeGroup_rect_expandCollapseIcon_' + data.index,
                appendTo: _arrowIconGrp
            } );

            // Plant object for root node 
            x = data.Left + CPM.Enums.Constants.horizontalgap;
            _mainIconSvg = CPM.svgUtil.createSVG( 'svg', {
                id: 'iconSvg',
                appendTo: _iconGroup
            } );
            _createRootIcon( _mainIconSvg, x, 4, _attrs.nodeIconColor );

            _openFolderIcon = CPM.svgUtil.createSVG( 'svg', {
                x: x,
                y: '4',
                fill: _attrs.nodeIconColor,
                id: 'OpenFolderIcon'
            } );
            _createOpenFolderIcon();
            _closedFolderIcon = CPM.svgUtil.createSVG( 'svg', {
                x: x,
                y: '4',
                fill: _attrs.nodeIconColor,
                id: 'ClosedFolderIcon'
            } );
            _createClosedFolderIcon();
            _linkedNodeGrpIcon = CPM.svgUtil.createSVG( 'svg', {
                x: x,
                y: '7',
                height: '22',
                width: '26',
                viewbox: '4 2 22 18',
                fill: _attrs.nodeIconColor,
                id: 'linkedNodeGrpIcon'
            } );
            _createlinkedNodeGrpIcon();            
        }
        if ( !_traverseNodeGrpIcon && viewportIndex === 0 && WebCC.Properties.NavigationType === CPM.Enums.NavigationType.Dynamic ) {
            _traverseNodeGrpIcon = CPM.svgUtil.createSVG('svg', {
                x: '-12',
                y: '10',
                id: 'traverseNodeGrpIcon',
                appendTo: _iconGroup
            });
            var traverseNodeGrp = CPM.svgUtil.createSVG('g', {
                appendTo: _traverseNodeGrpIcon
            });
            CPM.svgUtil.createSVG('rect', {
                width: '12',
                height: '16',
                y: '-2',
                fill: 'black',
                'fill-opacity': 0,
                style: 'cursor: pointer',
                id: 'traverseToParentIconBackgroundRect_' + data.index,
                appendTo: _traverseNodeGrpIcon
            });
            CPM.svgUtil.createSVG('path', {
                id: 'traverseToParentIconPolygon_' + data.index,
                fill: _attrs.expandCollIconColor,
                d: 'M6,0.03795 L11.801,6.99995 L9.198,6.99995 L6,3.16199994 L2.801,6.99995 L0.199,6.99995 L6,0.03795 Z',
                style: 'cursor: pointer',
                appendTo: traverseNodeGrp
            });
            CPM.svgUtil.createSVG('rect', {
                id: 'traverseToParentIconRect_' + data.index,
                x: '5',
                y: '2',
                width: '2',
                height: '10',
                fill: _attrs.expandCollIconColor,
                style: 'cursor: pointer',
                appendTo: traverseNodeGrp
            });
        }
    };

    this.createText = function ( obj, stylePropObj, i ) {
        if ( !_nodeText ) {
            _nodeText = CPM.svgUtil.createSVG( 'text', {
                style: 'cursor: default',
                display: 'block',
                appendTo: obj.nodeTextGroup
            } );
        }
        CPM.svgUtil.setAttr( _nodeText, {
            id: 'treeGroup_nodeText_' + i,
            x: obj.x,
            y: obj.y,
            'font-size': obj.font.Size,
            'fill': ( obj.isSelected && stylePropObj.SelectionForeColor ) ? stylePropObj.SelectionForeColor : stylePropObj.ForeColor,
            'font-style': obj.font.Italic ? 'italic' : 'normal',
            'font-family': obj.font.family
        } );
        _nodeText.textContent = obj.currText;
    };

    this.updateRectWidth = function ( rectWidth ) {
        _bgRect.setAttribute( 'width', rectWidth );
    };

    this.hideLastNode = function () {
        if ( _iconGroup ) {
            _hide( _iconGroup );
        }
        if ( _nodeText ) {
            _hide( _nodeText );
        }
    };

    this.hideLastAlarmNode = function () {
        _hide( _alarmIconGrp );
    };

    this.showLastNode = function () {
        if ( _nodeText && _nodeText.textContent ) {
            _show( _iconGroup );
            _show( _nodeText );
        }
    };

    this.changeAlarmState = function ( isActive ) {
        if ( isActive ) {
            _show( _alarmIconGrp );
        } else {
            _hide( _alarmIconGrp );
        }
    };

    this.changeAlarmSeperatorState = function ( width, lineColor, foreColor, y ) {
        _show( _alarmIconSeparatorGrp );
        _alarmIconSeparatorGrp.setAttribute( 'transform', 'translate(' + ( width ) + ',' + ( y ) + ')' );
        _alarmIconGrp.setAttribute( 'transform', 'translate(' + ( width + CPM.Enums.Constants.alarmIconLeftPadding ) + ',' + ( y + CPM.Enums.Constants.topPaddingAlarmIcon ) + ')' );
        _setElementProp( _alarmSeparatorVertLine, 'stroke', lineColor );
        _setElementProp( _alarmSeparatorVertLine, 'x', width );
        _setElementProp( _alarmSvgIcon, 'fill', foreColor );
    };

    this.updateSelectionBackColor = function ( color ) {
        _setElementProp( _bgRect, 'fill', color );
        _setElementProp( _alarmIconSeparatorRect, 'fill', color );
    };

    this.updateSelectionForeColor = function ( color ) {
        _setElementProp( _nodeText, 'fill', color );
    };

    this.updateNodeStyle = function ( stylePropObj, altBackFill, forAlarmIcon ) {
        if ( !forAlarmIcon ) {
            _setElementProp( _bgRect, 'fill', altBackFill );
            _setElementProp( _horizSeparatorLine, 'stroke', stylePropObj.HorizLineColor );
            _setElementProp( _nodeText, 'fill', stylePropObj.ForeColor );
            _setElementProp( _rootIcon, 'fill', stylePropObj.NodeIconColor );
            _setElementProp( _openFolderIcon, 'fill', stylePropObj.NodeIconColor );
            _setElementProp( _closedFolderIcon, 'fill', stylePropObj.NodeIconColor );
            _setElementProp( _linkedNodeGrpIcon, 'fill', stylePropObj.NodeIconColor );
            _setElementProp( _expandCollapseIcon, 'fill', stylePropObj.ForeColor );
            _setElementProp( _traverseNodeGrpIcon, 'fill', stylePropObj.ForeColor );
        } else {
            _setElementProp( _alarmIconSeparatorRect, 'fill', altBackFill );
            _setElementProp( _alarmSeparatorHorLine, 'stroke', stylePropObj.HorizLineColor );
            _setElementProp( _alarmSeparatorVertLine, 'stroke', stylePropObj.HorizLineColor );
            _setElementProp( _alarmSvgIcon, 'fill', stylePropObj.ForeColor );
        }
    };
};

var CPM = ( CPM || {} );

CPM.svgNodeHandler = function ( obj ) {
    var
    self = this,
    _urlPartTotalHeight = obj.urlPartTotalHeight,
    _toolbarHeight = obj.toolbarHeight,
    _searchComboBoxHeight = obj.searchComboBoxHeight,
    _nodeTextGroup,
    _parent,
    _vpSVgNodes = [],
    _vpAlarmIconNodes = [],
    _nodeHeight,
    _scrollIndex = 0,
    _count,
    _dataArray = null,
    _top,
    _left,
    _font,
    _selectedSvgNode = null,
    _selectedAlarmIconNode = null,
    _ctrlWidth,
    _alarmSummaryData = [],
    _alarmDataFromServer = {},

    _updateOnScroll = function ( data, isScrollbarCreated, isAlarmsPresent, horizontalLine ) {
        var i, dataIndex, y, nodeObj, nodeBBoxInfo, nodeWidth, svgNode, alarmIconNode, top, nodeProps = {};
        _alarmSummaryData = [];
        // find deepest node
        for ( i = 0; i < _count; i++ ) {
            svgNode = _vpSVgNodes[i];
            dataIndex = i + _scrollIndex;
            nodeObj = _dataArray[dataIndex];
            if ( nodeObj ) {
                nodeBBoxInfo = _getNodeWidth( nodeObj );
                if ( i === 0 ) {
                    nodeWidth = nodeBBoxInfo.nodeWidth;
                }
                if ( nodeWidth < nodeBBoxInfo.nodeWidth ) {
                    nodeWidth = nodeBBoxInfo.nodeWidth;
                }
            }
        }
        top = _urlPartTotalHeight + _toolbarHeight + _searchComboBoxHeight;
        // Below for loop takes care of node icon, expand/collapse icon, node text, selection of node, alarm data
        _selectedSvgNode = null;
        _selectedAlarmIconNode = null;
        for ( i = 0; i < _count; i++ ) {
            svgNode = _vpSVgNodes[i];
            if ( isAlarmsPresent ) {
                alarmIconNode = _vpAlarmIconNodes[i];
            }
            dataIndex = i + _scrollIndex;
            nodeObj = _dataArray[dataIndex];
            if ( nodeObj ) {
                nodeProps.hasSearchText = nodeObj.hasSearchText;
                y = i * _nodeHeight;
                svgNode.update( nodeObj, _left, y );
                svgNode.createText( _createText( nodeObj ), data, i );
                self.updateSelectedNodes( nodeObj.isSelected, svgNode, alarmIconNode, isAlarmsPresent );
                nodeProps.isSelected = nodeObj.isSelected;
                svgNode.setStyleForNode( nodeProps, data, i );
                if ( isAlarmsPresent ) {
                    alarmIconNode.setStyleForAlarmNode( nodeObj.isSelected, data, i );
                }
                _alarmSummaryData.push( nodeObj.fullPath );
            } else {    //node which was present previously, but has to be empty when vertical scroller has reached the bottom end
                svgNode.update();
                nodeProps.isSelected = false;
                svgNode.setStyleForNode( nodeProps, data, i );
                if ( isAlarmsPresent ) {
                    alarmIconNode.setStyleForAlarmNode( false, data, i );
                }
            }
        }
        self.updateAlarmSummary( null, data, isScrollbarCreated, isAlarmsPresent, horizontalLine );
        if ( nodeBBoxInfo ) {
            nodeBBoxInfo.nodeWidth = nodeWidth;
        }
        return nodeBBoxInfo;
    },

       _resetTextGroup = function () {
           if ( _nodeTextGroup ) {
               while ( _nodeTextGroup.firstChild ) {
                   _nodeTextGroup.removeChild( _nodeTextGroup.lastChild );
               }
           }
           _nodeTextGroup = CPM.svgUtil.createSVG( 'g', {
               id: 'treeGroup_iconTextGroup',
               transform: 'translate(0, 0 )',
               appendTo: _parent
           } );
       },
        _createText = function ( currText ) {
            var y, textHeight = 15,//Hardcoded as no configuration available in ES for font
            initX, x;
            y = _top +5 + ( textHeight * 0.75 ) +( ( currText.index - _scrollIndex ) * ( 18.5 +textHeight ) );
            if( currText &&( currText.isSelected || currText.childSelected ) && currText.ParentId && currText.isNodeNavigated ){
                initX = CPM.Enums.Constants.iconToIconToTextGap + ( CPM.Enums.Constants.iconDim / 2 ) + CPM.Enums.Constants.horizontalgap;
            } else {
                initX = CPM.Enums.Constants.iconToIconToTextGap + ( CPM.Enums.Constants.iconDim / 2 ) + CPM.Enums.Constants.horizontalgap -(2*_left);
            }
            x = initX + ( ( currText.depth ? currText.depth : 0 ) * CPM.Enums.Constants.iconToIconGap );
            return {
                x: x,
                y: y,
                currText: currText.Name,
                nodeTextGroup: _nodeTextGroup,
                font: _font,
                isSelected: currText.isSelected
            };
        },
        _getNodeWidth = function ( node ) {
            var nodeDepth = node.depth, nodeNameWidth,
            initX = _left + CPM.Enums.Constants.iconToIconToTextGap + ( CPM.Enums.Constants.iconDim / 2 ) + CPM.Enums.Constants.horizontalgap,
            x = initX + ( ( nodeDepth ? nodeDepth : 0 ) * CPM.Enums.Constants.iconToIconGap ),
            bbox = CPM.svgUtil.getTextBBox( { Size: _font.Size, Name: _font.family }, '' + node.Name );
            nodeNameWidth = bbox.width + x;
            return {
                nodeWidth: nodeNameWidth,
                textBBox: bbox
            };
        },
        _updateSummary = function ( i, fullPath ) {
            var isAlarmIconRemove = true;
            if ( _vpAlarmIconNodes[i] && _alarmDataFromServer ) {
                if ( _alarmDataFromServer.RemovedAlarms && Object.keys( _alarmDataFromServer.RemovedAlarms ).indexOf( fullPath ) !== -1 ) {
                    _vpAlarmIconNodes[i].changeAlarmState( false );
                    isAlarmIconRemove = false;

                }
                if ( _alarmDataFromServer.ActiveAlarms && Object.keys( _alarmDataFromServer.ActiveAlarms ).indexOf( fullPath ) !== -1 ) {
                    _vpAlarmIconNodes[i].changeAlarmState( true );
                    isAlarmIconRemove = false;

                }
                if ( isAlarmIconRemove ) {
                    _vpAlarmIconNodes[i].changeAlarmState( false );
                }

            }
        },

        _getBgAttributes = function ( parent, data, i ) {
            var x = 0, y, attrs = {};
            y = i * data.nodeHeight;
            attrs = {
                width: data.Width,
                height: data.nodeHeight,
                appendTo: parent,
                x: x,
                y: y,
                fill: ( i % 2 !== 0 ) ? data.grey3 : data.white,
                stroke: data.HorizLineColor,
                nodeIconColor: data.NodeIconColor,
                expCollIconColor: data.ExpCollIconColor
            };
            return attrs;
        };

    this.createBgRects = function ( parent, data ) {
        var i, svgNode, attrs;
        _parent = parent;
        _vpSVgNodes = [];
        _count = data.count;
        _nodeHeight = data.nodeHeight;
        _top = data.Top;
        _left = data.Left;
        _ctrlWidth = data.Width;
        _urlPartTotalHeight = data.UrlHeight;
        _toolbarHeight = data.ToolbarHeight;
        _searchComboBoxHeight = data.SearchComboBoxHeight;
        for ( i = 0; i < _count + 1; i++ ) {
            attrs = {};
            attrs = _getBgAttributes( parent, data, i, top );
            svgNode = new CPM.svgNode( { Left: data.Left, Top: data.Top, index: i, selectionColor: data.SelectionBackColor, selectionForeColor: data.SelectionForeColor } );
            svgNode.create( attrs );
            _vpSVgNodes.push( svgNode );
        }
        _resetTextGroup();
    };


    this.updateBgRects = function ( dataArray, isResetScrollReq, data, isAlarmsPresent ) {
        var svgNode, y, idx, nodeBBoxInfo, nodeWidth, nodeData, nodeIdx, top, alarmIconNode, nodeText, nodeProps = {};
        _alarmSummaryData = [];
        _font = data.Font;
        _urlPartTotalHeight = data.URLPart.border.height;
        _toolbarHeight = data.ToolbarPart.border.height;
        _searchComboBoxHeight = data.SearchComboBoxPart.border.height;
        top = _urlPartTotalHeight + _toolbarHeight + _searchComboBoxHeight;
        if ( dataArray ) {
            _dataArray = dataArray;
        }
        if ( isResetScrollReq ) {
            _scrollIndex = 0;
        }
        //On control resize, if the viewport has space to show more tree nodes then adjust the scroll index accordingly to show more nodes. 
        if ( _scrollIndex > 0 && ( _count > ( _dataArray.length - _scrollIndex ) ) ) {
            if ( _dataArray.length > _count ) {
                idx = _scrollIndex = _dataArray.length - _count;
            } else {
                idx = _scrollIndex = 0;//Reset the scroll index to 0 if the tree length becomes less than the viewport count i.e. the complete tree can be shown within the viewport on resize.
            }
        } else {
            idx = _scrollIndex;
        }
        //nodeIdx is used in this for loop to find deepest node and is incremented depending on nodes visible in viewport
        nodeIdx = idx;
        for ( var i = 0; i < _count; i++ ) {
            svgNode = _vpSVgNodes[i];
            nodeData = _dataArray[nodeIdx];
            if ( nodeData ) {
                nodeBBoxInfo = _getNodeWidth( nodeData );
                if ( i === 0 ) {
                    nodeWidth = nodeBBoxInfo.nodeWidth;
                }
                if ( nodeWidth < nodeBBoxInfo.nodeWidth ) {
                    nodeWidth = nodeBBoxInfo.nodeWidth;
                }
            }
            nodeIdx++;
        }
        // Below for loop takes care of node icon, expand/collapse icon, node text, selection of node, alarm data
        _selectedSvgNode = null;
        _selectedAlarmIconNode = null;
        for ( i = 0; i < _count; i++ ) {
            svgNode = _vpSVgNodes[i];
            nodeData = _dataArray[idx];
            if ( nodeData ) {
                nodeProps.isSelected = nodeData.isSelected;
                nodeProps.hasSearchText = nodeData.hasSearchText;
                y = i * _nodeHeight;
                nodeText = _createText( _dataArray[idx] );
                svgNode.createText( nodeText, data, i );
                svgNode.createNodeIcon( nodeText, i );
                svgNode.update( nodeData, _left, y );
                svgNode.setStyleForNode( nodeProps, data, i );
                if ( isAlarmsPresent ) {
                    alarmIconNode = _vpAlarmIconNodes[i];
                    alarmIconNode.updateAlarmIcon( nodeData, y, data.Width );
                    alarmIconNode.setStyleForAlarmNode( nodeData.isSelected, data, i );
                }
                self.updateSelectedNodes( nodeProps.isSelected, svgNode, alarmIconNode, isAlarmsPresent );
                _alarmSummaryData.push( nodeData.fullPath );
                idx++;
            } else {
                svgNode.update();
                if ( isAlarmsPresent ) {
                    alarmIconNode = _vpAlarmIconNodes[i];
                    alarmIconNode.setStyleForAlarmNode( false, data, i );
                }
            }
        }
        if ( nodeBBoxInfo ) {
            nodeBBoxInfo.nodeWidth = nodeWidth;
        }
        return nodeBBoxInfo;
    };

    this.createAlarmBgRects = function ( parent, data ) {
        var i, alarmIconNode, attrs;
        _vpAlarmIconNodes = [];
        for ( i = 0; i < _count + 1; i++ ) {
            attrs = {};
            attrs = _getBgAttributes( parent, data, i );
            alarmIconNode = new CPM.svgNode( { index: i, selectionColor: data.SelectionBackColor, selectionForeColor: data.SelectionForeColor } );
            alarmIconNode.createAlarmIconGroup( attrs );
            _vpAlarmIconNodes.push( alarmIconNode );
        }
    };

    this.updateSelectedNodes = function ( isSelected, svgNode, alarmIconNode, isAlarmsPresent ) {
        if ( isSelected)  {
            _selectedSvgNode = svgNode;
            if ( isAlarmsPresent ) {
                _selectedAlarmIconNode = alarmIconNode;
            }
        }
    };

    this.onScroll = function ( yValue, stylePropObj, isScrollbarCreated, isAlarmsPresent, horizontalLine ) {
        var bBoxData;
        _scrollIndex = yValue;
        bBoxData = _updateOnScroll( stylePropObj, isScrollbarCreated, isAlarmsPresent, horizontalLine );
        return bBoxData;
    };

    this.getScrollIndex = function () {
        return _scrollIndex;
    };

    this.getNodeData = function ( target ) {
        var idArray = target.id.split( '_' ), idx;
        idx = parseInt( idArray[idArray.length - 1] ) + _scrollIndex;
        //if ( idx > _count ) {
        //    idx = parseInt( idArray[idArray.length - 1] );
        //}
        return _dataArray[idx];

    };
    this.resetDataArray = function ( data ) {
        _dataArray = data;
    };
    this.getIconTextGroup = function () {
        return _nodeTextGroup;
    };
    this.setSelectedNode = function ( node, stylePropObj, isAlarmsPresent, horizontalLine ) {
        var vpIndx, nodeProps = {};
        if ( node ) {
            vpIndx = node.index - _scrollIndex;
            if ( vpIndx === _vpSVgNodes.length - 2 && horizontalLine ) {
                return;
            }
            if ( _vpSVgNodes[vpIndx] ) {
                _selectedSvgNode = _vpSVgNodes[vpIndx];
                nodeProps.isSelected = node.isSelected;
                nodeProps.hasSearchText = node.hasSearchText;
                _selectedSvgNode.setStyleForNode( nodeProps, stylePropObj, vpIndx );
            }
            if ( isAlarmsPresent && _vpAlarmIconNodes[vpIndx] ) {
                _selectedAlarmIconNode = _vpAlarmIconNodes[vpIndx];
                _selectedAlarmIconNode.setStyleForAlarmNode( node.isSelected, stylePropObj, vpIndx );
            }
        }
    };
    this.updateAlarmSummary = function ( data, styleProp, isScrollbarCreated, isAlarmsPresent, horizontalLine ) {
        var len, i, fullPath, ctrlWidth, y, lineColor, foreColor, lastNodeIdx, nodeProps = {},
            dataLength, svgNode, alarmIconNode, scrollBarWidth, top, dataIndex;
        len = _vpSVgNodes.length;
        lineColor = styleProp.stylePropObj.Control.HorizLineColor;
        foreColor = styleProp.stylePropObj.Control.ForeColor;
        scrollBarWidth = styleProp.stylePropObj.ScrollBar.Width;
        if ( horizontalLine ) {
            dataLength = _count - 1;
        }
        ctrlWidth = _ctrlWidth;
        if ( data ) {
            _alarmDataFromServer = data;
        }
        if ( Object.keys( _alarmDataFromServer ).length ) {
            if ( isAlarmsPresent ) {
                ctrlWidth = ctrlWidth - CPM.Enums.Constants.alarmIconWidth;
            }
            if ( isScrollbarCreated ) {
                if ( !isAlarmsPresent ) {
                    ctrlWidth = ctrlWidth + scrollBarWidth;
                }
                ctrlWidth = ctrlWidth - scrollBarWidth;
            }
            top = _urlPartTotalHeight + _toolbarHeight + _searchComboBoxHeight;
            for ( i = 0; i < len; i++ ) {
                fullPath = _alarmSummaryData[i];
                y = top + ( i * _nodeHeight );
                svgNode = _vpSVgNodes[i];
                if ( isAlarmsPresent ) {
                    alarmIconNode = _vpAlarmIconNodes[i];
                    alarmIconNode.changeAlarmSeperatorState( ctrlWidth, lineColor, foreColor, y );
                    dataIndex = i + _scrollIndex;
                    if ( _dataArray[dataIndex] ) {
                        alarmIconNode.setStyleForAlarmNode( _dataArray[dataIndex].isSelected, styleProp, i );
                        if ( data && _dataArray[dataIndex].isSelected ) {
                            _selectedAlarmIconNode = alarmIconNode;
                        }
                    }
                    svgNode.updateRectWidth( ctrlWidth );
                } else {
                    svgNode.updateRectWidth( _ctrlWidth );
                }
                _updateSummary( i, fullPath );
                if ( dataLength === i ) {
                    svgNode.hideLastNode();
                    alarmIconNode = _vpAlarmIconNodes[i];
                    alarmIconNode.hideLastAlarmNode();
                    if ( _dataArray[dataLength] && _dataArray[dataLength].isSelected ) {
                        nodeProps.isSelected = false;
                        nodeProps.hasSearchText = _dataArray[dataLength].hasSearchText;
                        svgNode.setStyleForNode( nodeProps, styleProp, i );
                        alarmIconNode.setStyleForAlarmNode( false, styleProp, i );
                    }
                } else {
                    if ( !isAlarmsPresent ) {
                        svgNode.showLastNode();
                        lastNodeIdx = len - 2;
                        dataIndex = i + _scrollIndex;
                        if ( dataIndex === lastNodeIdx && _dataArray[dataIndex] && _dataArray[dataIndex].isSelected ) {
                            nodeProps.isSelected = true;
                            nodeProps.hasSearchText = _dataArray[dataIndex].hasSearchText;
                            svgNode.setStyleForNode( nodeProps, styleProp, i );
                        }
                    }
                }
            }
        }
    };
    this.updateSelectionBackColor = function ( color ) {
        if ( _selectedSvgNode ) {
            _selectedSvgNode.updateSelectionBackColor( color );
            if ( _selectedAlarmIconNode ) {
                _selectedAlarmIconNode.updateSelectionBackColor( color );
            }
        }
    };

    this.updateSelectionForeColor = function ( color ) {
        if ( _selectedSvgNode ) {
            _selectedSvgNode.updateSelectionForeColor( color );
        }
    };
    this.updateNodeStyle = function ( stylePropObj, isAlarmsPresent ) {
        var i, vpLength, altBackFill, svgNode, alarmIconNode, nodeObj, dataIndex, nodeProps = {};
        vpLength = _vpSVgNodes.length;
        for ( i = 0; i < vpLength; i++ ) {
            altBackFill = ( i % 2 !== 0 ) ? stylePropObj.grey3 : stylePropObj.white;
            svgNode = _vpSVgNodes[i];
            dataIndex = i + _scrollIndex;
            nodeObj = _dataArray[dataIndex];
            svgNode.updateNodeStyle( stylePropObj, altBackFill, false );
            if ( nodeObj && nodeObj.isSelected ) {
                nodeProps.isSelected = true;
                nodeProps.hasSearchText = nodeObj.hasSearchText;
                svgNode.setStyleForNode( nodeProps, stylePropObj, i );
            }
            if ( isAlarmsPresent ) {
                alarmIconNode = _vpAlarmIconNodes[i];
                alarmIconNode.updateNodeStyle( stylePropObj, altBackFill, isAlarmsPresent );
                if ( nodeObj && nodeObj.isSelected ) {
                    alarmIconNode.setStyleForAlarmNode( nodeObj.isSelected, stylePropObj, i );
                }
            }
        }
    };

};
var CPM = ( CPM || {} );

CPM.breadcrumb = function () {
    var _urlPartGroup, _top, _nodeHeight, _urlHeight, _borderWidth, _strokeWidth, _font, _urlData, _viewPortData, _crumbData,
        _prevNode, _bCSvgGroup, _urlGroup, _treeGroup, _startImgRectGroup, _stylePropObj, _pathBackRect, _pathRect, _urlBottomLine,

    _removeBgColor = function ( evt ) {
        var target = evt.target || evt.srcElement,
            idArray = target.id.split( '_' ), idx, nodeImageRect, nodeImagePath;
        idx = parseInt( idArray[idArray.length - 1] );
        if ( target.id.indexOf( 'NodeURL' ) !== -1 ) {
            nodeImageRect = _treeGroup.getElementById( 'rect_NodeImage_' + idx );
            if ( nodeImageRect ) {
                nodeImageRect.setAttribute( 'fill', 'transparent' );
                nodeImageRect.setAttribute( 'stroke-width', '0px' );
            }
            nodeImagePath = _treeGroup.getElementById( 'path_NodeImage_' + idx );
            if ( nodeImagePath ) {
                nodeImagePath.setAttribute( 'stroke', _stylePropObj.BreadCrumb.IconColor );
            }
        } else {
            if ( target.id.indexOf( 'StartImage' ) !== -1 && _urlData.length !== _viewPortData.length && _startImgRectGroup ) {
                _startImgRectGroup.setAttribute( 'fill', 'transparent' );
                _startImgRectGroup.setAttribute( 'stroke-width', '0px' );
            }
        }

    };

    this.createBCRects = function ( parent, urlGroup, data ) {
        _top = data.Top;
        _nodeHeight = data.nodeHeight;
        _urlHeight = data.urlHeight;
        _borderWidth = data.borderWidth;
        _strokeWidth = data.strokeWidth;
        _font = data.Font;
        _treeGroup = parent;
        _urlGroup = urlGroup;
        _stylePropObj = data.stylePropObj;

        _pathBackRect = CPM.svgUtil.createSVG( 'rect', {
            id: 'pathBackRect',
            x: 0,
            y: 0,
            width: data.Width,
            height: CPM.Enums.Constants.urlHeight,
            fill: _stylePropObj.BreadCrumb.BackColor,
            opacity: 1,
            appendTo: _urlGroup
        } );

        _urlBottomLine = CPM.svgUtil.createSVG( 'line', {
            x1: 0,
            y1: CPM.Enums.Constants.urlHeight,
            x2: data.Width,
            y2: CPM.Enums.Constants.urlHeight,
            stroke: _stylePropObj.BreadCrumb.BottomBorderColor,
            'stroke-width': 1,
            appendTo: _urlGroup
        } );
        _pathRect = CPM.svgUtil.createSVG( 'rect', {
            id: 'pathRect',
            x: 0,
            y: 0,
            width: data.Width,
            height: CPM.Enums.Constants.urlHeight - ( CPM.Enums.Constants.urlHeight - data.imageHeight ) / 2, //_urlHeight- ( _urlHeight - data.imageHeight ) / 2,
            fill: _stylePropObj.BreadCrumb.BackColor,
            opacity: 1,
            appendTo: _urlGroup
        } );

        _urlPartGroup = CPM.svgUtil.createSVG( 'g', {
            id: 'URLPart',
            appendTo: _urlGroup
        } );
    };

    this.updateBCStyle = function ( stylePropObj ) {
        var startImage, length, i, urlText, nodeImagePath;
        _stylePropObj = stylePropObj;
        if ( _pathBackRect ) {
            _pathBackRect.setAttribute( 'fill', _stylePropObj.BreadCrumb.BackColor );
        }
        if ( _pathRect ) {
            _pathRect.setAttribute( 'fill', _stylePropObj.BreadCrumb.BackColor );
        }
        if ( _urlBottomLine ) {
            _urlBottomLine.setAttribute( 'stroke', _stylePropObj.BreadCrumb.BottomBorderColor );
        }
        startImage = _treeGroup.getElementById( 'path_StartImage' );
        if ( startImage ) {
            startImage.setAttribute( 'stroke', _stylePropObj.BreadCrumb.IconColor );
        }
        length = _urlData.length;
        for ( i = 0; i < length; i++ ) {
            urlText = _treeGroup.getElementById( 'text_NodeText_' + i );
            if ( urlText ) {
                if ( i === 0 ) {
                    urlText.setAttribute( 'fill', _stylePropObj.BreadCrumb.SelectionForeColor );
                } else {
                    urlText.setAttribute( 'fill', _stylePropObj.BreadCrumb.ForeColor );
                }
            }
            nodeImagePath = _treeGroup.getElementById( 'path_NodeImage_' + i );
            if ( nodeImagePath ) {
                nodeImagePath.setAttribute( 'stroke', _stylePropObj.BreadCrumb.IconColor );
            }
        }
    };
    this.createURLPart = function ( urlData ) {
        var startImageGroup, linearGrad, defsGroup, svg1;
        _urlData = urlData.data;
        CPM.svgUtil.createSVG( 'rect', {
            x: 0,
            y: 0,
            width: _borderWidth,
            height: CPM.Enums.Constants.urlHeight,
            stroke: 'none',
            'stroke-width': _strokeWidth,
            fill: 'none',
            id: 'URLViewPort',
            appendTo: _urlPartGroup
        } );

        //Creating elements required for Start Image
        startImageGroup = CPM.svgUtil.createSVG( 'g', {
            id: 'StartImage',
            appendTo: _urlPartGroup
        } );

        startImageGroup.addEventListener( 'mouseleave', _removeBgColor );//Event added to remove the background color if any, on the start image
        //Defining gradient color for url parts on mouse hover
        defsGroup = CPM.svgUtil.createSVG( 'defs', {
            appendTo: startImageGroup
        } );

        linearGrad = CPM.svgUtil.createSVG( 'linearGradient', {
            id: 'urlNodeGradient',
            x1: '0%',
            x2: '0%',
            y1: '0%',
            y2: '100%',
            appendTo: defsGroup
        } );

        CPM.svgUtil.createSVG( 'stop', {
            offset: '0%',
            'stop-color': '#91939A',
            'stop-opacity': 1,
            appendTo: linearGrad
        } );

        CPM.svgUtil.createSVG( 'stop', {
            offset: '100%',
            'stop-color': '#F2F4FF',
            'stop-opacity': 1,
            appendTo: linearGrad
        } );

        _startImgRectGroup = CPM.svgUtil.createSVG( 'rect', {
            id: 'rect_StartImage',
            x: urlData.textPadding.left - ( ( urlData.imageIconRect.width - urlData.imageIconSvg.width ) / 2 ),
            y: CPM.Enums.Constants.topPadding,
            width: urlData.imageIconRect.width,
            height: urlData.imageIconRect.height,
            fill: 'transparent',
            stroke: 'rgba(100, 100, 106, 0.5)',
            'stroke-width': '0px',
            appendTo: startImageGroup
        } );

        svg1 = CPM.svgUtil.createSVG( 'svg', {
            id: 'svg_StartImage',
            x: urlData.textPadding.left - ( ( urlData.imageIconRect.width - urlData.imageIconSvg.width ) / 2 ),
            y: CPM.Enums.Constants.topPadding,
            width: urlData.imageIconRect.width,
            height: CPM.Enums.Constants.urlHeight,
            appendTo: startImageGroup
        } );

        //StartImage Icon
        if ( urlData.data.length === urlData.viewportData.length ) {
            startImageGroup.setAttribute( 'pointer-events', 'none' );
            CPM.svgUtil.createSVG( 'path', {
                id: 'path_StartImage',
                d: 'M7 7.5 l 5 5 l -5 5',
                fill: 'none',
                stroke: _stylePropObj.BreadCrumb.IconColor,
                'stroke-width': '1px',
                appendTo: svg1
            } );
        } else {
            startImageGroup.removeAttribute( 'pointer-events' );
            CPM.svgUtil.createSVG( 'path', {
                id: 'path_StartImage',
                d: 'M16 6.5 l -4 5 l 4 5',
                fill: 'none',
                stroke: _stylePropObj.BreadCrumb.IconColor,
                'stroke-width': '1px',
                appendTo: svg1
            } );

            CPM.svgUtil.createSVG( 'path', {
                id: 'path_StartImage',
                d: 'M10 6.5 l -4 5 l 4 5',
                fill: 'none',
                stroke: _stylePropObj.BreadCrumb.IconColor,
                'stroke-width': '1px',
                appendTo: svg1
            } );
        }
    };

    this.updateNodeURL = function ( urlData ) {
        var i, nodeData, nodeURLGroup, nodeTextGroup, nodeText, nodeImageGroup, imageSvg, length = urlData.viewportData.length;
        _viewPortData = urlData.viewportData;
        _urlHeight = urlData.border.height;
        if ( _urlPartGroup ) {
            while ( _urlPartGroup.firstChild ) {
                _urlPartGroup.removeChild( _urlPartGroup.firstChild );
            }
            this.createURLPart( urlData );
        }
        //Creating the url parts based on the current viewport size
        for ( i = 0; i < length; i++ ) {
            nodeData = urlData.viewportData[i];

            nodeURLGroup = CPM.svgUtil.createSVG( 'g', {
                id: 'NodeURL_' + i,
                appendTo: _urlPartGroup
            } );

            nodeURLGroup.addEventListener( 'mouseleave', _removeBgColor );//Event added to remove the background color if any, on the current url part.

            nodeTextGroup = CPM.svgUtil.createSVG( 'g', {
                id: 'NodeText',
                appendTo: nodeURLGroup
            } );

            CPM.svgUtil.createSVG( 'rect', {
                id: 'rect_NodeText_' + i,
                x: nodeData.x,
                y: 0,
                width: nodeData.width + urlData.imageIconSvg.width + urlData.textPadding.left + urlData.textPadding.right,
                height: CPM.Enums.Constants.urlHeight,
                fill: 'transparent',
                stroke: 'rgba(100, 100, 106, 0.5)',
                'stroke-width': '0px',
                appendTo: nodeTextGroup
            } );

            nodeText = CPM.svgUtil.createSVG( 'text', {
                id: 'text_NodeText_' + i,
                x: nodeData.x,
                y: nodeData.height + CPM.Enums.Constants.topPadding,
                'font-size': urlData.font.size,
                fill: i === 0 ? _stylePropObj.BreadCrumb.SelectionForeColor : _stylePropObj.BreadCrumb.ForeColor,
                'font-family': _font.family,
                'font-weight': 'bold',
                appendTo: nodeTextGroup
            } );

            nodeText.textContent = nodeData.name;

            //Do not create BC Node Image if the node is leaf node
            if ( !nodeData.IsLeaf ) {
                nodeImageGroup = CPM.svgUtil.createSVG( 'g', {
                    id: 'NodeImage',
                    appendTo: nodeURLGroup
                } );

                CPM.svgUtil.createSVG( 'rect', {
                    id: 'rect_NodeImage_' + i,
                    x: nodeData.x + nodeData.width + ( urlData.textPadding.left - urlData.imageIconSvg.width ) / 2,
                    y: ( _urlHeight - urlData.imageIconRect.height ) / 2,
                    width: urlData.imageIconRect.width,
                    height: urlData.imageIconRect.height,
                    fill: 'transparent',
                    stroke: 'rgba(100, 100, 106, 0.5)',
                    'stroke-width': '0px',
                    appendTo: nodeImageGroup
                } );

                imageSvg = CPM.svgUtil.createSVG( 'svg', {
                    id: 'svg_NodeImage_' + i,
                    x: nodeData.x + nodeData.width + ( urlData.textPadding.left - urlData.imageIconSvg.width ) / 2,
                    y: CPM.Enums.Constants.topPadding,
                    width: urlData.imageIconRect.width,
                    height: CPM.Enums.Constants.urlHeight,
                    appendTo: nodeImageGroup
                } );

                CPM.svgUtil.createSVG( 'path', {
                    id: 'path_NodeImage_' + i,
                    d: 'M7 7.5 l 5 5 l -5 5',
                    fill: 'none',
                    stroke: _stylePropObj.BreadCrumb.IconColor,
                    'stroke-width': '1px',
                    appendTo: imageSvg
                } );
            }
        }
    };

    this.getBCNode = function ( target ) {
        var idArray = target.id.split( '_' ), idx;
        idx = parseInt( idArray[idArray.length - 1] );
        return _viewPortData[idx];
    };

    this.setBgColor = function ( evtType, target ) {
        var idArray = target.id.split( '_' ), idx, nodeImageRect, fill, nodeImagePath;
        idx = parseInt( idArray[idArray.length - 1] );
        if ( evtType === 'mouseover' || evtType === 'mouseup' || evtType === 'touchend' ) {
            fill = _stylePropObj.BreadCrumb.ButtonColor;
        } else {
            if ( evtType === 'mousedown' || evtType === 'touchstart' ) {
                fill = _stylePropObj.BreadCrumb.PressedButtonColor;
            }
        }
        if ( target.id.indexOf( 'StartImage' ) !== -1 && _urlData.length !== _viewPortData.length ) {
            if ( _startImgRectGroup ) {
                _startImgRectGroup.setAttribute( 'fill', fill );
                _startImgRectGroup.setAttribute( 'stroke-width', '1px' );
            }
        } else {
            nodeImageRect = _treeGroup.getElementById( 'rect_NodeImage_' + idx );
            nodeImagePath = _treeGroup.getElementById( 'path_NodeImage_' + idx );
            if ( nodeImageRect ) {
                nodeImageRect.setAttribute( 'fill', fill );
                nodeImageRect.setAttribute( 'stroke-width', '1px' );
                nodeImagePath.setAttribute( 'stroke', _stylePropObj.BreadCrumb.PressedIconColor );
            }
        }
    };

    this.updateNodeImage = function ( target ) {
        var idArray, idx, nodeImagePath;
        if ( target ) {
            idArray = target.id.split( '_' );
            idx = parseInt( idArray[idArray.length - 1] );
            nodeImagePath = _treeGroup.getElementById( 'path_NodeImage_' + idx );
            if ( nodeImagePath ) {
                nodeImagePath.setAttribute( 'd', 'M6 12 l 5 5 l 5 -5' );//Update the image to downward arrow whenever the children of a node is displayed from breadcrumb.
                if ( _prevNode && _prevNode.id !== nodeImagePath.id ) {
                    _prevNode.setAttribute( 'd', 'M7 7.5 l 5 5 l -5 5' );//Reset the image to forward arrow if any previous node's children were displayed in breadcrumb.
                }
                _prevNode = nodeImagePath;
                return;
            }
        }
        if ( _prevNode ) {
            _prevNode.setAttribute( 'd', 'M7 7.5 l 5 5 l -5 5' );//Reset the image to forward arrow if any previous node's children were displayed in breadcrumb.
            _prevNode = null;
        }
    };

    this.createBreadCrumb = function ( crumbCollection, data, toolbarHeight, imageIconRectHeight ) {
        var i, length = crumbCollection.length, svgGroup, breadCrumbGroup, crumbGroup, crumbSvg, crumbText, left, top, bgRect;
        _crumbData = crumbCollection;
        left = data.crumbX;
        top = CPM.Enums.Constants.urlHeight + toolbarHeight - imageIconRectHeight / 2 + ( 2 * CPM.Enums.Constants.textBottomPadding );

        if ( length > 0 ) {
            if ( !_bCSvgGroup ) {
                _bCSvgGroup = CPM.svgUtil.createSVG( 'svg', {
                    id: 'breadCrumSvg',
                    y: top,
                    style: 'position:absolute; left:0px; top:0px;',
                    appendTo: data.divParent
                } );
            }

            bgRect = CPM.svgUtil.createSVG( 'rect', {
                x: '0',
                y: '0',
                width: data.crumbNodeNameWidth + ( 2 * CPM.Enums.Constants.textLeftPadding ) + CPM.Enums.Constants.polyDimH,
                height: data.crumbHeight,
                fill: _stylePropObj.Control.EvenBackColor,
                stroke: 'none',
                style: 'position:absolute; left:0px; top:0px;',
                appendTo: _bCSvgGroup
            } );
            _bCSvgGroup.setAttribute( 'x', left );
            _bCSvgGroup.setAttribute( 'width', data.crumbNodeNameWidth + ( 2 * CPM.Enums.Constants.textLeftPadding ) + CPM.Enums.Constants.polyDimH );
            _bCSvgGroup.setAttribute( 'height', data.crumbHeight + 7 );
            _bCSvgGroup.style.left = bgRect.style.left = left + 'px';
            _bCSvgGroup.style.top = bgRect.style.top = top + 'px';
        }

        svgGroup = CPM.svgUtil.createSVG( 'svg', {
            height: data.crumbHeight + CPM.Enums.Constants.urlHeight + toolbarHeight,
            width: data.crumbNodeNameWidth + ( 2 * CPM.Enums.Constants.textLeftPadding ) + CPM.Enums.Constants.polyDimH,
            appendTo: _bCSvgGroup
        } );

        breadCrumbGroup = CPM.svgUtil.createSVG( 'g', {
            id: 'breadcrumbGroup',
            transform: 'translate(0,0)',
            appendTo: svgGroup
        } );
        //Creating the elements to display immediate children of for the node selected from breadcrumb
        for ( i = 0; i < length; i++ ) {
            crumbGroup = CPM.svgUtil.createSVG( 'g', {
                id: 'breadcrumbGroup_g_' + i,
                appendTo: breadCrumbGroup
            } );

            CPM.svgUtil.createSVG( 'rect', {
                id: _crumbData[i].isSelected ? 'breadcrumbGroup_rect_Selected_' + i : 'breadcrumbGroup_rect_' + i,
                x: '0',
                y: ( i * _nodeHeight ),
                width: data.crumbNodeNameWidth + ( 2 * CPM.Enums.Constants.textLeftPadding ) + CPM.Enums.Constants.polyDimH,
                height: _nodeHeight,
                fill: _crumbData[i].isSelected ? data.active : i % 2 === 0 ? data.white : data.grey3,
                'stroke-width': '0px',
                appendTo: crumbGroup
            } );

            crumbText = CPM.svgUtil.createSVG( 'text', {
                id: 'breadcrumbGroup_text_' + i,
                x: ( 2 * CPM.Enums.Constants.textLeftPadding ) - CPM.Enums.Constants.horizontalgap,
                y: ( i * _nodeHeight ) + ( 11 * CPM.Enums.Constants.textBottomPadding ),
                fill: _crumbData[i].isSelected ? data.SelectionForeColor : data.foreColor,
                'font-family': _font.family,
                'font-size': _font.Size,
                appendTo: crumbGroup
            } );

            crumbText.textContent = _crumbData[i].Name;

            //Icon to be displayed for each children
            crumbSvg = CPM.svgUtil.createSVG( 'svg', {
                x: CPM.Enums.Constants.polyDimH,
                y: ( i * _nodeHeight ) + ( 3 * CPM.Enums.Constants.textBottomPadding ),
                fill: _crumbData[i].isSelected ? data.SelectionNodeIconColor : _stylePropObj.Control.NodeIconColor,
                appendTo: crumbGroup
            } );

            CPM.svgUtil.createSVG( 'path', {
                id: 'breadcrumbGroup_path1_' + i,
                d: 'M10,7,5.5,11.5,10,16l4.5-4.5ZM6.91,11.5,10,8.41v6.17Z',
                appendTo: crumbSvg
            } );

            CPM.svgUtil.createSVG( 'path', {
                id: 'breadcrumbGroup_path2_' + i,
                d: 'M18.5,6.5,15,3,11.5,6.5,15,10Zm-5.59,0L15,4.41V8.59Z',
                appendTo: crumbSvg
            } );

            CPM.svgUtil.createSVG( 'path', {
                id: 'breadcrumbGroup_path3_' + i,
                d: 'M11.5,16.5,15,20l3.5-3.5L15,13Zm1.41,0L15,14.41v4.17Z',
                appendTo: crumbSvg
            } );
        }

        if ( length > 0 ) {
            CPM.svgUtil.createSVG( 'rect', {
                x: '0',
                y: '0',
                width: data.crumbNodeNameWidth + ( 2 * CPM.Enums.Constants.textLeftPadding ) + CPM.Enums.Constants.polyDimH,
                height: data.crumbHeight,
                fill: 'none',
                stroke: 'none',
                appendTo: _bCSvgGroup
            } );
        }
        return _bCSvgGroup;
    };

    this.resetDims = function () {
        if( _bCSvgGroup ){
            _bCSvgGroup.setAttribute( 'height', '0' );
            _bCSvgGroup.setAttribute( 'width', '0' );
        }
    };

    this.unloadBreadCrumb = function () {
        if ( _bCSvgGroup ) {
            while ( _bCSvgGroup.firstChild ) {
                _bCSvgGroup.removeChild( _bCSvgGroup.firstChild );
            }
            _bCSvgGroup.parentElement.removeChild(_bCSvgGroup);
            _bCSvgGroup = null;
        }
    };

    this.getCrumbNode = function ( target ) {
        var idArray = target.id.split( '_' ), idx;
        idx = parseInt( idArray[idArray.length - 1] );
        return _crumbData[idx];
    };

    this.remove = function () {
        while ( _urlGroup && _urlGroup.firstChild ) {
            _urlGroup.removeChild( _urlGroup.firstChild );
        }
    };
};
var CPM = ( CPM || {} );

CPM.toolbar = function ( currStyle ) {
    var _left, _toolbarPart, _toolbarGroup, _treeControl, topVal, height,
        self = this,
        _constants = CPM.Enums.Constants,
        _toolbarBtns = CPM.Enums.ToolbarButtons,
        _expandAllGroup, _expandAllBtnOpacity,
        _collapseAllGroup, _collapseAllBtnOpacity,
        _filterGroup, _filterBtnState,
        _toolbarBackRect, _toolbarBottomLine,
        _separatorLine = null,
        _styleFactory = CPM.StyleFactory.getCurrentStyleProps( currStyle ),
        _isExtendedStyle = currStyle.includes( CPM.Enums.StyleName.Extended ) ? true : false,
        _pressedbuttonStyles,
        _expPolygon, _collPolygon, _filterPolygon, _iconRectArray = [],

    _createExpandBorder = function () {
        CPM.svgUtil.createSVG( 'line', {
            id: 'ExpandAll_Line',
            x1: 2 * _left,
            x2: 2 * _left + _toolbarPart.border.width,
            y1: topVal + height - 1,
            y2: topVal + height - 1,
            'stroke-width': '2px',
            stroke: _styleFactory.ToolBar.BottomBorder,
            appendTo: _expandAllGroup
        } );
    },
    _createExpandAllButton = function () {
        var svgGroup, parentGroup, polygonGroup, rectGroup1, rectGroup2, rectGroup3;
        _expandAllGroup = CPM.svgUtil.createSVG( 'g', {
            id: 'ExpandAll',
            opacity: _expandAllBtnOpacity,
            appendTo: _toolbarGroup
        } );

        _expandAllGroup.addEventListener( 'mouseleave', self.updateToolbarColor ); //Event added to update button gradient color on mouseleave
        if ( _isExtendedStyle ) {
            _createGradientElement( _expandAllGroup, _toolbarBtns.ExpandAll ); //Define default gradient color for the button
        }

        CPM.svgUtil.createSVG( 'rect', {
            id: 'ExpandAll_Rect',
            x: 2 * _left,
            y: topVal,
            width: _toolbarPart.border.width,
            height: height,
            stroke: _styleFactory.ToolBar.BorderColor1,
            'stroke-width': '1px',
            fill: _styleFactory.ToolBar.Fill,
            rx: _styleFactory.ToolBar.Rx,
            appendTo: _expandAllGroup
        } );
        if ( !_isExtendedStyle ) {
            _createExpandBorder();
        }
        //Svg part (icon) of ExpandAll button
        svgGroup = CPM.svgUtil.createSVG( 'svg', {
            id: 'ExpandAll_Svg',
            x: ( 3 * _left ) + _toolbarPart.border.strokeWidth + _toolbarPart.border.iconSpacing,
            y: topVal + 7,
            'shape-rendering': 'crispEdges',
            appendTo: _expandAllGroup
        } );

        parentGroup = CPM.svgUtil.createSVG( 'g', {
            appendTo: svgGroup
        } );

        polygonGroup = CPM.svgUtil.createSVG( 'g', {
            appendTo: parentGroup
        } );

        _createRect( polygonGroup, 'ExpandAll_rect1', 5, 7.83, 2, 9 );

        _expPolygon = CPM.svgUtil.createSVG( 'polygon', {
            id: 'ExpandAll_polygon',
            fill: _styleFactory.ToolBar.IconColor,
            points: '3 15.83 5.96 19.83 9 15.83 3 15.83',
            appendTo: polygonGroup
        } );

        _createRect( parentGroup, 'ExpandAll_rect2', 5, 2.83, 16, 4 );

        rectGroup1 = CPM.svgUtil.createSVG( 'g', {
            appendTo: parentGroup
        } );
        _createRect( rectGroup1, 'ExpandAll_rect3', 10, 7.83, 11, 1 );
        _createRect( rectGroup1, 'ExpandAll_rect4', 10, 9.83, 11, 1 );
        _createRect( rectGroup1, 'ExpandAll_rect5', 10, 7.83, 1, 3 );
        _createRect( rectGroup1, 'ExpandAll_rect6', 20, 7.83, 1, 3 );

        rectGroup2 = CPM.svgUtil.createSVG( 'g', {
            appendTo: parentGroup
        } );
        _createRect( rectGroup2, 'ExpandAll_rect7', 10, 11.83, 11, 1 );
        _createRect( rectGroup2, 'ExpandAll_rect8', 10, 13.83, 11, 1 );
        _createRect( rectGroup2, 'ExpandAll_rect9', 10, 11.83, 1, 3 );
        _createRect( rectGroup2, 'ExpandAll_rect10', 20, 11.83, 1, 3 );

        rectGroup3 = CPM.svgUtil.createSVG( 'g', {
            appendTo: parentGroup
        } );
        _createRect( rectGroup3, 'ExpandAll_rect11', 10, 15.83, 11, 1 );
        _createRect( rectGroup3, 'ExpandAll_rect12', 10, 17.83, 11, 1 );
        _createRect( rectGroup3, 'ExpandAll_rect13', 10, 15.83, 1, 3 );
        _createRect( rectGroup3, 'ExpandAll_rect14', 20, 15.83, 1, 3 );

        CPM.svgUtil.createSVG( 'rect', {
            width: 26,
            height: 21.67,
            fill: 'none',
            appendTo: svgGroup
        } );
        //End of the ExpandAll icon
    },
    _createCollapseBorder = function () {
        CPM.svgUtil.createSVG( 'line', {
            id: 'CollapseAll_Line',
            x1: ( 4 * _left ) + _toolbarPart.border.width + _constants.toolbarPadding,
            x2: ( 4 * _left ) + _toolbarPart.border.width + _constants.toolbarPadding + _toolbarPart.border.width,
            y1: topVal + height - 1,
            y2: topVal + height - 1,
            'stroke-width': '2px',
            stroke: _styleFactory.ToolBar.BottomBorder,
            appendTo: _collapseAllGroup
        } );
    },

    _createCollapseAllButton = function () {
        var svgGroup, rectGroup, polygonGroup;
        _collapseAllGroup = CPM.svgUtil.createSVG( 'g', {
            id: 'CollapseAll',
            opacity: _collapseAllBtnOpacity,
            appendTo: _toolbarGroup
        } );
        _collapseAllGroup.addEventListener( 'mouseleave', self.updateToolbarColor ); //Event added to update button gradient color on mouseleave
        if ( _isExtendedStyle ) {
            _createGradientElement( _collapseAllGroup, _toolbarBtns.CollapseAll ); //Define default gradient color for the button
        }

        CPM.svgUtil.createSVG( 'rect', {
            id: 'CollapseAll_Rect',
            x: ( 4 * _left ) + _toolbarPart.border.width + _constants.toolbarPadding,
            y: topVal,
            width: _toolbarPart.border.width,
            height: height,
            stroke: _styleFactory.ToolBar.BorderColor1,
            'stroke-width': '1px',
            fill: _styleFactory.ToolBar.Fill,
            rx: _styleFactory.ToolBar.Rx,
            appendTo: _collapseAllGroup
        } );
        if ( !_isExtendedStyle ) {
            _createCollapseBorder();
        }
        //Svg part (icon) of CollapseAll button
        svgGroup = CPM.svgUtil.createSVG( 'svg', {
            id: 'CollapseAll_Svg',
            x: ( 5 * _left ) + _toolbarPart.border.strokeWidth + _toolbarPart.border.width + _constants.toolbarPadding + _toolbarPart.border.iconSpacing,
            y: topVal + 7,
            'shape-rendering': 'crispEdges',
            appendTo: _collapseAllGroup
        } );

        rectGroup = CPM.svgUtil.createSVG( 'g', {
            appendTo: svgGroup
        } );

        polygonGroup = CPM.svgUtil.createSVG( 'g', {
            appendTo: rectGroup
        } );

        _createRect( polygonGroup, 'CollapseAll_rect1', 5, 10.83, 2, 9 );

        _collPolygon = CPM.svgUtil.createSVG( 'polygon', {
            id: 'CollapseAll_polygon',
            fill: _styleFactory.ToolBar.IconColor,
            points: '9 11.83 6.04 7.83 3 11.83 9 11.83',
            appendTo: polygonGroup
        } );

        _createRect( rectGroup, 'CollapseAll_rect2', 5, 2.83, 16, 4 );

        CPM.svgUtil.createSVG( 'rect', {
            width: 26,
            height: 21.67,
            fill: 'none',
            appendTo: svgGroup
        } );
        //End of the CollapseAll icon
    },
    _createFilterBorder = function () {
        CPM.svgUtil.createSVG( 'line', {
            id: 'Filter_Line',
            x1: ( 6 * _left ) + ( 2 * _toolbarPart.border.width ) + ( 5 * _constants.toolbarPadding ) + 1,
            x2: ( 6 * _left ) + ( 2 * _toolbarPart.border.width ) + ( 5 * _constants.toolbarPadding ) + 1 + _toolbarPart.border.width,
            y1: topVal + height - 1,
            y2: topVal + height - 1,
            'stroke-width': '2px',
            stroke: _styleFactory.ToolBar.BottomBorder,
            appendTo: _filterGroup
        } );
    },
    _createFilterButton = function () {
        var svgGroup, rectGroup, polygonGroup;
        _filterGroup = CPM.svgUtil.createSVG( 'g', {
            id: 'FilterButton',
            opacity: 1,
            appendTo: _toolbarGroup
        } );
        _filterGroup.addEventListener( 'mouseleave', self.updateToolbarColor ); //Event added to update button gradient color on mouseleave
        if ( _isExtendedStyle ) {
            _createGradientElement( _filterGroup, _toolbarBtns.Filter ); //Define default gradient color for the button
        }
        _separatorLine = CPM.svgUtil.createSVG( 'line', {
            x1: ( 6 * _left ) + ( 2 * _toolbarPart.border.width ) + ( 2 * _constants.toolbarPadding ),
            y1: topVal,
            x2: ( 6 * _left ) + ( 2 * _toolbarPart.border.width ) + ( 2 * _constants.toolbarPadding ),
            y2: topVal + height,
            stroke: 'gray',
            'stroke-width': 1,
            appendTo: _filterGroup
        } );
        CPM.svgUtil.createSVG( 'rect', {
            id: 'FilterButton_Rect',
            x: ( 6 * _left ) + ( 2 * _toolbarPart.border.width ) + ( 5 * _constants.toolbarPadding ) + 1,
            y: topVal,
            width: _toolbarPart.border.width,
            height: height,
            stroke: _styleFactory.ToolBar.BorderColor1,
            'stroke-width': '1px',
            fill: _isExtendedStyle && ( _filterBtnState === 1 ) ? _pressedbuttonStyles['fill'] : _styleFactory.ToolBar.Fill,
            rx: _styleFactory.ToolBar.Rx,
            appendTo: _filterGroup
        } );
        if ( !_isExtendedStyle ) {
            _createFilterBorder();
        }
        //Svg part (icon) of CollapseAll button
        svgGroup = CPM.svgUtil.createSVG( 'svg', {
            id: 'FilterButton_Svg',
            x: ( 7 * _left ) + _toolbarPart.border.strokeWidth + ( 2 * _toolbarPart.border.width ) + ( 5 * _constants.toolbarPadding ) + _toolbarPart.border.iconSpacing,
            y: topVal + 7,
            'shape-rendering': 'crispEdges',
            appendTo: _filterGroup
        } );
        rectGroup = CPM.svgUtil.createSVG( 'g', {
            appendTo: svgGroup
        } );
        polygonGroup = CPM.svgUtil.createSVG( 'g', {
            appendTo: rectGroup
        } );
        _filterPolygon = CPM.svgUtil.createSVG( 'polygon', {
            id: 'FilterButton_polygon',
            fill: _styleFactory.ToolBar.IconColor,
            points: '19,3 12.5,14 6,3',
            appendTo: polygonGroup
        } );
        _createRect( polygonGroup, 'FilterButton_icon_rect', 11, 11, 3, 7 );
        CPM.svgUtil.createSVG( 'rect', {
            width: 26,
            height: 21.67,
            fill: 'none',
            appendTo: svgGroup
        } );
        //End of the FilterButton icon
    },
    _createGradientElement = function ( parentDom, elemId ) {
        var defsGroup, linearGrad;
        //Defining gradient color for toolbar buttons
        defsGroup = CPM.svgUtil.createSVG( 'defs', {
            appendTo: parentDom
        } );

        linearGrad = CPM.svgUtil.createSVG( 'linearGradient', {
            id: 'ButtonBgGradient_LigtherDarker_' + elemId,
            x1: '50%',
            x2: '50%',
            y1: '0%',
            y2: '100%',
            gradientUnits: 'objectBoundingBox',
            appendTo: defsGroup
        } );

        CPM.svgUtil.createSVG( 'stop', {
            offset: '0.0',
            'stop-color': _constants.stopColor1,
            'stop-opacity': '1.0',
            appendTo: linearGrad
        } );

        CPM.svgUtil.createSVG( 'stop', {
            offset: '1.0',
            'stop-color': _constants.stopColor2,
            'stop-opacity': '1.0',
            appendTo: linearGrad
        } );
    },

    //Reset the gradient colors of toolbar buttons to their default values
    _resetToDefaults = function ( btnType ) {
        var linearGrad, buttonRect;
        if ( btnType === _toolbarBtns.ExpandAll ) {
            linearGrad = _treeControl.getElementById( 'ButtonBgGradient_LigtherDarker_ExpandAll' );
            buttonRect = _treeControl.getElementById( 'ExpandAll_Rect' );
        } else if ( btnType === _toolbarBtns.CollapseAll ) {
            linearGrad = _treeControl.getElementById( 'ButtonBgGradient_LigtherDarker_CollapseAll' );
            buttonRect = _treeControl.getElementById( 'CollapseAll_Rect' );
        } else {
            if ( btnType === _toolbarBtns.Filter ) {
                linearGrad = _treeControl.getElementById( 'ButtonBgGradient_LigtherDarker_FilterButton' );
                buttonRect = _treeControl.getElementById( 'FilterButton_Rect' );
            }
        }
        if ( linearGrad && buttonRect ) {
            linearGrad.childNodes[0].setAttribute( 'stop-color', _constants.stopColor1 );
            linearGrad.childNodes[1].setAttribute( 'stop-color', _constants.stopColor2 );
            buttonRect.setAttribute( 'stroke', _constants.btnBorderColor1 );
        }
    },

    _createRect = function ( parentDom, id, x, y, width, rectHeight ) {
        var rect;
        rect = CPM.svgUtil.createSVG( 'rect', {
            id: id,
            x: x,
            y: y,
            width: width,
            height: rectHeight,
            fill: _styleFactory.ToolBar.IconColor,
            appendTo: parentDom
        } );
        _iconRectArray.push( rect );
    },
    _setAttributes = function ( element, property, value ) {
        if ( element ) {
            element.setAttribute( property, value );
        }
    },
    _setButtonStateColor = function ( currButton, currStyleToolBarProps ) {
        var currButtonFillColor;
        if ( currButton ) {
            currButtonFillColor = currButton.getAttribute( 'fill' );
            switch ( currButtonFillColor ) {
                case currStyleToolBarProps.Fill:
                    currButton.setAttribute( 'fill', _styleFactory.ToolBar.Fill );
                    break;
                case currStyleToolBarProps.Hover:
                    currButton.setAttribute( 'fill', _styleFactory.ToolBar.Hover );
                    break;
                case currStyleToolBarProps.Pressed:
                    currButton.setAttribute( 'fill', _styleFactory.ToolBar.Pressed );
                    break;
                default:
                    currButton.setAttribute( 'fill', _styleFactory.ToolBar.Fill );
                    break;
            }
        }
    },
    _updateIconColor = function () {
        var i, length = _iconRectArray.length;
        for ( i = 0; i < length; i++ ) {
            _setAttributes( _iconRectArray[i], 'fill', _styleFactory.ToolBar.IconColor );
        }
        _setAttributes( _expPolygon, 'fill', _styleFactory.ToolBar.IconColor );
        _setAttributes( _collPolygon, 'fill', _styleFactory.ToolBar.IconColor );
        _setAttributes( _filterPolygon, 'fill', _styleFactory.ToolBar.IconColor );
    };



    this.createToolbar = function ( parentDom, toolbarGroup, data, bottomLine ) {
        var yVal, stroke;
        _left = data.Left;
        _toolbarPart = data.ToolbarPart;
        topVal = _toolbarPart.border.buttonTop;
        height = _toolbarPart.border.buttonHeight;
        _treeControl = parentDom;
        _toolbarGroup = toolbarGroup;
        _pressedbuttonStyles = data.pressedbuttonStyles;
        _filterBtnState = data.filterBtnState;
        yVal = _toolbarPart.border.topVal;
        if ( data.Enabled ) {
            if ( !_expandAllBtnOpacity && !_collapseAllBtnOpacity ) {
                _expandAllBtnOpacity = _collapseAllBtnOpacity = 1;
            }
        } else {
            _expandAllBtnOpacity = _collapseAllBtnOpacity = 0.5;
        }
        _toolbarBackRect = CPM.svgUtil.createSVG( 'rect', {
            x: 0,
            y: yVal,
            id: 'toolbarBackgroundRect2',
            width: data.Width,
            height: CPM.Enums.Constants.toolbarHeight,
            fill: data.white,
            appendTo: _toolbarGroup
        } );
        _isExtendedStyle = data.isExtendedStyle;
        if ( _isExtendedStyle ) {
            stroke = _styleFactory.ToolBar.BottomLineColor;
        } else {
            if ( bottomLine ) {
                stroke = _styleFactory.Control.HorizLineColor;
            } else {
                stroke = _styleFactory.ToolBar.BottomLineColor;
            }
        }

        _toolbarBottomLine = CPM.svgUtil.createSVG( 'line', {
            x1: 0,
            y1: CPM.Enums.Constants.toolbarHeight - 1,
            x2: data.Width,
            y2: CPM.Enums.Constants.toolbarHeight - 1,
            stroke: stroke,
            'stroke-width': 1,
            appendTo: _toolbarGroup
        } );
        _createExpandAllButton();
        _createCollapseAllButton();
        _createFilterButton();
    };

    this.updateWidth = function ( width ) {
        _setAttributes( _toolbarBackRect, 'width', width );
        _setAttributes( _toolbarBottomLine, 'x2', width );
    };

    this.setExpandBtnOpacity = function ( expandBtnOpacity ) {
        if ( _expandAllBtnOpacity !== expandBtnOpacity ) {
            _expandAllBtnOpacity = expandBtnOpacity;
            if ( _expandAllBtnOpacity === 0.5 ) {
                _resetToDefaults( _toolbarBtns.ExpandAll ); //Reset the expandAll button to default colors when the button opacity is 0.5 (disabled).
                if ( !_isExtendedStyle ) {
                    this.removeExpandBtnLine();
                }
            }
            else {
                if ( !_isExtendedStyle ) {
                    this.setExpandBtnLine();
                }
            }
            _expandAllGroup.setAttribute( 'opacity', _expandAllBtnOpacity );
        }
    };

    this.setCollapseBtnOpacity = function ( collapseBtnOpacity ) {
        if ( _collapseAllBtnOpacity !== collapseBtnOpacity ) {
            _collapseAllBtnOpacity = collapseBtnOpacity;
            if ( _collapseAllBtnOpacity === 0.5 ) {
                _resetToDefaults( _toolbarBtns.CollapseAll ); //Reset the collapseAll button to default colors when the button opacity is 0.5 (disabled).
                if ( !_isExtendedStyle ) {
                    this.removeCollapseBtnLine();
                }
            }
            else {
                if ( !_isExtendedStyle ) {
                    this.setCollapseBtnLine();
                }
            }
            _collapseAllGroup.setAttribute( 'opacity', _collapseAllBtnOpacity );
        }
    };

    this.isExpandAllEnabled = function () {
        return _expandAllBtnOpacity === 1 ? true : false;
    };

    this.isCollapseAllEnabled = function () {
        return _collapseAllBtnOpacity === 1 ? true : false;
    };

    this.updateToolbarColor = function ( evt ) {
        var target = evt.target || evt.srcElement, linearGrad, buttonRect;
        if ( _expandAllBtnOpacity === 1 && target.id.indexOf( 'ExpandAll' ) !== -1 ) {
            linearGrad = _treeControl.getElementById( 'ButtonBgGradient_LigtherDarker_ExpandAll' );
            buttonRect = _treeControl.getElementById( 'ExpandAll_Rect' );
        } else if ( _collapseAllBtnOpacity === 1 && target.id.indexOf( 'CollapseAll' ) !== -1 ) {
            linearGrad = _treeControl.getElementById( 'ButtonBgGradient_LigtherDarker_CollapseAll' );
            buttonRect = _treeControl.getElementById( 'CollapseAll_Rect' );
        } else {
            if ( _collapseAllBtnOpacity === 1 && target.id.indexOf( 'FilterButton' ) !== -1 ) {
                linearGrad = _treeControl.getElementById( 'ButtonBgGradient_LigtherDarker_Filter' );
                buttonRect = _treeControl.getElementById( 'FilterButton_Rect' );
            }
        }
        if ( linearGrad && buttonRect && _isExtendedStyle ) {
            switch ( evt.type ) {
                case 'mouseover':
                    linearGrad.childNodes[1].setAttribute( 'stop-color', _constants.stopColor3 );
                    buttonRect.setAttribute( 'stroke', _constants.btnBorderColor2 );
                    break;
                case 'mouseleave':
                    linearGrad.childNodes[1].setAttribute( 'stop-color', _constants.stopColor2 );
                    buttonRect.setAttribute( 'stroke', _constants.btnBorderColor1 );
                    break;
                case 'mousedown':
                case 'touchstart':
                    linearGrad.childNodes[0].setAttribute( 'stop-color', _constants.stopColor3 );
                    linearGrad.childNodes[1].setAttribute( 'stop-color', _constants.stopColor1 );
                    if ( target.id.indexOf( 'FilterButton' ) !== -1 ) {
                        if ( _filterBtnState === 0 ) {
                            buttonRect.setAttributeNS( null, 'fill', _pressedbuttonStyles['fill'] );
                            _filterBtnState = 1;
                        }
                        else {
                            buttonRect.setAttributeNS( null, 'fill', _styleFactory.ToolBar.Fill );
                            _filterBtnState = 0;
                        }
                    }
                    buttonRect.setAttribute( 'stroke', _constants.btnBorderColor2 );
                    break;
                case 'mouseup':
                case 'touchend':
                    linearGrad.childNodes[0].setAttribute( 'stop-color', _constants.stopColor1 );
                    linearGrad.childNodes[1].setAttribute( 'stop-color', _constants.stopColor3 );
                    break;
                default:
                    break;
            }
        }
        else {
            if ( buttonRect ) {
                switch ( evt.type ) {
                    case 'mouseover':
                        buttonRect.setAttribute( 'fill', _styleFactory.ToolBar.Hover );
                        break;
                    case 'mouseleave':
                        buttonRect.setAttribute( 'fill', _styleFactory.ToolBar.Fill );
                        break;
                    case 'mousedown':
                    case 'touchstart':
                        buttonRect.setAttribute( 'fill', _styleFactory.ToolBar.Pressed );
                        break;
                    default:
                        break;
                }
            }
        }
    };
    this.setExpandBtnLine = function ( expandAll ) {
        var lineStyle;
        lineStyle = _treeControl.getElementById( 'ExpandAll_Line' );
        if ( !lineStyle ) {
            _createExpandBorder();
            lineStyle = _treeControl.getElementById( 'ExpandAll_Line' );
        }
        if ( expandAll ) {
            lineStyle.setAttribute( 'y1', topVal - 1 );
            lineStyle.setAttribute( 'y2', topVal - 1 );
        }
        else {
            lineStyle.setAttribute( 'y1', topVal + height - 1 );
            lineStyle.setAttribute( 'y2', topVal + height - 1 );
        }
    };
    this.setCollapseBtnLine = function ( collapseAll ) {
        var lineStyle;
        lineStyle = _treeControl.getElementById( 'CollapseAll_Line' );
        if ( !lineStyle ) {
            _createCollapseBorder();
            lineStyle = _treeControl.getElementById( 'CollapseAll_Line' );
        }
        if ( collapseAll ) {
            lineStyle.setAttribute( 'y1', topVal - 1 );
            lineStyle.setAttribute( 'y2', topVal - 1 );
        }
        else {
            lineStyle.setAttribute( 'y1', topVal + height - 1 );
            lineStyle.setAttribute( 'y2', topVal + height - 1 );
        }
    };
    this.setFilterBtnLine = function ( isPressed ) {
        var lineStyle;
        lineStyle = _treeControl.getElementById( 'Filter_Line' );
        if ( !lineStyle ) {
            _createFilterBorder();
            lineStyle = _treeControl.getElementById( 'Filter_Line' );
        }
        if ( isPressed ) {
            lineStyle.setAttribute( 'y1', topVal - 1 );
            lineStyle.setAttribute( 'y2', topVal - 1 );
        }
        else {
            lineStyle.setAttribute( 'y1', topVal + height - 1 );
            lineStyle.setAttribute( 'y2', topVal + height - 1 );
        }
    };
    this.removeExpandBtnLine = function () {
        var expandAllLine;
        expandAllLine = _treeControl.getElementById( 'ExpandAll_Line' );
        _expandAllGroup.removeChild( expandAllLine );
    };
    this.removeCollapseBtnLine = function () {
        var collapseAllLine;
        collapseAllLine = _treeControl.getElementById( 'CollapseAll_Line' );
        _collapseAllGroup.removeChild( collapseAllLine );
    };
    this.updateToolBarStyles = function ( currentStyle, bottomLine, pressedbuttonStyles ) {
        var expandBorder, collapseBroder, filterBorder,
            collapseButtonRect, expandButtonRect, filterButtonRect,
             toolbarBackRect2,
            currentStyleProps;

        currentStyleProps = _styleFactory;
        _styleFactory = CPM.StyleFactory.getCurrentStyleProps( currentStyle );
        _isExtendedStyle = currentStyle.includes( CPM.Enums.StyleName.Extended ) ? true : false;
        _pressedbuttonStyles = pressedbuttonStyles;
        expandBorder = _treeControl.getElementById( 'ExpandAll_Line' );
        collapseBroder = _treeControl.getElementById( 'CollapseAll_Line' );
        filterBorder = _treeControl.getElementById( 'Filter_Line' );
        collapseButtonRect = _treeControl.getElementById( 'CollapseAll_Rect' );
        expandButtonRect = _treeControl.getElementById( 'ExpandAll_Rect' );
        filterButtonRect = _treeControl.getElementById( 'FilterButton_Rect' );
        toolbarBackRect2 = _treeControl.getElementById( 'toolbarBackgroundRect2' );
        if ( _isExtendedStyle ) {
            if ( expandBorder && expandBorder.parentNode ) {
                expandBorder.parentNode.removeChild( expandBorder );
                expandBorder = null;
            }
            if ( collapseBroder && collapseBroder.parentNode ) {
                collapseBroder.parentNode.removeChild( collapseBroder );
                collapseBroder = null;
            }
            if ( filterBorder && filterBorder.parentNode ) {
                filterBorder.parentNode.removeChild( filterBorder );
                filterBorder = null;
            }
            _createGradientElement( _expandAllGroup, _toolbarBtns.ExpandAll );
            _createGradientElement( _collapseAllGroup, _toolbarBtns.CollapseAll );
            _setAttributes( collapseButtonRect, 'fill', _styleFactory.ToolBar.Fill );
            _setAttributes( expandButtonRect, 'fill', _styleFactory.ToolBar.Fill );
            _setAttributes( filterButtonRect, 'fill', _isExtendedStyle && ( _filterBtnState === 1 ) ? _pressedbuttonStyles['fill'] : _styleFactory.ToolBar.Fill );
            _setAttributes( _toolbarBottomLine, 'stroke', _styleFactory.ToolBar.BottomLineColor );
        } else {
            _setButtonStateColor( expandButtonRect, currentStyleProps.ToolBar );
            if ( expandBorder ) {
                expandBorder.setAttribute( 'stroke', _styleFactory.ToolBar.BottomBorder );
            } else {
                _createExpandBorder();
                if ( _expandAllBtnOpacity === 0.5 ) {
                    this.setExpandBtnLine( true );
                }
            }
            _setButtonStateColor( collapseButtonRect, currentStyleProps.ToolBar );
            if ( collapseBroder ) {
                collapseBroder.setAttribute( 'stroke', _styleFactory.ToolBar.BottomBorder );
            } else {
                _createCollapseBorder();
                if ( _collapseAllBtnOpacity === 0.5 ) {
                    this.setCollapseBtnLine( true );
                }
            }
            _setButtonStateColor( filterButtonRect, currentStyleProps.ToolBar );
            if ( filterBorder ) {
                filterBorder.setAttribute( 'stroke', _styleFactory.ToolBar.BottomBorder );
            }
            else {
                _createFilterBorder();
                this.setFilterBtnLine( _filterBtnState );
            }
            _setAttributes( toolbarBackRect2, 'width', toolbarBackRect2.width.baseVal.value + 1 );
            if ( bottomLine ) {
                _setAttributes( _toolbarBottomLine, 'stroke', _styleFactory.Control.HorizLineColor );
            } else {
                _setAttributes( _toolbarBottomLine, 'stroke', _styleFactory.ToolBar.BottomLineColor );
            }
        }
        _setAttributes( expandButtonRect, 'rx', _styleFactory.ToolBar.Rx );
        _setAttributes( collapseButtonRect, 'rx', _styleFactory.ToolBar.Rx );
        _setAttributes( filterButtonRect, 'rx', _styleFactory.ToolBar.Rx );

        _setAttributes( toolbarBackRect2, 'fill', _styleFactory.Control.EvenBackColor );
        _setAttributes( collapseButtonRect, 'stroke', _styleFactory.ToolBar.BorderColor1 );
        _setAttributes( expandButtonRect, 'stroke', _styleFactory.ToolBar.BorderColor1 );
        _setAttributes( filterButtonRect, 'stroke', _styleFactory.ToolBar.BorderColor1 );
        _updateIconColor();
    };

    this.showBottomLine = function () {
        _setAttributes( _toolbarBottomLine, 'stroke', _styleFactory.Control.HorizLineColor );
    };
};
var CPM = ( CPM || {} );
CPM.searchBox = function () {
    var _backRect, _rectSvg, _line, _textBox, _searchIconSvg, _searchIconRect, _searchIconPath, _closeIconSvg, _closeIconRect, _closeIconPath,

    _setWidth = function ( width, isComboBoxBelow ) {
        var ctrlWidth = width;
        width = ( width / 2 ) - CPM.Enums.Constants.searchBoxLeftPadding;
        if ( isComboBoxBelow ) {
            width = ctrlWidth - 2 * CPM.Enums.Constants.searchComboBoxPadding;
        }
        return width;
    },
    _setAttribute = function ( element, prop, value ) {
        if ( element ) {
            element.setAttribute( prop, value );
        }
    },
    _setIconPath = function ( isExtendedStyle ) {
        var d;
        if ( isExtendedStyle ) {
            d = 'M 21.375 18.882812 L 17.039062 14.542969 C 17.648438 13.503906 18 12.292969 18 11 C 18 7.132812 14.867188 4 11 4 C 7.132812 4 4 7.132812 4 11 C 4 14.867188 7.132812 18 11 18 C 12.355469 18 13.621094 17.613281 14.691406 16.949219 L 19 21.257812 C 19.78125 22.035156 20.953125 22.136719 21.601562 21.484375 C 22.253906 20.828125 22.15625 19.65625 21.375 18.882812 Z M 6 11 C 6 8.238281 8.238281 6 11 6 C 13.761719 6 16 8.238281 16 11 C 16 13.761719 13.761719 16 11 16 C 8.238281 16 6 13.761719 6 11 Z M 6 11 ';
        } else {
            d = 'M11,1 C15.418278,1 19,4.581722 19,9 C19,10.8486595 18.3729536,12.5508646 17.3199461,13.9055298 L21.9142136,18.5 L20.5,19.9142136 L15.9055298,15.3199461 C14.5508646,16.3729536 12.8486595,17 11,17 C6.581722,17 3,13.418278 3,9 C3,4.581722 6.581722,1 11,1 Z M11,2 C7.13400675,2 4,5.13400675 4,9 C4,12.8659932 7.13400675,16 11,16 C14.8659932,16 18,12.8659932 18,9 C18,5.13400675 14.8659932,2 11,2 Z';
        }
        return d;
    };
    this.create = function ( divParent, attrs ) {
        var width, isExtendedStyle, stylePropObj, self = this;
        isExtendedStyle = attrs.currentStyle.includes( CPM.Enums.StyleName.Extended );
        stylePropObj = CPM.StyleFactory.getCurrentStyleProps( attrs.currentStyle );
        width = _setWidth( attrs.width, attrs.isComboBoxBelow );

        // Creating svg & rect to hold the search icon and clear icon to avoid overlapping of input box text value with icons
        _rectSvg = CPM.svgUtil.createSVG( 'svg', {
            x: 0,
            y: 0,
            height: '39',
            width: width,
            style: 'position:absolute; top:0px; left:10px;',
            appendTo: divParent
        } );
        _backRect = CPM.svgUtil.createSVG( 'rect', {
            x: '1',
            y: '1',
            height: '36',
            width: width - 2,
            fill: stylePropObj.TextBox.BackColor,
            stroke: stylePropObj.ComboBox.Stroke,
            'stroke-width': '0.5',
            rx: stylePropObj.ComboBox.Rx,
            style: 'position:absolute; top:0px;',
            appendTo: _rectSvg
        } );
        _line = CPM.svgUtil.createSVG( 'line', {
            x1: '1',
            y1: '37',
            x2: width - 1,
            y2: '37',
            stroke: stylePropObj.TextBox.BottomLineColor,
            'stroke-width': stylePropObj.TextBox.LineStroke,
            appendTo: _rectSvg
        } );
        _textBox = CPM.svgUtil.createDomElement( 'input', {
            id: 'searchBox',
            type: 'text',
            value: '',
            autocomplete: 'off',
            style: 'position:absolute; left:38px; top:10px; height:30px; width:60px;  border:none; outline:none; color:black;',
            appendTo: divParent
        } );
        _textBox.style.width = width - ( 5 * CPM.Enums.Constants.searchComboBoxPadding ) + 'px';
        _textBox.style.backgroundColor = stylePropObj.TextBox.BackColor;
        _textBox.style.color = attrs.currentStyle === CPM.Enums.StyleName.DarkStyle ? 'white' : 'black';

        _searchIconSvg = CPM.svgUtil.createSVG( 'svg', {
            id: 'svg_searchIcon',
            x: 0,
            y: 0,
            height: '35',
            width: stylePropObj.TextBox.SvgWidth,
            style: 'position:absolute; left:12px; top:0px;',
            viewBox: stylePropObj.TextBox.ViewBox,
            appendTo: divParent
        } );

        _searchIconRect = CPM.svgUtil.createSVG( 'rect', {
            id: 'rect_searchIcon',
            x: '0',
            y: stylePropObj.TextBox.IconY,
            height: '37',
            width: stylePropObj.TextBox.SvgWidth,
            fill: stylePropObj.TextBox.BackColor,
            style: 'position:absolute; left:12px; top:0px;',
            appendTo: _searchIconSvg
        } );
        _searchIconPath = CPM.svgUtil.createSVG( 'path', {
            id: 'path_searchIcon',
            d: _setIconPath( isExtendedStyle ),
            fill: stylePropObj.TextBox.IconColor,
            appendTo: _searchIconSvg
        } );
        _closeIconSvg = CPM.svgUtil.createSVG( 'svg', {
            display: 'none',
            id: 'svg_closeIcon',
            x: 0,
            y: 0,
            height: '34',
            width: '26',
            style: 'position:absolute; left:12px; top:0px;',
            viewBox: stylePropObj.TextBox.ViewBox,
            appendTo: divParent
        } );
        _closeIconSvg.style.left = width - CPM.Enums.Constants.searchBoxLeftPadding - 3 + 'px';
        _closeIconRect = CPM.svgUtil.createSVG( 'rect', {
            id: 'rect_closeIcon',
            x: '0',
            y: '-2',
            height: '34',
            width: stylePropObj.TextBox.SvgWidth,
            fill: stylePropObj.TextBox.BackColor,
            style: 'position:absolute; left:12px; top:0px;',
            appendTo: _closeIconSvg
        } );
        _closeIconRect.style.left = width - CPM.Enums.Constants.searchBoxLeftPadding - 3 + 'px';
        _closeIconPath = CPM.svgUtil.createSVG( 'path', {
            id: 'path_closeIcon',
            'stroke-width': stylePropObj.TextBox.StrokeWidth,
            stroke: stylePropObj.TextBox.IconColor,
            d: 'M 13 15 L 7 9 L 19 21 M 13 15 L 7 21 L 19 9',
            fill: stylePropObj.TextBox.IconColor,
            appendTo: _closeIconSvg
        } );
        //Setting top value of elements based on toolbarand url height
         self.updateTopValue( attrs.toolbarHeight + attrs.urlHeight );
        _textBox.addEventListener( 'mouseout', self.hideToolTip );
    };

    this.showInputTextToolTip = function ( position ) {
        var toolTipText, width, ratio, threshold = 6;
        toolTipText = _textBox.value;
        if ( toolTipText !== '' ) {
            width = parseInt( _textBox.style.width, 10 );
            ratio = width / toolTipText.length;
            if ( ratio <= threshold ) {
                CPM.Common.Tooltip.show( position.x, position.y, toolTipText );
            }
        }
    };

    this.hideToolTip = function () {
        CPM.Common.Tooltip.hide();
    };

    this.show = function () {
        if ( _textBox ) {
            _textBox.style.display = 'initial';
            _textBox.disabled = false;
        }
        if ( _rectSvg ) {
            _rectSvg.style.position = 'absolute';
        }
        if ( _searchIconSvg ) {
            _searchIconSvg.style.position = 'absolute';
        }
        if ( _textBox.value !== '' ) {
            _closeIconSvg.style.position = 'absolute';
        } else {
            _closeIconSvg.style.position = 'relative';
        }
    };

    this.hide = function () {
        if ( _textBox ) {
            _textBox.style.display = 'none';
            _textBox.disabled = true;
        }
        // _rectSvg, _searchIconSvg, _closeIconSvg will be stacked on top inside divParent, the display: none will hide the element but will be present in the DOM 
        // and interfere with click of nodes. So changing the position instead of display
        if ( _rectSvg ) {
            _rectSvg.style.position = 'relative';
        }
        if ( _searchIconSvg ) {
            _searchIconSvg.style.position = 'relative';
        }
        if ( _closeIconSvg ) {
            _closeIconSvg.style.position = 'relative';
        }
    };

    this.updateTopValue = function ( top ) {
        var topVal = top + CPM.Enums.Constants.searchBoxTopPadding;
        if ( _textBox ) {
            _textBox.style.top = topVal + 2 + 'px';
        }
        if ( _rectSvg ) {
            _rectSvg.style.top = topVal - 1 + 'px';
        }
        if ( _backRect ) {
            _backRect.style.top = topVal + 'px';
        }
        if ( _line ) {
            _line.style.top = topVal + 7 + 'px';
        }
        if ( _searchIconSvg ) {
            _searchIconSvg.style.top = topVal + 'px';
        }
        if ( _closeIconSvg ) {
            _closeIconSvg.style.top = topVal - 1 + 'px';
        }
    };
    this.showClearIcon = function () {
        _setAttribute( _closeIconSvg, 'display', 'initial' );
        _closeIconSvg.style.position = 'absolute';
    };
    this.hideClearIcon = function () {
        _setAttribute( _closeIconSvg, 'display', 'none' );
        _closeIconSvg.style.position = 'relative';
    };

    this.clearSearch = function () {
        var self = this;
        _textBox.value = '';
        self.hideClearIcon();
        return _textBox.value;
    };

    this.searchText = function () {
        return _textBox.value;
    };

    this.updateWidth = function ( width, isComboBoxBelow ) {
        width = _setWidth( width, isComboBoxBelow );
        _setAttribute( _rectSvg, 'width', width );
        _setAttribute( _backRect, 'width', width - 2 );
        _setAttribute( _line, 'x2', width - 1 );
        _textBox.style.width = width - ( 5 * CPM.Enums.Constants.searchComboBoxPadding ) + 'px';
        _closeIconSvg.style.left = width - CPM.Enums.Constants.searchBoxLeftPadding - 3 + 'px';
    };

    this.updateStyle = function ( stylePropObj, isExtendedStyle, currentStyle ) {
        _textBox.style.backgroundColor = stylePropObj.TextBox.BackColor;
        _textBox.style.color = currentStyle === CPM.Enums.StyleName.DarkStyle ? 'white' : 'black';

        _setAttribute( _backRect, 'fill', stylePropObj.TextBox.BackColor );
        _setAttribute( _backRect, 'stroke', stylePropObj.TextBox.BorderColor );
        _setAttribute( _backRect, 'rx', stylePropObj.TextBox.Rx );

        _setAttribute( _line, 'stroke', stylePropObj.TextBox.BottomLineColor );
        _setAttribute( _line, 'stroke-width', stylePropObj.TextBox.LineStroke );

        _setAttribute( _searchIconSvg, 'width', stylePropObj.TextBox.SvgWidth );
        _setAttribute( _searchIconSvg, 'viewBox', stylePropObj.TextBox.ViewBox );

        _setAttribute( _searchIconRect, 'y', stylePropObj.TextBox.IconY );
        _setAttribute( _searchIconRect, 'fill', stylePropObj.TextBox.BackColor );

        _setAttribute( _searchIconPath, 'd', _setIconPath( isExtendedStyle ) );
        _setAttribute( _searchIconPath, 'fill', stylePropObj.TextBox.IconColor );

        _setAttribute( _closeIconRect, 'fill', stylePropObj.TextBox.BackColor );

        _setAttribute( _closeIconPath, 'stroke-width', stylePropObj.TextBox.StrokeWidth );
        _setAttribute( _closeIconPath, 'stroke', stylePropObj.TextBox.IconColor );
    };
};
var CPM = ( CPM || {} );
CPM.App = function () {
    var
        // holds refernce of callback function to be called on event occurs on DOM
        _callback,
        _searchText = '',
        // holds information of general operations
        _operation = {
            add: 'add',
            remove: 'remove'
        },
        // holds left value
        _left = 5,
        // holds top value
        _top = 5,
        _id = 'CPM_Tree_Combo',
        _deepestNode = 0,
        _deepestNodeWidth = 0,
        _prevNodeSelected,
        _ctrlHeight = 0,
        _nodeHeight = 33.5, // Hardcoded value as there is no configuration available for the font for control in ES
        _divParent = null,
        _isExpandAll = false,
        _isRootNodePropertyChanged = false,
        _isNodeUpdated = false,
        _isFullDataPresent = false,
        _isCollapseAll = false,
        _scrollVerticalHandler = new CPM.Control.ScrollHandler(),
        _scrollBCVerticalHandler = new CPM.Control.ScrollHandler(),
        _scrollHorizontalHandler = new CPM.Control.ScrollHandler(),
        _urlPartTotalHeight,
        _searchComboBoxPartHeight,
        _nodeDomHeight,
        _toolbarHeight,
        _isScrollbarCreated = false,
        _isBCVerticalScrollbarCreated = false,
        _isHorizontalScrollbarCreated = false,
        _isExtendedStyle = false,
        _isAlarmsPresent = false,
        _horizontalLine = false,
        _treeAlarmIconGroup = null,
        _treeGroup = null,
        _treeGroupMatrix,
        _iconTextGroup = null,
        _breadcrumbGroup = null,
        _breadcrumbGroupMatrix,
        _deepestIdx = 1,
        _isBreadCrumbCreated = false,
        _prevHoveredNodeId = null,
        _prevSelectedBCNodeId = null,
        _prevSelectedCrumbNode,
        _nodeHandler,
        _treeControlGroup = null,
        _urlGroup = null,
        _urlGroupMatrix,
        _toolbarGroup = null,
        _searchComboBoxGroup = null,
        _showToolBar = true,
        _showBreadCrumb = true,
        _showSearchComboBox = true,
        _isFilterRectsCreated = false,
        _breadCrumb,
        _toolbar,
        _vpNodeCount,
        _scrollCount = 0,
        _linearDataArray = [],
        _bufferDataArray = [],
        _isBCUpdateRequired = false,
        _iconTextGroupMatrix,
        _vScrollStep = 0,
        _prevScrollPerc = 0,
        _vBCScrollStep = 0,
        _vBCScrollHeight = 0,
        _prevBCScrollPerc = 0,
        _hScrollStep = 0,
        _hScrollWidth = 0,
        //maintain count information. it is used to calculate index of tree nodes
        _count = 0,
        _crumbChildren = [],
        _crumbX,
        _crumbNodeNameWidth,
        _showCrumb = false,
        _crumbHeight,
        _clickedURLNodeId,
        _crumbNodeNameHeight,
        _comboBoxHandler,
        _filterComboBox,
        _searchBox,
        _isSearchPending = false,
        _scrollbarGrp,
        _bcParentGrp = null,
        _options = {},
        _isBCSelectionRequest = false,
        self = this,
        // holds font information
        TEXT_BBOX = 0,
        _font = {
            parttype: 'FontPart',
            Size: 14,
            family: 'Siemens Sans',
            color: 'black'
        },
        _data = {
            Left: _left,
            Top: _top,
            Width: 150,
            Height: 900,
            Font: _font,
            NodePart: [],
            currentStyle: WebCC.Extensions.HMI.Style.Name,
            URLPart: { border: { height: 40, width: 0, strokeWidth: 1, paddingRight: 10 }, font: { size: 14 }, imageIconRect: { width: 20, height: 24 }, imageIconSvg: { width: 5 }, textPadding: { left: 10, right: 10 }, data: [], viewportData: [] },
            ToolbarPart: {
                border: {
                    height: 55, width: 50, topVal: 0, strokeWidth: 1, paddingRight: 10, iconSpacing: 7,
                    buttonHeight: 36,
                    buttonTop: 10
                }, font: { size: 15 }, imageIcon: { width: 24, height: 20 }, textPadding: { left: 5, right: 5 }, data: [], viewportData: []
            },
            SearchComboBoxPart: {
                border: {
                    height: 60, width: 0, strokeWidth: 1, paddingRight: 10, iconSpacing: 7,
                    buttonHeight: 36,
                    buttonTop: 10
                }, font: { size: 15 }, data: [], viewportData: []
            }
        },
        _cntrlHeightNew = 0,
        _cntrlWidthNew = 0,
        // holds refernce of svgParent
        _svgParent,
        // holds selectedNode Id
        _selectedNodeId,
        _expandedNodeId,
        _navigatedNodeId,
        _navigationType,
        _horizontalInitialScrollOffset = 0,
        _hScrollbarHeight,
        _alarmComapnion = [],
        _screenWindowCompanion = [],
        _shcCompanion = [],
        _selectedNodePath,
        _rootNode,
        _eventManager,
        _tbUpdateRequired = false,
        _enableExpandBtn = false,
        _alarmData = {},
        _screenData = {},
        _selectedFilter,
        _createFilter = false,
        _moveBelow = false,
        _addExtraScroll,
        _defaultSelectionBackColor = 4286434805,
        _defaultSelectionForeColor = 0,
        _selectionBackColUpdated = false,
        _selectionForeColUpdated = false,
        _bcOverlaySVG = null,
        //returns default node properties
        _getDefaultNode = function () {
            return {
                Name: null,
                Id: null,
                ObjectType: null,
                IsExpanded: true,
                IsLeaf: false,
                Visible: true,
                Children: [],
                Parent: WebCC.Properties.SelectedNode,
                ParentId: _selectedNodeId
            };
        },

        //calculates bbox information of text
        _fillBBoxInfo = function ( data ) {
            if ( data ) {
                var text = ( data.name || 'XY' ),
                    bbox = CPM.svgUtil.getTextBBox( { Size: _data.URLPart.font.size, Weight: 'bold', Name: _font.family }, '' + text );
                data.height = Math.ceil( bbox.height );
                data.width = Math.ceil( bbox.width );
            }
        },

        //returns node data based on nodeId
        _getNodeData = function ( nodeId ) {
            var nodeData,
                nodePart = _data.NodePart[0];
            if ( nodeId ) {
                if ( nodeId === nodePart.Id ) {
                    nodeData = nodePart;
                }
                else {
                    nodeData = _searchForNode( nodePart, nodeId, _operation.add );
                }
            }
            return nodeData;
        },

        //returns node data based on fullPath
        _getNodeDataByPath = function ( fullPath ) {
            var nodeData,
                nodePart = _data.NodePart[0];
            if ( nodePart ) {
                if ( fullPath === nodePart.fullPath ) {
                    nodeData = nodePart;
                } else {
                    nodeData = _searchForNode( nodePart, fullPath, _operation.add, true );
                }
            }
            return nodeData;
        },

        _handleSearchText = function ( textStr ) {
            var currentSearchText;
            if ( _isSearchPending ) {
                _count = 0;
            }
            else {
                if ( textStr || textStr === '' ) {
                    currentSearchText = textStr.toLowerCase();
                    if ( _searchText.toLowerCase() !== currentSearchText ) {
                        _searchText = currentSearchText;
                    }
                }
            }

            if ( !_isFullDataPresent ) {
                if ( _data.NodePart[0] ) {
                    WebCC.Extensions.HMI.DomainLogic.sendDLEvent( [0, 1], [CPM.Enums.BrowsingMode.ExpandAll, _data.NodePart[0].Id] );
                    _isSearchPending = true;
                    _nodeHandler.updateBgRects( [], !_scrollCount, _data, _isAlarmsPresent );
                }
            }
            else {
                _markNodesHavingSearchText();

                if ( !_isSearchPending ) {
                    _nodeHandler.updateBgRects( [], !_scrollCount, _data, _isAlarmsPresent );
                }
                else {
                    _isSearchPending = false;
                }

                if ( _isAlarmsPresent ) {
                    _removeAlarmBgRects();
                    _createAlarmBgRects();
                }
                _setBeforeTraverse();
                _setForUpdate();
                if ( _selectedNodeId ) {
                    _updateURLData( _getNodeData( _selectedNodeId ) );
                }
            }
        },

        _mergeNodeProps = function ( dest, src ) {
            var i, j,
                srcChildren,
                destChildren,
                srcChildrenLen,
                destChildrenLen,
                matchedNode;

            if ( dest.Id === src.Id ) {
                dest.isNodeNavigated = src.isNodeNavigated;

                //process if any source children exists
                srcChildren = src.Children;

                if ( srcChildren ) {
                    srcChildrenLen = src.Children.length;

                    for ( j = 0; j < srcChildrenLen; j++ ) {
                        _mergeNodeProps( dest, srcChildren[j] );
                    }
                }
            }
            else {
                destChildren = dest.Children;

                if ( destChildren ) {
                    destChildrenLen = destChildren.length;

                    //process if any destination children exists
                    for ( i = 0; i < destChildrenLen; i++ ) {

                        if ( destChildren[i].Id === src.Id ) {
                            matchedNode = destChildren[i];
                            matchedNode.isNodeNavigated = src.isNodeNavigated;

                            _mergeNodeProps( matchedNode, src );
                            break;
                        }
                    }
                }
            }
        },

        _markNodesHavingSearchText = function () {
            _searchNodes( _data.NodePart[0] );
            _data.NodePart[0].hasSearchText = _data.NodePart[0].Name.toLowerCase().includes( _searchText );
        },

        _searchNodes = function ( node ) {
            var child,
                length,
                children;

            node.hasChildWithSearchText = false;

            if ( node ) {
                children = node.Children || [];
                length = children.length;

                while ( length-- ) {
                    node.IsExpanded = true;
                    child = children[length];
                    child.hasSearchText = child.Name.toLowerCase().includes( _searchText );
                    if ( child.hasSearchText ) {
                        node.hasChildWithSearchText = true;
                    }
                    if ( child.isSelected && child.fullPath !== _selectedNodePath ) {
                        child.isSelected = false;
                    }
                    if ( !child.IsLeaf ) {
                        _searchNodes( child );
                    }
                }

                if ( node.hasChildWithSearchText && node.Parent ) {
                    node.Parent.hasChildWithSearchText = true;
                }
                if ( node.isSelected && node.fullPath !== _selectedNodePath ) {
                    node.isSelected = false;
                }
            }
        },

        //Expands all the childrens of the selected node
        _expandAllChildren = function ( selectedNode ) {
            var i = 0,
                children = selectedNode.Children,
                child,
                childCount;
            if ( _isExpandAll ) {
                selectedNode.IsExpanded = true;
            }
            if ( children ) {
                childCount = children.length;
                for ( i = 0; i < childCount; i++ ) {
                    child = children[i];
                    child.Visible = true;
                    _expandAllChildren( child );
                }
            }
        },

        //update or set depth and index information
        _traverse = function ( node, isVisible ) {
            var i = 0, childName,
                children = node.Children,
                child,
                childCount,
                prevIndexAtDepth = 0;
            prevIndexAtDepth = node.index = _count++;
            if ( _isExpandAll ) {
                node.IsExpanded = true;
            } else {
                if ( _isCollapseAll ) {
                    node.IsExpanded = false;
                }
            }

            if ( _rootNode !== '' && _selectedFilter && ( ( _selectedFilter === _options['TBID_NODE_PENDINGALARMS'] && Object.keys( _alarmData ).length > 0 && Object.keys( _alarmData.ActiveAlarms ).length > 0 && _alarmData.ActiveAlarms[_rootNode] === undefined ) || ( _selectedFilter === _options['TBID_NODE_VISUALIZATION'] && Object.keys( _screenData ).length > 0 && Object.keys( _screenData.ScreenFilter ).length > 0 && _screenData.ScreenFilter[_rootNode] === undefined ) ) ) {
                return;
            } else {
                if ( isVisible || _applyVisibilityOnSearchAndFilter( node ) ) {
                    _linearDataArray.push( node );
                }
            }
            if ( children ) {
                childCount = children.length;
                for ( i = 0; i < childCount; i++ ) {
                    child = children[i];
                    child.ParentId = node.Id;
                    child.prevIndexAtDepth = prevIndexAtDepth;
                    if ( node.IsExpanded === true ) {
                        _applyVisibilityOnSearchAndFilter( child );
                        if ( node.depth === undefined || node.depth === null ) {
                            node.depth = 0;
                        }
                        child.depth = node.depth + 1;
                        if ( child.depth >= _deepestNode ) {
                            _deepestNode = child.depth;
                            childName = child.Name;
                        }
                    } else {
                        child.Visible = false;
                    }

                    if ( child.Visible === true ) {
                        _traverse( child, true );
                        prevIndexAtDepth = child.index;
                    }
                }
            }
            //node.isSelected = false;
        },

        _applyVisibilityOnSearchAndFilter = function ( node ) {
            var isVisible = false;

            if ( _selectedFilter && _selectedFilter !== _options['TBID_NONE'] ) {
                if ( _selectedFilter === _options['TBID_NODE_PENDINGALARMS'] && Object.keys( _alarmData ).length > 0 && Object.keys( _alarmData.ActiveAlarms ).length > 0 ) {
                    isVisible = Object.keys( _alarmData.ActiveAlarms ).indexOf( node.fullPath ) !== -1;
                }
                else {
                    if ( _selectedFilter === _options['TBID_NODE_VISUALIZATION'] && Object.keys( _screenData ).length > 0 && Object.keys( _screenData.ScreenFilter ).length > 0 ) {
                        isVisible = Object.keys( _screenData.ScreenFilter ).indexOf( node.fullPath ) !== -1;
                    }
                }
            }
            else {
                isVisible = true;
            }

            if ( isVisible && _searchText ) {
                if ( _selectedFilter && _selectedFilter !== _options['TBID_NONE'] ) {
                    isVisible = node.canRetain;
                    if ( _selectedFilter === _options['TBID_NODE_PENDINGALARMS'] && Object.keys( _alarmData ).length > 0 && Object.keys( _alarmData.ActiveAlarms ).length > 0 ) {
                        node.hasSearchText = _alarmData.ActiveAlarms[node.fullPath] === 1 && node.hasSearchText;
                    } else {
                        if ( _selectedFilter === _options['TBID_NODE_VISUALIZATION'] && Object.keys( _screenData ).length > 0 && Object.keys( _screenData.ScreenFilter ).length > 0 ) {
                          node.hasSearchText = _screenData.ScreenFilter[node.fullPath] === 1 && node.hasSearchText;
                        }
                    }
                }
                else {
                    isVisible = node.hasSearchText || node.hasChildWithSearchText;
                }
            }

            node.Visible = isVisible;

            return isVisible;
        },

        //updates URL data
        _updateURLData = function ( node ) {
            var URLPart = _data.URLPart,
                nodePart = _data.NodePart[0], prevNode,
                nodeData;
            URLPart.data.length = 0;
            if ( !node ) {
                return;
            }
            //selected node is hierarchy node
            if ( node.Id === nodePart.Id ) {
                nodeData = { name: nodePart.Name, id: nodePart.Id, height: null, width: null, IsLeaf: nodePart.IsLeaf };
                URLPart.data.push( nodeData );
                _fillBBoxInfo( nodeData );
            }
            else {//selected node is view root or view node
                nodeData = { name: node.Name, id: node.Id, height: null, width: null, IsLeaf: node.IsLeaf };
                URLPart.data.push( nodeData );
                _fillBBoxInfo( nodeData );

                prevNode = node;
                while ( prevNode.Id !== nodePart.Id ) {
                    if ( prevNode.ParentId === nodePart.Id ) {
                        nodeData = { name: nodePart.Name, id: nodePart.Id, height: null, width: null, IsLeaf: nodePart.IsLeaf };
                        URLPart.data.push( nodeData );
                        _fillBBoxInfo( nodeData );
                        break;
                    }
                    prevNode = _searchForNode( nodePart, prevNode.ParentId, _operation.add );
                    nodeData = { name: prevNode.Name, id: prevNode.Id, height: null, width: null, IsLeaf: prevNode.IsLeaf };
                    URLPart.data.push( nodeData );
                    _fillBBoxInfo( nodeData );
                }
            }
            _calculateViewPortURLData();
        },

        //calculate viewport URL data from entire URL data
        _calculateViewPortURLData = function () {
            var i = 0,
                URLPart = _data.URLPart,
                dataLength = URLPart.data.length,
                viewportDataLength,
                offset = URLPart.textPadding.left + URLPart.imageIconSvg.width + URLPart.textPadding.right,
                availableWidth = ( URLPart.border.width - offset ) > 0 ? ( URLPart.border.width - offset ) : 0,
                coveredWidth = 0;
            URLPart.viewportData.length = 0;
            if ( _breadCrumb ) {
                if ( availableWidth > coveredWidth ) {
                    for ( i = 0; i < dataLength; i++ ) {
                        if ( ( coveredWidth + URLPart.data[i].width + offset ) < availableWidth ) {
                            URLPart.viewportData.push( URLPart.data[i] );
                            coveredWidth += URLPart.data[i].width + offset;
                        }
                        else {
                            break;
                        }
                    }
                    //calculate text x-position
                    viewportDataLength = URLPart.viewportData.length;
                    coveredWidth = offset;
                    for ( i = viewportDataLength - 1; i >= 0; i-- ) {
                        URLPart.viewportData[i].x = coveredWidth;
                        coveredWidth += URLPart.viewportData[i].width + offset;
                    }
                }
                _breadCrumb.updateNodeURL( URLPart );
            }
        },

        _searchForNode = function ( node, searchStr, operation, isFullPath ) {
            var
                children,
                child,
                length,
                retVal,
                isFound = false;
            if ( node && node.Children && node.Children.length > 0 ) {
                children = node.Children;
                length = children.length;
                while ( length-- ) {
                    child = children[length];
                    if ( searchStr && searchStr !== '' ) {
                        if ( isFullPath ) {
                            isFound = ( child.fullPath === searchStr ) ? true : false;
                        }
                        else {
                            isFound = ( child.Id.toLowerCase() === searchStr.toLowerCase() ) ? true : false;
                        }
                        if ( isFound ) {
                            switch ( operation ) {
                                case _operation.remove:
                                    children.splice( children.indexOf( child ), 1 );
                                    retVal = true;
                                    break;
                                case _operation.add:
                                    retVal = child;
                                    break;
                                default:
                                    break;
                            }
                        }
                        else {
                            if ( !child.IsLeaf && !retVal ) {
                                retVal = _searchForNode( child, searchStr, operation, isFullPath );
                            }
                        }
                    }
                }
            }
            return retVal;
        },


        _onScroll = function ( direction, scrollBar, evt ) {
            var yValue, xValue, pageScrollCount;
            switch ( scrollBar ) {
                case 'bcVScroll':
                    if ( _isBCVerticalScrollbarCreated ) {
                        if ( direction && ( _prevBCScrollPerc + _vBCScrollStep <= 1 ) ) {
                            _prevBCScrollPerc = _prevBCScrollPerc + _vBCScrollStep;
                        } else {
                            if ( !direction && ( _prevBCScrollPerc > 0 && ( _prevBCScrollPerc - _vBCScrollStep >= 0 ) ) ) {
                                _prevBCScrollPerc = _prevBCScrollPerc - _vBCScrollStep;
                            }
                        }
                        if ( _prevBCScrollPerc !== 0 ) {
                            yValue = -( _prevBCScrollPerc * _vBCScrollHeight );
                        }
                        else {
                            yValue = 0;
                        }
                        _breadcrumbGroupMatrix.f = yValue;
                        _createBCVerticalScrollBar();
                    }
                    break;
                case 'VScroll':
                    if ( _isScrollbarCreated ) {
                        if ( direction && ( _vScrollStep + _prevScrollPerc <= 1 ) ) {
                            _prevScrollPerc = _vScrollStep + _prevScrollPerc;
                            if ( evt && evt.keyCode === 34 ) {
                                pageScrollCount = _vpNodeCount + _scrollCount;
                                _prevScrollPerc = pageScrollCount / ( _count - _vpNodeCount );
                            }
                            _scrollCallBack( null, null, _prevScrollPerc );
                            _createVerticalScrollBar();
                        } else {
                            if ( !direction && ( _prevScrollPerc > 0 && ( ( _prevScrollPerc - _vScrollStep ) >= 0 ) ) ) {
                                _prevScrollPerc = _prevScrollPerc - _vScrollStep;
                                if ( evt && evt.keyCode === 33 ) {
                                    pageScrollCount = _scrollCount - _vpNodeCount;
                                    _prevScrollPerc = pageScrollCount / ( _count - _vpNodeCount );
                                }
                                _scrollCallBack( null, null, _prevScrollPerc );
                                _createVerticalScrollBar();
                            }
                        }
                    }
                    break;
                case 'HScroll':
                    if ( _isHorizontalScrollbarCreated ) {
                        if ( direction && ( _horizontalInitialScrollOffset + _hScrollStep <= 1 ) ) {
                            _horizontalInitialScrollOffset = _horizontalInitialScrollOffset + _hScrollStep;
                        } else {
                            if ( !direction && ( _horizontalInitialScrollOffset > 0 && ( _horizontalInitialScrollOffset - _hScrollStep >= 0 ) ) ) {
                                _horizontalInitialScrollOffset = _horizontalInitialScrollOffset - _hScrollStep;
                            }
                        }
                        if ( _horizontalInitialScrollOffset !== 0 ) {
                            xValue = -( _horizontalInitialScrollOffset * _hScrollWidth );
                        }
                        else {
                            xValue = 0;
                        }
                        _createHorizontalScrollBar();
                        _iconTextGroupMatrix.e = xValue;
                    }
                    break;
                default:
                    break;
            }
        },

        _scrollCallBack = function ( changeType, abs, perc ) {
            var nodeBBoxInfo, vCount = _count;//, percentile;
            _prevScrollPerc = perc;
            if ( _addExtraScroll ) {
                vCount++;
            }
            _scrollCount = Math.round(( vCount - _vpNodeCount ) * perc );
            //Below _scrollCount check is required for handling Page Up and Page Down events
            if ( _scrollCount < 0 ) {
                _scrollCount = 0;
            } else {
                if ( _scrollCount > vCount - _vpNodeCount ) {
                    _scrollCount = Math.round( vCount - _vpNodeCount );
                }
            }
            _setHorizontalLineVal();
            nodeBBoxInfo = _nodeHandler.onScroll( _scrollCount, _data, _isScrollbarCreated, _isAlarmsPresent, _horizontalLine );
            _updateNodeBBox( nodeBBoxInfo );
        },

        _scrollCallBackBC = function ( changeType, abs, perc ) {
            var yValue;
            _prevBCScrollPerc = perc;
            if ( perc !== 0 ) {
                yValue = -abs;
            }
            else {
                yValue = 0;
            }
            _breadcrumbGroupMatrix.f = yValue;
        },

        _scrollCallBackHoriz = function ( changeType, abs, perc ) {
            var xValue;
            _horizontalInitialScrollOffset = perc;
            if ( perc !== 0 ) {
                xValue = -abs;
            } else {
                xValue = 0;
            }
            _iconTextGroupMatrix.e = xValue;
        },

        _handleVScrollBar = function ( mousePoint, targetGroup, event, target ) {
            _scrollVerticalHandler.onScrollEvent( mousePoint, targetGroup, event, target );
            _unloadBreadCrumb();
        },

        _handleBCVScrollBar = function ( mousePoint, targetGroup, event, target ) {
            _scrollBCVerticalHandler.onScrollEvent( mousePoint, targetGroup, event, target );
        },

        _handleCBVScrollBar = function ( mousePoint, targetGroup, event, target ) {
            _filterComboBox.cbScrollVerticalHandler.onScrollEvent( mousePoint, targetGroup, event, target );
        },

        _handleHScrollBar = function ( mousePoint, targetGroup, event, target ) {
            _scrollHorizontalHandler.onScrollEvent( mousePoint, targetGroup, event, target );
        },

        _applyResize = function ( height ) {
            var actualHeight;
            if ( height > _ctrlHeight ) {
                actualHeight = height;
                _svgParent.setAttribute( 'height', ( height + 'px' ) );
            }
            else {
                actualHeight = _ctrlHeight;
                _svgParent.setAttribute( 'height', ( _ctrlHeight + 'px' ) );
            }
            _createVerticalScrollBar();
            _createHorizontalScrollBar();
            _updateBgRects();
            _setForUpdate();
        },

        _createVerticalScrollBar = function () {
            var
                left = _data.Left + _data.Width - _data.stylePropObj.ScrollBar.ScrollPadding, settings = {}, totalHeight, viewPortHeight, vCount = _count,
                topValue = _urlPartTotalHeight + _toolbarHeight + _searchComboBoxPartHeight;
            totalHeight = _count * _nodeHeight;
            viewPortHeight = _ctrlHeight - topValue;
            //Do not create vertical scrollbar if total height of tree is within viewport height or if viewport height is lesser than the node height i.e. height of one tree node.
            if ( viewPortHeight >= totalHeight || viewPortHeight < _nodeHeight ) {
                if ( _isScrollbarCreated ) {
                    _scrollVerticalHandler.remove();
                    _isScrollbarCreated = false;
                    _scrollCount = 0;
                }
                return;
            }
            if ( _addExtraScroll ) {
                vCount++;
            }
            settings.currentStyle = _data.currentStyle;
            settings.width = _data.stylePropObj.ScrollBar.Width;
            settings.height = viewPortHeight + _data.stylePropObj.ScrollBar.TopPadding;
            if ( _isHorizontalScrollbarCreated ) {
                settings.height = settings.height - _data.stylePropObj.ScrollBar.Width;
            }
            settings.height = settings.height < 0 ? 0 : settings.height;
            settings.id = 'tree_';
            settings.startValue = 0;
            settings.endValue = vCount - Math.round( _vpNodeCount );

            settings.initialScrollOffset = 0;
            settings.initialHeightPerc = ( _vpNodeCount ) / ( vCount );
            _vScrollStep = settings.scrollStep = 1 / ( vCount - Math.ceil( _vpNodeCount ) );
            settings.horizontalSliderHeight = _data.stylePropObj.ScrollBar.Width;
            if ( _isScrollbarCreated ) {
                _scrollVerticalHandler.remove();
                _prevScrollPerc = settings.initialScrollOffset = _scrollCount / ( settings.endValue );
            }
            _isScrollbarCreated = true;
            _scrollVerticalHandler.createScrollBar( settings, left, topValue, _scrollbarGrp, _scrollCallBack, false );
        },

        // Vertical scroll bar for Breadcrumb 
        _createBCVerticalScrollBar = function () {
            var settings = {},
                left = _crumbNodeNameWidth + 40,
                topValue = _toolbarHeight + _data.URLPart.imageIconRect.height + ( _urlPartTotalHeight - _data.URLPart.imageIconRect.height ) / 2,
                totalHeight = _crumbChildren.length * _nodeDomHeight;
            if ( ( _ctrlHeight - topValue - _toolbarHeight ) > totalHeight ) {
                if ( _isBCVerticalScrollbarCreated ) {
                    _scrollBCVerticalHandler.remove();
                    _isBCVerticalScrollbarCreated = false;
                }
                return;
            }
            settings.currentStyle = _data.currentStyle;
            settings.width = 15;
            settings.horizontalSliderHeight = 15;
            if ( _isHorizontalScrollbarCreated ) {
                settings.height = _ctrlHeight - topValue - _hScrollbarHeight;
                _vBCScrollHeight = settings.endValue = _nodeDomHeight * _crumbChildren.length - _ctrlHeight + topValue + _hScrollbarHeight;
            } else {
                settings.height = _ctrlHeight - topValue;
                _vBCScrollHeight = settings.endValue = _nodeDomHeight * _crumbChildren.length - _ctrlHeight + topValue;
            }
            _vBCScrollStep = settings.scrollStep = 1 / _crumbChildren.length;
            settings.initialHeightPerc = ( _ctrlHeight - _toolbarHeight - _nodeDomHeight ) / ( _crumbChildren.length * _nodeDomHeight );
            settings.initialScrollOffset = 0;
            settings.id = 'bc_';
            if ( _isBCVerticalScrollbarCreated ) {
                _scrollBCVerticalHandler.remove();
                settings.initialScrollOffset = ( _prevBCScrollPerc * _vBCScrollHeight ) / ( settings.endValue );
            }
            topValue = 0;
            _scrollBCVerticalHandler.createScrollBar( settings, left, topValue, _bcParentGrp, _scrollCallBackBC, false );
            _isBCVerticalScrollbarCreated = true;
        },

        _createHorizontalScrollBar = function () {
            var
                left = 0, settings = {}, viewPortHeight, stylePropObj = _data.stylePropObj,
                topValue = _data.CtrlHeight + _nodeHeight - _data.ToolbarPart.border.topVal - ( 50 + stylePropObj.ScrollBar.TopPadding );
            _hScrollbarHeight = stylePropObj.ScrollBar.Width;
            settings.currentStyle = _data.currentStyle;
            settings.width = _data.CtrlWidth;
            viewPortHeight = _ctrlHeight - _urlPartTotalHeight + _data.Top - _toolbarHeight - _searchComboBoxPartHeight;
            if ( _isScrollbarCreated ) {
                settings.width = settings.width - stylePropObj.ScrollBar.Width;
            }
            if ( _isAlarmsPresent ) {
                settings.width = settings.width - CPM.Enums.Constants.alarmIconWidth;
            }
            _iconTextGroup = _nodeHandler.getIconTextGroup();
            if ( _iconTextGroup ) {
                _iconTextGroupMatrix = _iconTextGroup.transform.baseVal.getItem( 0 ).matrix;
            }
            //Do not create horizontal scrollbar if deepest node width of tree is within viewport width or if viewport height is lesser than the node height i.e. height of one tree node.
            if ( _deepestNodeWidth < settings.width || viewPortHeight < _nodeHeight ) {
                if ( _isHorizontalScrollbarCreated ) {
                    _scrollHorizontalHandler.remove();
                    _isHorizontalScrollbarCreated = false;
                    _iconTextGroupMatrix.e = 0;
                }
                return;
            } else {
                settings.horizontalSliderHeight = _hScrollbarHeight;
                settings.height = _hScrollbarHeight;
                _hScrollWidth = settings.endValue = _deepestNodeWidth - settings.width;
                _hScrollStep = settings.scrollStep = ( 1 / settings.endValue ) * 10;
                settings.initialHeightPerc = ( settings.width ) / ( _deepestNodeWidth );
                settings.initialScrollOffset = 0;
                if ( _isHorizontalScrollbarCreated ) {
                    _scrollHorizontalHandler.remove();
                    if ( _horizontalInitialScrollOffset ) {
                        settings.initialScrollOffset = _horizontalInitialScrollOffset;
                    }
                    _isHorizontalScrollbarCreated = false;
                    _iconTextGroupMatrix.e = 0;
                }
                _isHorizontalScrollbarCreated = true;
                _scrollHorizontalHandler.createScrollBar( settings, left, topValue, _svgParent, _scrollCallBackHoriz, true, _horizontalLine );
            }
        },

        _setHorizontalLineVal = function () {
            if ( _isScrollbarCreated && _isHorizontalScrollbarCreated && _isAlarmsPresent ) {
                _horizontalLine = true;
            } else {
                _horizontalLine = false;
            }
        },

        _getNodeDomHeight = function () {
            return _nodeHeight;
        },

        //update Parent Dims
        _updateParentDims = function () {
            var treeControl, treeViewPortHeight;
            if ( _svgParent ) {
                treeControl = _svgParent.firstElementChild; //TODO:Remove hard coded id
                if ( treeControl && treeControl.getBBox ) {
                    treeViewPortHeight = _urlPartTotalHeight + ( ( _count ) * _nodeHeight );
                    _applyResize( treeViewPortHeight );
                }
            }
        },

        _toRGBA = function ( num ) {
            /*jslint bitwise: true */
            num >>>= 0;
            var b = num & 0xFF,
                g = ( num & 0xFF00 ) >>> 8,
                r = ( num & 0xFF0000 ) >>> 16,
                a = ( ( num & 0xFF000000 ) >>> 24 ) / 255;
            /*jslint bitwise: false */

            return 'rgba(' + [r, g, b, a].join( ',' ) + ')';
        },

        _isNodeInViewport = function ( index ) {
            if ( index >= _scrollCount && ( index < _vpNodeCount + _scrollCount ) ) {
                return true;
            } else {
                return false;
            }
        },

        _traverseRawdata = function ( nodeObj, parentNode ) {
            var i = 0, childName, node = {}, formattedNode,
                children,
                child,
                childCount,
                prevIndexAtDepth = 0;
            prevIndexAtDepth = node.index = _count++;
            node.Name = nodeObj[0];

            node.Id = nodeObj[1];
            if ( nodeObj[5] ) {
                node.InstanceId = nodeObj[5];
            }
            node.ChildCount = nodeObj[3];
            node.fullPath = nodeObj[2];
            if ( nodeObj[5] === '0.0.0.0.0.0' ) {
                node.IsLinked = false;
            } else {
                node.IsLinked = true;
            }
            node.IsExpanded = false;
            node.IsLeaf = true;
            node.ParentId = nodeObj.ParentId;
            if ( nodeObj.depth === undefined || nodeObj.depth === null ) {
                node.depth = 0;
            }
            else {
                node.depth = nodeObj.depth;
            }
            if ( nodeObj.length > 6 && nodeObj[6].length > 0 ) {//Children array is sent at the 6th index from server
                children = nodeObj[6].splice( 0 );
                node.Children = [];
                node.IsExpanded = true;
                node.IsLeaf = false;
            }
            if ( node.ChildCount > 0 ) {
                node.IsLeaf = false;
            }
            node.height = TEXT_BBOX.height;
            if ( children ) {
                childCount = children.length;
                for ( i = 0; i < childCount; i++ ) {
                    child = children[i];
                    child.ParentId = node.Id;
                    child.prevIndexAtDepth = prevIndexAtDepth;
                    if ( node.IsExpanded === true ) {
                        child.depth = node.depth + 1;
                        if ( child.depth >= _deepestIdx ) {
                            _deepestNode = child[1];
                            _deepestIdx = child.depth;
                            childName = child[0];
                        }
                    }
                    formattedNode = _traverseRawdata( child, node );
                    formattedNode.Parent = node;
                    node.Children.push( formattedNode );
                    prevIndexAtDepth = child.index;
                }
            }
            if ( !node.Parent && parentNode ) {
                node.Parent = parentNode;
            }
            node.isSelected = false;
            if ( _prevNodeSelected && _prevNodeSelected.Id === node.Id ) {
                node.isSelected = true;
            }
            return node;
        },

        _unloadBreadCrumb = function () {
            _crumbChildren = [];
            _showCrumb = false;
            _clickedURLNodeId = null;
            _isBreadCrumbCreated = false;
            _prevHoveredNodeId = null;
            if ( _isBCVerticalScrollbarCreated ) {
                _isBCVerticalScrollbarCreated = false;
                _scrollBCVerticalHandler.remove();
                _breadcrumbGroupMatrix.f = 0;
                _prevBCScrollPerc = 0;
            }
            _removeBCOverlay();
            _breadCrumb.unloadBreadCrumb();
            _breadCrumb.updateNodeImage();   // reset the arrow of URL part if empty area of viewport is clicked
        },
        _getBgAttributes = function () {
            var data = {}, count, nodeHeight;
            nodeHeight = _getNodeDomHeight();
            count = ( _data.CtrlHeight - _urlPartTotalHeight - _toolbarHeight - _searchComboBoxPartHeight ) / nodeHeight;
            //Checking if the total count of bg rects is a whole number. If its whole number then all the bg rects are drawn completely. Hence scrolling should not be adjusted.
            //If the count contains decimal values that means the last bg rect is partially drawn. Hence we add an extra scroll step to the scrollbar so that the last node data is fully displayed on last scroll.
            if ( count !== Math.floor( count ) ) {
                _addExtraScroll = true;
            } else {
                _addExtraScroll = false;
            }
            data.nodeHeight = nodeHeight;
            _vpNodeCount = Math.ceil( count ); //needed for vertical scrollbar
            //we are not considering height of toolbar, breadcrumb, search combobox because setting _treeGroupMatrix.f after creation of all the groups
            //creating extra bgrects than required especially for handling dynamization(hide Toolbar and breadcrumb) to avoid remove and creation of rects
            data.count = Math.ceil( _data.CtrlHeight / nodeHeight );
            data.Top = _data.Top;
            data.ToolbarHeight = _data.ToolbarPart.border.height;
            data.UrlHeight = _data.URLPart.border.height;
            data.SearchComboBoxHeight = _data.SearchComboBoxPart.border.height;
            data.Left = _data.Left;
            data.SelectionBackColor = _data.SelectionBackColor;
            data.SelectionForeColor = _data.SelectionForeColor;
            data.Width = _data.Width;
            data.white = _data.white;
            data.grey3 = _data.grey3;
            data.HorizLineColor = _data.HorizLineColor;
            data.ExpCollIconColor = _data.ExpCollIconColor;
            data.NodeIconColor = _data.NodeIconColor;
            data.SelectionNodeIconColor = _data.SelectionNodeIconColor;
            return data;
        },

        _createBgRects = function () {
            var attrs;
            _treeGroup = document.getElementById( 'treeGroup' );
            _treeGroupMatrix = _treeGroup.transform.baseVal.getItem( 0 ).matrix;
            _treeAlarmIconGroup = document.getElementById( 'treeAlarmIconGroup' );
            attrs = _getBgAttributes();
            _nodeHandler.createBgRects( _treeGroup, attrs );
            _treeGroupMatrix.f = _toolbarHeight + _urlPartTotalHeight + _searchComboBoxPartHeight;
        },

        _updateBgRects = function () {
            while ( _treeGroup.firstChild ) {
                _treeGroup.removeChild( _treeGroup.lastChild );
            }
            _createBgRects();
        },

        _createAlarmBgRects = function () {
            var attrs;
            attrs = _getBgAttributes();
            _nodeHandler.createAlarmBgRects( _treeAlarmIconGroup, attrs );
        },

        _removeAlarmBgRects = function () {
            while ( _treeAlarmIconGroup.firstChild ) {
                _treeAlarmIconGroup.removeChild( _treeAlarmIconGroup.lastChild );
            }
        },

        _createBCRects = function () {
            var data = {}, urlPartGroupCreated;
            urlPartGroupCreated = document.getElementById( 'URLPart' );
            if ( urlPartGroupCreated ) {
                _breadCrumb.updateNodeURL( _data.URLPart );
            } else {
                data.Left = _data.Left;
                data.Top = _data.ToolbarPart.border.height;
                data.Width = _data.Width;
                data.stylePropObj = _data.stylePropObj;
                data.BackColor = _data.BackColor;
                data.imageWidth = _data.URLPart.imageIconRect.width;
                data.imageHeight = _data.URLPart.imageIconRect.height;
                data.nodeHeight = _getNodeDomHeight();
                data.urlHeight = _data.URLPart.border.height;
                data.borderWidth = _data.URLPart.border.width;
                data.strokeWidth = _data.URLPart.border.strokeWidth;
                data.Font = _data.Font;
                _breadCrumb.createBCRects( _treeControlGroup, _urlGroup, data );
                _breadCrumb.createURLPart( _data.URLPart );
            }
            if ( _showBreadCrumb ) {
                _urlGroup.setAttribute( 'display', 'block' );
            } else {
                _urlGroup.setAttribute( 'display', 'none' );
            }
            _urlGroupMatrix.f = _data.ToolbarPart.border.height;
        },

        _updateTreeComponents = function () {
            var count, nodeHeight = _getNodeDomHeight();
            count = ( _data.CtrlHeight - _urlPartTotalHeight - _toolbarHeight - _searchComboBoxPartHeight ) / nodeHeight;
            _vpNodeCount = Math.ceil( count );
            _updateSearchComboBox();
            _setForUpdate();
        },

        _showBreadcrumbArea = function () {
            _urlPartTotalHeight = _data.URLPart.border.height = CPM.Enums.Constants.urlHeight;
            if ( _urlGroup ) {
                _urlGroup.setAttribute( 'display', 'block' );
            }
            if ( _showToolBar ) {
                _urlGroupMatrix.f = CPM.Enums.Constants.toolbarHeight;
                _treeGroupMatrix.f = CPM.Enums.Constants.toolbarHeight + CPM.Enums.Constants.urlHeight + _searchComboBoxPartHeight;
            } else {
                _urlGroupMatrix.f = 0;
                _treeGroupMatrix.f = CPM.Enums.Constants.urlHeight + _searchComboBoxPartHeight;
            }
        },

        _hideBreadcrumbArea = function () {
            _urlPartTotalHeight = _data.URLPart.border.height = 0;
            if ( _urlGroup ) {
                _urlGroup.setAttribute( 'display', 'none' );
            }
            if ( _showToolBar ) {
                _treeGroupMatrix.f = CPM.Enums.Constants.toolbarHeight + _searchComboBoxPartHeight;
            } else {
                _treeGroupMatrix.f = _searchComboBoxPartHeight;
            }
        },

        _createFilterRects = function () {
            var yVal, xVal, stroke, top;
            top = _data.ToolbarPart.border.height + _data.URLPart.border.height;
            yVal = top;
            xVal = 0;
            _isFilterRectsCreated = true;
            if ( _createFilter && _data.CtrlWidth < ( ( 2 * CPM.Enums.Constants.searchComboBoxMinWidth ) + ( 3 * CPM.Enums.Constants.searchComboBoxPadding ) ) ) {
                if ( _searchComboBoxPartHeight !== ( 2 * CPM.Enums.Constants.searchBackRectHeight ) - CPM.Enums.Constants.searchComboBoxPadding ) {
                    _data.SearchComboBoxPart.border.height = _searchComboBoxPartHeight = ( 2 * _data.SearchComboBoxPart.border.height ) - CPM.Enums.Constants.searchComboBoxPadding;
                }
                _moveBelow = true;
            } else {
                _data.SearchComboBoxPart.border.height = _searchComboBoxPartHeight = CPM.Enums.Constants.searchBackRectHeight;
                _moveBelow = false;
            }
            CPM.svgUtil.createSVG( 'rect', {
                x: xVal,
                y: yVal,
                id: 'searchComboBoxRect',
                width: ( _data.CtrlWidth - xVal ) < 0 ? 0 : _data.CtrlWidth - xVal,
                height: _data.SearchComboBoxPart.border.height,
                fill: _data.stylePropObj.Control.EvenBackColor,
                appendTo: _searchComboBoxGroup
            } );
            if ( _isExtendedStyle ) {
                stroke = _data.stylePropObj.ToolBar.BottomLineColor;
            } else {
                stroke = _data.stylePropObj.Control.HorizLineColor;
            }
            CPM.svgUtil.createSVG( 'line', {
                id: 'searchComboBoxLine',
                x1: 0,
                y1: top + _data.SearchComboBoxPart.border.height,
                x2: _data.CtrlWidth,
                y2: top + _data.SearchComboBoxPart.border.height,
                stroke: stroke,
                'stroke-width': 1,
                appendTo: _searchComboBoxGroup
            } );
        },
        _updateFilterRects = function () {
            var topVal, rect, line;
            rect = _svgParent.getElementById( 'searchComboBoxRect' );
            line = _svgParent.getElementById( 'searchComboBoxLine' );
            if ( _createFilter && _data.CtrlWidth < ( ( 2 * CPM.Enums.Constants.searchComboBoxMinWidth ) + ( 3 * CPM.Enums.Constants.searchComboBoxPadding ) ) ) {
                if ( _searchComboBoxPartHeight !== ( 2 * CPM.Enums.Constants.searchBackRectHeight ) - CPM.Enums.Constants.searchComboBoxPadding ) {
                    _data.SearchComboBoxPart.border.height = _searchComboBoxPartHeight = ( 2 * _data.SearchComboBoxPart.border.height ) - CPM.Enums.Constants.searchComboBoxPadding;
                }
                _moveBelow = true;
            } else {
                _data.SearchComboBoxPart.border.height = _searchComboBoxPartHeight = CPM.Enums.Constants.searchBackRectHeight;
                _moveBelow = false;
            }
            topVal = _data.ToolbarPart.border.height + _data.URLPart.border.height;
            _data.SearchComboBoxPart.border.width = _data.CtrlWidth;
            if ( rect ) {
                rect.setAttribute( 'height', _searchComboBoxPartHeight );
                rect.setAttribute( 'y', topVal );
                rect.setAttribute( 'width', _data.CtrlWidth );
            }
            if ( line ) {
                line.setAttribute( 'y1', ( topVal + _searchComboBoxPartHeight ) );
                line.setAttribute( 'y2', ( topVal + _searchComboBoxPartHeight ) );
                line.setAttribute( 'x2', _data.CtrlWidth );
            }
        },
        _removeFilterRects = function () {
            _isFilterRectsCreated = false;
            while ( _searchComboBoxGroup && _searchComboBoxGroup.firstChild ) {
                if ( _searchComboBoxGroup.firstChild.id === '_comboBoxElementsGroup' ) {
                    break;
                }
                else {
                    _searchComboBoxGroup.removeChild( _searchComboBoxGroup.firstChild );
                }
            }
        },
        _updateBCStyle = function () {
            if ( _breadCrumb ) {
                _breadCrumb.updateBCStyle( _data.stylePropObj );
            }
        },
        _showToolbarLine = function () {
            var bottomLine = false;
            if ( _showToolBar && !_showBreadCrumb ) {
                bottomLine = true;
            }
            return bottomLine;
        },
        //Creates toolbar expand, collapse buttons and background rect behind those buttons
        _createToolbar = function () {
            var data = {}, bottomLine = false;
            data.Left = _data.Left;
            data.white = _data.stylePropObj.Control.EvenBackColor;
            data.ToolbarPart = _data.ToolbarPart;
            data.Enabled = _data.Enabled;
            data.isExtendedStyle = _isExtendedStyle;
            data.pressedbuttonStyles = { fill: _isExtendedStyle ? _comboBoxHandler.getGuideStyles( CPM.Enums.ComboGradients.ButtonPressed ) : _data.stylePropObj.ComboBox.PressedbuttonColor };
            data.filterBtnState = _showSearchComboBox ? 1 : 0;
            data.Width = _data.CtrlWidth;
            bottomLine = _showToolbarLine();
            _toolbar.createToolbar( _treeControlGroup, _toolbarGroup, data, bottomLine );
            if ( _showToolBar ) {
                _toolbarGroup.setAttribute( 'display', 'block' );
            } else {
                _toolbarGroup.setAttribute( 'display', 'none' );
            }
        },

        _showToolbarArea = function () {
            _toolbarHeight = _data.ToolbarPart.border.height = CPM.Enums.Constants.toolbarHeight;
            if ( _toolbarGroup ) {
                _toolbarGroup.setAttribute( 'display', 'block' );
            }

            if ( _showBreadCrumb ) {
                _urlGroupMatrix.f = CPM.Enums.Constants.toolbarHeight;
                _treeGroupMatrix.f = CPM.Enums.Constants.toolbarHeight + CPM.Enums.Constants.urlHeight + _searchComboBoxPartHeight;
            } else {
                _treeGroupMatrix.f = CPM.Enums.Constants.toolbarHeight + _searchComboBoxPartHeight;
            }
        },

        _hideToolbarArea = function () {
            _toolbarHeight = _data.ToolbarPart.border.height = 0;
            if ( _toolbarGroup ) {
                _toolbarGroup.setAttribute( 'display', 'none' );
            }
            if ( _showBreadCrumb ) {
                _urlGroupMatrix.f = 0;
                _treeGroupMatrix.f = CPM.Enums.Constants.urlHeight + _searchComboBoxPartHeight;
            } else {
                _treeGroupMatrix.f = _searchComboBoxPartHeight;
            }
        },
        _updateToolBarStyles = function ( currentStyle ) {
            var bottomLine = false, pressedbuttonStyles;
            bottomLine = _showToolbarLine();
            pressedbuttonStyles = { fill: _isExtendedStyle ? _comboBoxHandler.getGuideStyles( CPM.Enums.ComboGradients.ButtonPressed ) : _data.stylePropObj.ComboBox.PressedbuttonColor };
            if ( _toolbar ) {
                _toolbar.updateToolBarStyles( currentStyle, bottomLine, pressedbuttonStyles );
            }
        },
        _callbackOnSelect = function ( data ) {
            var values = _getValues( _options );
            if ( _selectedFilter === values[data] ) {
                return;//Do nothing if the filter is already applied.
            }
            _selectedFilter = values[data];
            if ( _selectedFilter === _options['TBID_NODE_PENDINGALARMS'] ) {
                WebCC.Properties.Filter = CPM.Enums.Filter.NodeWithPendingAlarms;
            } else if ( _selectedFilter === _options['TBID_NODE_VISUALIZATION'] ) {
                WebCC.Properties.Filter = CPM.Enums.Filter.NodeWithVisualization;
            } else {
                WebCC.Properties.Filter = CPM.Enums.Filter.None;
            }

            _filterComboBox.setSelectedOption( _selectedFilter );
            self.filter();
        },
        _updateSearchComboBoxStyle = function () {
            var bgRect, line, stroke;
            bgRect = _svgParent.getElementById( 'searchComboBoxRect' );
            line = _svgParent.getElementById( 'searchComboBoxLine' );
            if ( bgRect ) {
                bgRect.setAttribute( 'fill', _data.stylePropObj.Control.EvenBackColor );
            }
            if ( line ) {
                if ( _isExtendedStyle ) {
                    stroke = _data.stylePropObj.ToolBar.BottomLineColor;
                } else {
                    stroke = _data.stylePropObj.Control.HorizLineColor;
                }
                line.setAttribute( 'stroke', stroke );
            }
        },
        _updateComboBoxStyle = function () {
            var styles;
            if ( _filterComboBox ) {
                styles = {
                    comboBoxStyles: { fill: _isExtendedStyle ? _comboBoxHandler.getGuideStyles( CPM.Enums.ComboGradients.IOFieldNormal ) : _data.stylePropObj.ComboBox.ComboBoxColor },
                    normalbuttonStyles: { fill: _isExtendedStyle ? _comboBoxHandler.getGuideStyles( CPM.Enums.ComboGradients.ButtonNormal ) : _data.stylePropObj.ComboBox.NormalbuttonColor },
                    pressedbuttonStyles: { fill: _isExtendedStyle ? _comboBoxHandler.getGuideStyles( CPM.Enums.ComboGradients.ButtonPressed ) : _data.stylePropObj.ComboBox.PressedbuttonColor }
                };
                _filterComboBox.updateComboBoxStyle( _data.currentStyle, styles );
            }
        },
        _registerAndSetLocale = function () {
            WebCC.Extensions.X_Textbib.registerTextResource( 'CPM' );
            WebCC.Extensions.X_Textbib.setLocale( 1033 );
        },
        _validateFilterCombination = function () {
            if ( _selectedFilter === undefined && ( ( WebCC.Properties.Filter === CPM.Enums.Filter.NodeWithPendingAlarms && _screenWindowCompanion && _screenWindowCompanion.length > 0 ) || ( WebCC.Properties.Filter === CPM.Enums.Filter.NodeWithVisualization && _alarmComapnion && _alarmComapnion.length > 0 ) || ( ( WebCC.Properties.Filter === CPM.Enums.Filter.NodeWithPendingAlarms || WebCC.Properties.Filter === CPM.Enums.Filter.NodeWithVisualization ) && _shcCompanion && _shcCompanion.length > 0 ) ) ) {
                _selectedFilter = _options['TBID_NONE'];
            }
        },
        _createFilterDropDown = function () {
            var attributes = {};
            if ( navigator.userAgent.indexOf( 'Firefox' ) !== -1 ) {
                setTimeout( function () {
                    _registerAndSetLocale();
                }, 0 );
            } else {
                _registerAndSetLocale();
            }
            _options['TBID_NONE'] = WebCC.Extensions.X_Textbib.getText( 'TBID_NONE' );
            if ( _alarmComapnion && _alarmComapnion.length > 0 ) {
                _options['TBID_NODE_PENDINGALARMS'] = WebCC.Extensions.X_Textbib.getText( 'TBID_NODE_PENDINGALARMS' );
            }
            if ( _screenWindowCompanion && _screenWindowCompanion.length > 0 ) {
                _options['TBID_NODE_VISUALIZATION'] = WebCC.Extensions.X_Textbib.getText( 'TBID_NODE_VISUALIZATION' );
            }
            _filterComboBox.setOptions( _getValues( _options ) );
            attributes = _getFilterComboBoxAttributes();
            _filterComboBox.draw( _searchComboBoxGroup, attributes, 400 );
            switch ( WebCC.Properties.Filter ) {
                case CPM.Enums.Filter.NodeWithPendingAlarms:
                    _selectedFilter = _options['TBID_NODE_PENDINGALARMS'];
                    break;
                case CPM.Enums.Filter.NodeWithVisualization:
                    _selectedFilter = _options['TBID_NODE_VISUALIZATION'];
                    break;
                default:
                    _selectedFilter = _options['TBID_NONE'];
                    break;
            }
            _validateFilterCombination();
            _filterComboBox.setSelectedOption( _selectedFilter );
        },
        _getComboBoxWidth = function ( width ) {
            width = ( width / 2 ) - CPM.Enums.Constants.searchBoxLeftPadding;
            width = width <= CPM.Enums.Constants.searchComboBoxMinWidth ? CPM.Enums.Constants.searchComboBoxMinWidth : width;
            return width;
        },
        _getFilterComboBoxAttributes = function () {
            var width, top, left, comboPadding = CPM.Enums.Constants.searchComboBoxPadding, attributes, topCbOptions;
            if ( _moveBelow ) {
                width = _data.Width - ( 2 * comboPadding );
                top = _data.ToolbarPart.border.height + _data.URLPart.border.height + CPM.Enums.Constants.searchBoxTopPadding + CPM.Enums.Constants.searchBackRectHeight - comboPadding;
                left = comboPadding;
            } else {
                width = _getComboBoxWidth( _data.Width );
                top = _data.ToolbarPart.border.height + _data.URLPart.border.height + CPM.Enums.Constants.searchBoxTopPadding;
                left = _data.Width - width - comboPadding;
            }
            topCbOptions = _data.ToolbarPart.border.height + _data.URLPart.border.height + _data.SearchComboBoxPart.border.height;
            attributes = {
                height: _data.SearchComboBoxPart.border.buttonHeight,
                left: left,
                optionsLeft: left,
                optionsWidth: width,
                top: top,
                width: width,
                ctrlHeight: _data.CtrlHeight,
                topCbOptions: topCbOptions
            };
            return attributes;
        },
        _createSearchBox = function () {
            var attrs = {};
            attrs.left = _data.Left;
            attrs.toolbarHeight = _data.ToolbarPart.border.height;
            attrs.urlHeight = _data.URLPart.border.height;
            attrs.width = _data.CtrlWidth;
            attrs.currentStyle = _data.currentStyle;
            attrs.isComboBoxBelow = _moveBelow;
            _searchBox.create( _divParent, attrs );
        },

        _retainCheckByFilterAndSearch = function ( node, currentFilterData, comparableOperand ) {
            var child,
                length,
                children;

            if ( node ) {
                node.canRetain = false;
                children = node.Children || [];
                length = children.length;

                while ( length-- ) {
                    child = children[length];

                    if ( !child.IsLeaf ) {
                        _retainCheckByFilterAndSearch( child, currentFilterData, comparableOperand );
                    }
                    else {
                        child.canRetain = false;
                    }

                    if ( currentFilterData[child.fullPath] === comparableOperand ) {
                        child.canRetain = child.hasSearchText;
                        if ( child.IsLinked && child.hasChildWithSearchText && Object.keys( currentFilterData ).indexOf( child.fullPath ) !== -1 ) {
                            child.canRetain = _checkChildRetainState( child.Children );
                            if ( currentFilterData[child.fullPath] !== comparableOperand ) {
                                child.canRetain = false;
                            } else {
                                if ( !child.canRetain && child.hasSearchText ) {
                                    child.canRetain = true;
                                }
                            }
                        }
                    } else if ( child.hasChildWithSearchText && Object.keys( currentFilterData ).indexOf( child.fullPath ) !== -1 ) {
                        child.canRetain = _checkChildRetainState( child.Children );
                    } else if ( child.hasSearchText && child.IsLeaf && child.IsLinked ) {
                        child.canRetain = false;
                    }
                    else {
                        child.canRetain = false;
                    }

                    if ( !node.canRetain && child.canRetain ) {
                        node.canRetain = true;
                    }
                }
                if ( node.canRetain && node.Parent ) {
                    node.Parent.canRetain = true;
                }
            }
        },

        _checkChildRetainState = function ( child ) {
            var i, length = child.length, canRetain = false;
            for ( i = 0; i < length; i++ ) {
                if ( child[i].canRetain ) {
                    canRetain = child[i].canRetain;
                    return canRetain;
                }
            }
            return canRetain;
        },

        _markByFilterAndSearch = function () {
            if ( _data.NodePart.length ) {
                if ( _selectedFilter === _options['TBID_NODE_PENDINGALARMS'] && _alarmData && Object.keys( _alarmData ).length !== 0 ) {
                    _retainCheckByFilterAndSearch( _data.NodePart[0], _alarmData.ActiveAlarms, 1 );
                }
                else {
                    if ( _selectedFilter === _options['TBID_NODE_VISUALIZATION'] && _screenData && Object.keys( _screenData ).length !== 0 ) {
                        _retainCheckByFilterAndSearch( _data.NodePart[0], _screenData.ScreenFilter, 1 );
                    }
                }
            }
        },

        _setBeforeTraverse = function () {
            var node, parentNode;
            _count = 0;
            _linearDataArray = [];

            if ( _selectedFilter !== _options['TBID_NONE'] ) {
                _markByFilterAndSearch();
            }

            if ( _navigationType === CPM.Enums.NavigationType.Dynamic && _navigatedNodeId ) {
                node = _getNodeData( _navigatedNodeId );
                if ( node ) {
                    if ( node.IsLeaf ) {
                        parentNode = _getNodeData( node.ParentId );
                        if ( parentNode ) {
                            _traverse( parentNode );
                        }
                    } else {
                        node.depth = 0;
                        if ( _svgParent && _svgParent.TifProperties ) {
                            _svgParent.TifProperties.item.nodeId = _navigatedNodeId;
                        }
                        _traverse( node );
                    }
                }
            } else {
                _traverse( _data.NodePart[0] );
            }
        },

        _updateNodeBBox = function ( nodeBBoxInfo ) {
            if ( nodeBBoxInfo ) {
                _deepestNodeWidth = nodeBBoxInfo.nodeWidth;
                TEXT_BBOX = nodeBBoxInfo.textBBox;
                _createHorizontalScrollBar();
            }
        },

        _setRootNode = function () {
            var paramValues, paramIds;
            if ( _rootNode !== '' ) {
                _updateRootNode( _rootNode );
            }
            else {
                paramValues = [CPM.Enums.BrowsingMode.Hierarchies];
                paramIds = [0];
                WebCC.Extensions.HMI.DomainLogic.sendDLEvent( paramIds, paramValues );
            }
        },

        _setForUpdate = function ( alarmData ) {
            var nodeBBoxInfo,
                isResetScrollIndexReq = false;
            if ( !_scrollCount ) {
                isResetScrollIndexReq = true;
            }
            nodeBBoxInfo = _nodeHandler.updateBgRects( _linearDataArray, isResetScrollIndexReq, _data, _isAlarmsPresent );
            if ( nodeBBoxInfo ) {
                _deepestNodeWidth = nodeBBoxInfo.nodeWidth;
                _createHorizontalScrollBar();
            }
            _createVerticalScrollBar();
            _setHorizontalLineVal();
            _nodeHandler.updateAlarmSummary( alarmData, _data, _isScrollbarCreated, _isAlarmsPresent, _horizontalLine );
            if ( _tbUpdateRequired && _prevNodeSelected ) {
                _tbUpdateRequired = false;
                _updateToolbarButtons( _prevNodeSelected );
            }
        },

        _resetScrollCount = function ( nodeData ) {
            var nodeBBoxInfo;
            if ( _count > _vpNodeCount ) {
                if ( nodeData.index < ( _count - _vpNodeCount ) ) {
                    _scrollCount = nodeData.index;
                }
                else {
                    _scrollCount = Math.round( _count - _vpNodeCount );
                    if ( nodeData.index === _count - 1 ) {
                        _scrollCount = _scrollCount + 1;
                    }
                }
            }
            _setHorizontalLineVal();
            nodeBBoxInfo = _nodeHandler.onScroll( _scrollCount, _data, _isScrollbarCreated, _isAlarmsPresent, _horizontalLine );
            _updateNodeBBox( nodeBBoxInfo );
            _createVerticalScrollBar();
            _unloadBreadCrumb();
        },

        _resetTree = function () {
            var selectedNode;
            if ( _selectedNodeId ) {
                selectedNode = _getNodeData( _selectedNodeId );
                selectedNode.isSelected = false;
                _nodeHandler.setSelectedNode( selectedNode, _data, _isAlarmsPresent, _horizontalLine );
                _selectedNodeId = undefined;
            }
            _prevNodeSelected = null;
            _prevSelectedCrumbNode = null;
            _prevSelectedBCNodeId = null;
            _deepestNodeWidth = 0;
            if ( _iconTextGroupMatrix ) {
                _iconTextGroupMatrix.e = 0;
            }
            _horizontalInitialScrollOffset = 0;
            _scrollCount = 0;
            _unloadBreadCrumb();
            _updateURLData( _data.NodePart[0] );
        },

        _sendSummaryInfo = function ( nodeData ) {
            var nodePath, paramValues, filterString, index, companionCount = _alarmComapnion.length;
            if ( _alarmComapnion && companionCount > 0 ) {
                if ( !nodeData ) {
                    nodePath = _data.NodePart[0].fullPath;
                    paramValues = [9, 'Area = \'' + nodePath + '\'' + ' OR Area LIKE \'' + nodePath + '/*\''];
                    WebCC.Extensions.HMI.DomainLogic.sendDLEvent( [0, 1], paramValues );
                }
                else {
                    nodePath = nodeData.fullPath;
                    for ( index = 0; index < companionCount; index++ ) {
                        filterString = 'Area = \'' + nodePath + '\'';
                        if (!nodeData.IsLeaf && _alarmData.ActiveAlarms[nodeData.fullPath] !== 1) {
                            filterString = filterString + ' OR Area LIKE \'' + nodePath + '/*\'';
                        }
                        if (_alarmComapnion[index].CompanionConfig && _alarmComapnion[index].CompanionConfig.AlarmClassFilter) {
                            filterString = filterString + ' AND AlarmClassName = \'' + _alarmComapnion[index].CompanionConfig.AlarmClassFilter + '\'';
                        }
                        paramValues = [10,
                            CPM.Enums.CompanionTypes.Alarm,
                            _alarmComapnion[index].ControlRef,
                            filterString
                        ];

                        WebCC.Extensions.HMI.DomainLogic.sendDLEvent( [0, 1, 2, 3], paramValues );
                    }
                }
            }
        },

        _setScreenCompanions = function () {
            var idx, length = WebCC.Properties.Companions.length, control;
            for ( idx = 0; idx < length; idx++ ) {
                control = WebCC.Properties.Companions[idx];
                if ( control && control.ControlRef ) {
                    if ( control.ControlType === 'AlarmControl' && control.CompanionConfig && control.CompanionConfig.ShowAlarmSummary ) {
                        _alarmComapnion.push( control );
                        if ( !_createFilter ) {
                            _createFilter = true;
                        }
                    }
                    else if ( control.ControlType === 'ScreenWindow' ) {
                        _screenWindowCompanion.push( control );
                        if ( !_createFilter ) {
                            _createFilter = true;
                        }
                    }
                    else {
                        if ( control.ControlType === 'Calendar Control' ) {
                            _shcCompanion.push( control );
                        }
                    }
                }
            }
        },
        _showToolTip = function ( target, position ) {
            var trendIndex, temp, toolTipText, targetText;
            temp = target.id.split( '_' );
            trendIndex = parseInt( temp[temp.length - 1] );

            if ( isNaN( trendIndex ) ) {//Mouse hover on the selected trend in combobox
                if ( target.id === _id + '_ComboBox_OptionNumber_SelectedNode' ) {
                    toolTipText = _selectedFilter;
                    targetText = target.parentNode.textContent;
                }
            } else {//Mouse hover on the combobox options
                toolTipText = _getValues( _options )[trendIndex];
                targetText = _svgParent.getElementById( _id + '_ComboBox_SvgOptionNode_' + trendIndex ).textContent;
            }
            if ( toolTipText !== targetText ) {
                CPM.Common.Tooltip.show( position.x, position.y, toolTipText );
            }
        },

        _searchOrClearText = function ( isSearch ) {
            var inputText, node;
            if ( isSearch ) {
                inputText = _searchBox.searchText();
            } else {
                inputText = _searchBox.clearSearch();
                node = _getNodeData( _navigatedNodeId );
                if ( node && node.IsLeaf && node.isNodeNavigated && node.Parent && !node.Parent.isNodeNavigated ) {
                    _navigatedNodeId = null;
                }
            }
            _handleSearchText( inputText );
        },

        _setNavigatedNodeId = function ( nodeId ) {
            var node;
            _navigatedNodeId = nodeId;
            node = _getNodeData( nodeId );
            if ( node ) {
                node.isNodeNavigated = true;
            }
        },


        _setTifLibExpandoProps = function () {
            _svgParent.TifProperties = {
                tif: {},
                item: {
                    nodes: _data.NodePart[0],
                    navigationType: _navigationType,
                    nodeId: ( _navigationType === CPM.Enums.NavigationType.Dynamic ) ? _selectedNodeId : undefined
                }
            };
        },

        _addTifLibExpandoProps = function () {
            _svgParent.TifProperties.item = {
                nodes: _data.NodePart[0],
                findNode: function ( nodeId ) {
                    return _getNodeData( nodeId );
                },
                setFocus: function ( nodeId ) {
                    var nodeData = _getNodeData( nodeId );
                    _resetScrollCount( nodeData );
                },
                navigationType: _navigationType,
                nodeId: ( _navigationType === CPM.Enums.NavigationType.Dynamic ) ? _selectedNodeId : undefined
            };
        },

        _sendDLEventForCompanions = function ( instanceId ) {
            var paramValues, index, companionCount;
            companionCount = _screenWindowCompanion.length;
            if ( _screenWindowCompanion && companionCount > 0 ) {
                for ( index = 0; index < companionCount; index++ ) {
                    paramValues = [
                        CPM.Enums.BrowsingMode.ScreenWindow,
                        CPM.Enums.CompanionTypes.ScreenWindow,
                        _screenWindowCompanion[index].ControlRef, instanceId];
                    WebCC.Extensions.HMI.DomainLogic.sendDLEvent( [0, 1, 2, 3], paramValues );
                }
            }
            companionCount = _shcCompanion.length;
            if ( _shcCompanion && companionCount > 0 ) {
                for ( index = 0; index < companionCount; index++ ) {
                    paramValues = [CPM.Enums.BrowsingMode.AlarmOrSHC,
                    CPM.Enums.CompanionTypes['Calendar Control'],
                    _shcCompanion[index].ControlRef,
                        _selectedNodePath
                    ];
                    WebCC.Extensions.HMI.DomainLogic.sendDLEvent( [0, 1, 2, 3], paramValues );
                }
            }
        },

        _displayImmediateChildren = function ( event, targetNode, isBreadCrumbCreated ) {
            var nodeData, paramIds, node, paramValues;
            node = _breadCrumb.getBCNode( targetNode );
            _clickedURLNodeId = node.id;
            if ( isBreadCrumbCreated ) {
                _isBreadCrumbCreated = true;
            }
            if ( _isBreadCrumbCreated ) {
                if ( _prevHoveredNodeId !== node.id || _prevHoveredNodeId === null ) {
                    _unloadBreadCrumb();
                    _showCrumb = true;
                    _isBreadCrumbCreated = true;
                    nodeData = _getNodeData( node.id );
                    paramIds = [CPM.Enums.ObjectCountAttributes.Requested, CPM.Enums.ObjectCountAttributes.TreeOrList, CPM.Enums.ObjectCountAttributes.SystemId, CPM.Enums.ObjectCountAttributes.ObjectId, CPM.Enums.ObjectCountAttributes.SelectedNode, CPM.Enums.ObjectCountAttributes.NameFilter,
                    CPM.Enums.ObjectCountAttributes.PropertyFilter, CPM.Enums.ObjectCountAttributes.LanguageId, CPM.Enums.ObjectCountAttributes.BrowsingMode, CPM.Enums.ObjectCountAttributes.SortingMode, CPM.Enums.ObjectCountAttributes.SortByAttribute];
                    paramValues = [8, CPM.Enums.View.Tree, 0, , node.id, , , CPM.Enums.Language.English, CPM.Enums.BrowsingMode.ViewNode, , ]; //4 == VIEWROOT
                    WebCC.Extensions.HMI.DomainLogic.sendDLEvent( paramIds, paramValues );
                    _prevHoveredNodeId = node.id;
                }
                // setting horizontal distance for breadcrumb
                _crumbX = node.x + node.width + ( _data.URLPart.textPadding.left - _data.URLPart.imageIconSvg.width ) / 2;
                _breadCrumb.updateNodeImage( targetNode );
            }
        },

        //fire from templete to get text Dims
        _getTextBBox = function ( text ) {
            var bbox;
            bbox = CPM.svgUtil.getTextBBox( _data.Font, '' + text );
            TEXT_BBOX = bbox;
            return bbox;
        },

        //fire from templete on URL click
        _onURLClick = function ( node ) {
            var nodeData,
                firstViewPortNodeData,
                firstViewPortNode;
            if ( node ) {
                nodeData = _getNodeData( node.id );
                nodeData.isNodeNavigated = true;
                _navigatedNodeId = nodeData.Id;
                _setSelected( nodeData, false, true );
            }
            else {
                firstViewPortNode = _data.URLPart.viewportData[_data.URLPart.viewportData.length - 1];
                if ( firstViewPortNode ) {
                    firstViewPortNodeData = _getNodeData( firstViewPortNode.id );
                    nodeData = _getNodeData( firstViewPortNodeData.ParentId );
                }
            }
            if ( nodeData ) {
                //update URL Viewport
                _updateURLData( nodeData );
                _resetScrollCount( nodeData );
            }
        },

        _loadData = function ( nodeData, updateUrl ) {
            if ( nodeData.IsExpanded || nodeData.Children ) {
                if ( !nodeData.IsExpanded ) {
                    nodeData.IsExpanded = !nodeData.IsExpanded;
                }
                _setBeforeTraverse();
                _setForUpdate();
            } else {
                if ( updateUrl ) {
                    _isBCSelectionRequest = true;
                }
                _expandedNodeId = nodeData.Id;
                WebCC.Events.fire( 'onExpand', nodeData.fullPath );
                nodeData.IsExpanded = true;
                _callback( { name: nodeData.fullPath, id: nodeData.Id, isRequestData: true, isHierarchyNode: false } );
            }
        },

        _setSelectedFromBC = function ( crumbNode ) {
            var i, nodeData, child, childCount, parentNode;
            crumbNode.isSelected = true;
            _isNodeUpdated = true;
            if ( _prevSelectedCrumbNode ) {
                if ( _prevSelectedCrumbNode.Id === crumbNode.Id ) {
                    return;
                }
                else {
                    _prevSelectedCrumbNode.isSelected = false;
                }
            }
            _prevSelectedCrumbNode = crumbNode;
            _prevSelectedBCNodeId = crumbNode.Id;

            nodeData = _getNodeData( crumbNode.Id );
            if ( _navigationType === CPM.Enums.NavigationType.Dynamic && nodeData && nodeData.IsLeaf ) {
                parentNode = _getNodeData( nodeData.ParentId );
                if ( parentNode && parentNode.ParentId ) {
                    parentNode.childSelected = true;
                }
            }
            if ( nodeData ) {
                nodeData.isSelected = true;
                if ( _prevNodeSelected ) {
                    if ( _prevNodeSelected.Id !== crumbNode.Id ) {
                        _prevNodeSelected.isSelected = false;
                        //If full data is available and the selected node is not expanded, then expand the selected node and update the tree.
                        if ( !_prevNodeSelected.IsExpanded && _prevNodeSelected.Children ) {
                            _prevNodeSelected.IsExpanded = true;
                            childCount = _prevNodeSelected.Children.length;
                            for ( i = 0; i < childCount; i++ ) {
                                child = _prevNodeSelected.Children[i];
                                child.Visible = true;
                            }
                            _setBeforeTraverse();
                            _setForUpdate();
                        }
                    } else {
                        return;
                    }
                }
                _prevNodeSelected = nodeData;
                _updateToolbarButtons( _prevNodeSelected );
                //update WebCC Properties 
                WebCC.Properties.SelectedNode = _prevNodeSelected.fullPath;
                WebCC.Events.fire( 'onSelectionChanged', nodeData.fullPath );
                _selectedNodePath = nodeData.fullPath;
                _navigatedNodeId = _selectedNodeId = nodeData.Id; //setting selectedNode Id
                nodeData.isNodeNavigated = !nodeData.IsLeaf;
                _resetScrollCount( nodeData );
                _sendDLEventForCompanions( nodeData.InstanceId );
                if ( _navigationType === CPM.Enums.NavigationType.Dynamic && !nodeData.IsLeaf ) {
                    _loadData( nodeData, true );
                }
                // If node selected from breadcrumb is available in viewport, then update URL
                for ( i = 0; i < _linearDataArray.length; i++ ) {
                    if ( _linearDataArray[i].Id === _prevNodeSelected.Id ) {
                        _updateURLData( _prevNodeSelected );
                        break;
                    }
                }
            } else {//If full data is not available then request the data from server for the selected node.
                WebCC.Events.fire( 'onExpand', _prevNodeSelected.fullPath );
                _prevNodeSelected.IsExpanded = true;
                _isBCUpdateRequired = true;
                _callback( { name: _prevNodeSelected.fullPath, id: _prevNodeSelected.Id, isRequestData: true, isHierarchyNode: false } );
            }
            _breadCrumb.resetDims();
        },

        //fire from templete on node click
        _setSelected = function ( node, isCallReq, unloadBreadCrumb ) {
            var parentNode, i;
            node.isSelected = true;
            if ( _prevNodeSelected ) {
                for ( i = 0; i < _linearDataArray.length; i++ ) {
                    if ( _prevNodeSelected.fullPath === _linearDataArray[i].fullPath ) {
                        _prevNodeSelected.index = _linearDataArray[i].index;
                        if ( _prevNodeSelected.Id !== node.Id ) {
                            _linearDataArray[i].isSelected = false;
                        }
                        break;
                    }
                }
                if ( _prevNodeSelected.Id !== node.Id ) {
                    _prevNodeSelected.isSelected = false;
                }
                else {
                    if ( !unloadBreadCrumb ) {
                        _unloadBreadCrumb();
                        _breadCrumb.updateNodeImage();
                    }
                    return;
                }
                parentNode = _getNodeData( _prevNodeSelected.ParentId );
                if ( parentNode ) {
                    if ( parentNode.childSelected ) {
                        parentNode.childSelected = false;
                    }
                    if ( !node.IsLeaf && _prevNodeSelected.isNodeNavigated ) {
                        _prevNodeSelected.isNodeNavigated = false;
                    }
                }
                _nodeHandler.setSelectedNode( _prevNodeSelected, _data, _isAlarmsPresent, _horizontalLine );
            }
            _prevNodeSelected = node;
            _prevSelectedCrumbNode = node;
            //update URL Viewport
            _updateURLData( node );
            //update WebCC Properties
            if ( !isCallReq ) {
                _callback( { name: node.fullPath, id: node.Id, isRequestData: false } );
            }
            WebCC.Properties.SelectedNode = node.fullPath;
            _selectedNodePath = node.fullPath;
            _selectedNodeId = node.Id; //setting selectedNode Id
            _prevSelectedBCNodeId = node.Id;
            if ( !unloadBreadCrumb ) {
                _unloadBreadCrumb();
            }
            WebCC.Events.fire( 'onSelectionChanged', node.fullPath );
            _sendDLEventForCompanions( node.InstanceId );
            _data.SelectionBackColor = _selectionBackColUpdated ? _data.SelectionBackColor : _data.stylePropObj.Control.SelectionBackColor;
            _data.SelectionForeColor = _selectionForeColUpdated ? _data.SelectionForeColor : _data.stylePropObj.Control.SelectionForeColor;
            if ( _navigationType === CPM.Enums.NavigationType.Static || node.IsLeaf || _navigatedNodeId !== _selectedNodeId ) {
                parentNode = _getNodeData( node.ParentId );
                if ( parentNode && parentNode.ParentId ) {
                    parentNode.childSelected = true;
                }
                _nodeHandler.setSelectedNode( node, _data, _isAlarmsPresent, _horizontalLine );
            } else {
                if ( _navigationType === CPM.Enums.NavigationType.Dynamic ) {
                    _setBeforeTraverse();
                    _setForUpdate();
                }
            }
            _updateToolbarButtons( node );
        },

        _updateSearchComboBox = function () {
            var attributes;

            if ( _showSearchComboBox ) {
                if ( !_isFilterRectsCreated ) {
                    _createFilterRects();
                }
                else {
                    _updateFilterRects();
                }
                if ( _createFilter && _filterComboBox ) {
                    attributes = _getFilterComboBoxAttributes();
                    _filterComboBox.show();
                    _filterComboBox.update( attributes, _ctrlHeight, true );
                }
                _searchBox.updateTopValue( _toolbarHeight + _urlPartTotalHeight );
            } else {
                _data.SearchComboBoxPart.border.height = _searchComboBoxPartHeight = 0;
                _removeFilterRects();
                if ( _createFilter && _filterComboBox ) {
                    _filterComboBox.hide();
                }
                _searchBox.hide();
            }
        },

        //Method to update the toolbar button state for the current selected node
        _updateToolbarButtons = function ( selectedNode ) {
            if ( _toolbar ) {
                if ( selectedNode.IsFullyExpanded ) { //If the selected node is fully expanded, disable expandAll button and enable collapseAll button.
                    selectedNode.IsFullyExpanded = false;
                    _toolbar.setExpandBtnOpacity( 0.5 );
                    _toolbar.setCollapseBtnOpacity( 1 );
                } else {
                    if ( selectedNode.IsLeaf ) { //If the selected node is a leaf node, disable both the toolbar buttons.
                        _toolbar.setExpandBtnOpacity( 0.5 );
                        _toolbar.setCollapseBtnOpacity( 0.5 );
                    } else if ( !selectedNode.IsExpanded ) { //If the selected node is collapsed, disable collapseAll button and enable expandAll button.
                        _toolbar.setExpandBtnOpacity( 1 );
                        _toolbar.setCollapseBtnOpacity( 0.5 );
                    } else {
                        if ( selectedNode.IsExpanded ) {
                            _toolbar.setCollapseBtnOpacity( 1 ); //If the selected node is expanded( not full expand), enable the collapseAll button.
                            _updateExpandBtnStatus( selectedNode ); //Also, check if any of the child node or their child nodes are collapsed. If any child node is collpased, enable the expandAll button else disable it.
                            if ( _enableExpandBtn ) {
                                _enableExpandBtn = false;
                                _toolbar.setExpandBtnOpacity( 1 );
                            } else {
                                _toolbar.setExpandBtnOpacity( 0.5 );
                            }
                        }
                    }
                }
            }
        },

        //Method to find if any of the child node under the selected node is collapsed or not.
        _updateExpandBtnStatus = function ( selectedNode ) {
            var childCount, i, child;
            if ( selectedNode.Children && !_enableExpandBtn ) {
                childCount = selectedNode.Children.length;
                for ( i = 0; i < childCount; i++ ) {
                    child = selectedNode.Children[i];
                    if ( !child.IsLeaf ) {
                        if ( child.IsExpanded ) {
                            _updateExpandBtnStatus( child );
                        } else {
                            _enableExpandBtn = true;
                            return;
                        }
                    }
                }
            }
        },

        //Method is called when RootNode is Dynamized
        _updateRootNode = function ( value ) {
            var paramIds, paramValues, inValidNode;
            inValidNode = value.includes( '\\' );
            if ( !inValidNode ) {
                _isRootNodePropertyChanged = true;
                paramValues = [CPM.Enums.BrowsingMode.RootNode, value];
                paramIds = [0];
                WebCC.Extensions.HMI.DomainLogic.sendDLEvent( paramIds, paramValues );
            }
        },

        _getValues = function ( obj ) {
            var arr = [];
            //work around for IE as _getValues will not work in IE.
            arr = Object.keys( obj ).map( function ( key ) {
                return obj[key];
            }
            );
            return arr;
        },

        _setFilterText = function ( languageId ) {
            var selectedFilterIndex, key, attributes = {};
            WebCC.Extensions.X_Textbib.setLocale( languageId );
            if ( _createFilter ) {
                for ( key in _options ) {
                    if ( _options[key] === _selectedFilter ) {
                        selectedFilterIndex = key;
                        break;
                    }
                }
                _options['TBID_NONE'] = WebCC.Extensions.X_Textbib.getText( 'TBID_NONE' );
                if ( _alarmComapnion && _alarmComapnion.length > 0 ) {
                    _options['TBID_NODE_PENDINGALARMS'] = WebCC.Extensions.X_Textbib.getText( 'TBID_NODE_PENDINGALARMS' );
                }
                if ( _screenWindowCompanion && _screenWindowCompanion.length > 0 ) {
                    _options['TBID_NODE_VISUALIZATION'] = WebCC.Extensions.X_Textbib.getText( 'TBID_NODE_VISUALIZATION' );
                }

                if ( _filterComboBox ) {
                    _filterComboBox.setOptions( _getValues( _options ) );
                    _selectedFilter = _options[selectedFilterIndex];
                    attributes = _getFilterComboBoxAttributes();//Update the combobox dimensions as per new values.
                    _filterComboBox.update( attributes, _ctrlHeight, false );
                    _filterComboBox.setSelectedOption( _selectedFilter );
                }
            }
        },

        _createTreeComponents = function () {
            _createToolbar();
            _createBCRects();
            if ( !_showBreadCrumb ) {
                _hideBreadcrumbArea();
            }
            if ( _createFilter && _toolbar ) {
                self.filter();
            }
            _createSearchBox();
            _setRootNode();
        },

        _createBCOverlay = function () {
            var top = _toolbarHeight + _urlPartTotalHeight - _data.URLPart.imageIconRect.height / 2 + ( 2 * CPM.Enums.Constants.textBottomPadding );
            _bcOverlaySVG = CPM.svgUtil.createSVG( 'svg', {
                id: 'overlayBreadCrumbSvg',
                width: _data.CtrlWidth,
                height: _data.CtrlHeight - top,
                style: 'position:absolute; left:0px; top:87px;',
                appendTo: _divParent
            } );
            _bcOverlaySVG.style.top = top + 'px';
            CPM.svgUtil.createSVG( 'rect', {
                id: 'overlayBreadCrumbRect',
                width: _data.CtrlWidth,
                height: _data.CtrlHeight - top,
                opacity: 0.3,
                fill: 'rgb(102,102,102)',
                appendTo: _bcOverlaySVG
            } );
        },

        _removeBCOverlay = function () {
            if ( _bcOverlaySVG ) {
                while ( _bcOverlaySVG.firstChild ) {
                    _bcOverlaySVG.removeChild( _bcOverlaySVG.firstChild );
                }
                _bcOverlaySVG.parentElement.removeChild( _bcOverlaySVG );
                _bcOverlaySVG = null;
            }
        };
    /*
    * Function to create the CPM tree control
    * @function
    * @memberOf CPM.App
    * @params{options} control data
    */
    this.createTreeControl = function ( options ) {
        var eventHandlers, desktopLayout = {}, configSelectionBackColor, configSelectionForeColor, styles;
        _svgParent = options.svgParent;
        _data.stylePropObj = CPM.StyleFactory.getCurrentStyleProps( options.currentStyle );
        _data.currentStyle = options.currentStyle;
        _isExtendedStyle = _data.currentStyle.includes( CPM.Enums.StyleName.Extended ) ? true : false;
        _data.URLPart.border.width = options.width - _left - _data.URLPart.border.paddingRight;
        _data.Width = options.width;
        _data.Height = options.height;
        _data.ForeColor = _data.stylePropObj.Control.ForeColor;
        configSelectionBackColor = _toRGBA( options.SelectionBackColor );
        configSelectionForeColor = _toRGBA( options.SelectionForeColor );
        if ( options.SelectionBackColor ) {
            if ( configSelectionBackColor === _toRGBA( _defaultSelectionBackColor ) ) {
                _data.SelectionBackColor = _data.stylePropObj.Control.SelectionBackColor;
            } else {
                _data.SelectionBackColor = configSelectionBackColor;
            }
        } else {
            _data.SelectionBackColor = _data.stylePropObj.Control.SelectionBackColor;
        }
        if ( options.SelectionForeColor ) {
            if ( configSelectionForeColor === _toRGBA( _defaultSelectionForeColor ) ) {
                _data.SelectionForeColor = _data.stylePropObj.Control.SelectionForeColor;
            } else {
                _data.SelectionForeColor = configSelectionForeColor;
            }
        } else {
            _data.SelectionForeColor = _data.stylePropObj.Control.SelectionForeColor;
        }

        _selectedNodePath = options.SelectedNodePath;
        _rootNode = options.RootNode;
        _navigationType = options.NavigationType;
        //new styles added
        _data.white = _data.stylePropObj.Control.EvenBackColor;
        _data.grey3 = _data.stylePropObj.Control.OddBackColor;
        _data.HorizLineColor = _data.stylePropObj.Control.HorizLineColor;
        _data.NodeIconColor = _data.stylePropObj.Control.NodeIconColor;
        _data.SelectionNodeIconColor = _data.stylePropObj.Control.SelectionNodeIconColor;
        _data.ExpCollIconColor = _data.stylePropObj.Control.ExpCollIconColor;
        _data.BaseDir = options.BaseDir || '';
        _cntrlHeightNew = _ctrlHeight = options.height;
        _cntrlWidthNew = options.width;
        _data.CtrlHeight = _ctrlHeight;
        _data.CtrlWidth = options.width;
        _data.rtoId = options.rtoId;
        _data.Enabled = options.Enabled;
        _showToolBar = options.ShowToolBar;
        _showBreadCrumb = options.ShowBreadCrumb;
        _divParent = options.divParent;
        if ( CPM.svgUtil ) {
            CPM.svgUtil.createBBoxItems( options.domParent );
            CPM.svgUtil.setDefaultbBox( _data.Font );
        }
        if ( _showToolBar ) {
            _toolbarHeight = _data.ToolbarPart.border.height = CPM.Enums.Constants.toolbarHeight;
        } else {
            _toolbarHeight = _data.ToolbarPart.border.height = 0;
        }
        if ( _showBreadCrumb ) {
            _urlPartTotalHeight = _data.URLPart.border.height = CPM.Enums.Constants.urlHeight;
        } else {
            _urlPartTotalHeight = _data.URLPart.border.height = 0;
        }
        if ( _showSearchComboBox ) {
            _searchComboBoxPartHeight = _data.SearchComboBoxPart.border.height = CPM.Enums.Constants.searchBackRectHeight;
        } else {
            _searchComboBoxPartHeight = _data.SearchComboBoxPart.border.height = 0;
        }
        _nodeHandler = new CPM.svgNodeHandler( { urlPartTotalHeight: _urlPartTotalHeight, toolbarHeight: _toolbarHeight, searchComboBoxHeight: _searchComboBoxPartHeight } );
        _createBgRects();
        _breadCrumb = new CPM.breadcrumb();
        _toolbar = new CPM.toolbar( _data.currentStyle );
        _comboBoxHandler = new CPM.ComboBoxHandler( _svgParent );
        _searchBox = new CPM.searchBox();
        _treeControlGroup = CPM.svgUtil.createSVG( 'svg', {
            id: 'treeControl',
            appendTo: _svgParent
        } );
        // Create placeholder groups for breadcrumb, toolbar, searchbox and combobox to maintain DOM order
        _toolbarGroup = CPM.svgUtil.createSVG( 'g', {
            id: 'toolbarGroup',
            appendTo: _treeControlGroup
        } );
        _urlGroup = CPM.svgUtil.createSVG( 'g', {
            id: 'urlGroup',
            transform: 'translate(0,0)',
            appendTo: _treeControlGroup
        } );
        _urlGroupMatrix = _urlGroup.transform.baseVal.getItem( 0 ).matrix;
        _scrollbarGrp = CPM.svgUtil.createSVG( 'g', {
            id: 'scrollbarGrp',
            appendTo: _treeControlGroup
        } );
        _searchComboBoxGroup = CPM.svgUtil.createSVG( 'g', {
            id: 'searchComboBoxGroup',
            appendTo: _treeControlGroup
        } );
        _setScreenCompanions();
        if ( !_isFilterRectsCreated ) {
            _createFilterRects();
        }
        if ( _createFilter ) {
            styles = {
                comboBoxStyles: { fill: _isExtendedStyle ? _comboBoxHandler.getGuideStyles( CPM.Enums.ComboGradients.IOFieldNormal ) : _data.stylePropObj.ComboBox.ComboBoxColor },
                normalbuttonStyles: { fill: _isExtendedStyle ? _comboBoxHandler.getGuideStyles( CPM.Enums.ComboGradients.ButtonNormal ) : _data.stylePropObj.ComboBox.NormalbuttonColor },
                pressedbuttonStyles: { fill: _isExtendedStyle ? _comboBoxHandler.getGuideStyles( CPM.Enums.ComboGradients.ButtonPressed ) : _data.stylePropObj.ComboBox.PressedbuttonColor },
            };
            _filterComboBox = new CPM.ComboBox( _id, _callbackOnSelect, undefined, styles, _data.currentStyle );
            _createFilterDropDown();
        }
        _createTreeComponents();
        _setTifLibExpandoProps();
        eventHandlers = self.getEventHandlers();
        _eventManager = new CPM.EventManager( _svgParent, eventHandlers, _divParent );
        _eventManager.addEventListeners();
        desktopLayout.domNode = _divParent;
        CPM.Common.Tooltip.createItems( desktopLayout );
    };

    this.getEventHandlers = function () {
        return {
            handleVScrollBar: _handleVScrollBar,
            handleHScrollBar: _handleHScrollBar,
            unloadBreadCrumb: _unloadBreadCrumb,
            toggleVisibility: self.toggleVisibility,
            getNodeData: _nodeHandler.getNodeData,
            setNavigatedNodeId: _setNavigatedNodeId,
            getParent: _getNodeData,
            handleBCVScrollBar: _handleBCVScrollBar,
            handleCBVScrollBar: _handleCBVScrollBar,
            selectNode: _setSelected,
            sendSummaryInfo: _sendSummaryInfo,
            getBCNode: _breadCrumb.getBCNode,
            displayImmediateChildren: _displayImmediateChildren,
            onURLClick: _onURLClick,
            setBgColor: _breadCrumb.setBgColor,
            getCrumbNode: _breadCrumb.getCrumbNode,
            setSelectedFromBC: _setSelectedFromBC,
            expandAll: self.expandAll,
            collapseAll: self.collapseAll,
            onScroll: _onScroll,
            updateNodeImage: _breadCrumb.updateNodeImage,
            updateToolbarColor: _toolbar.updateToolbarColor,
            filterComboBox: _filterComboBox,
            showToolTip: _showToolTip,
            handleSearchText: _handleSearchText,
            toggleFilterButton: self.toggleFilterButton,
            showClearIcon: _searchBox.showClearIcon,
            hideClearIcon: _searchBox.hideClearIcon,
            clearSearch: _searchOrClearText,
            searchForText: _searchOrClearText,
            showInputTextToolTip: _searchBox.showInputTextToolTip
        };
    };

    /*
     * Function to handle node expand/collapse events
     * @function
     * @memberOf CPM.App
     * @params{node} node to be expanded or collapsed
     * @params{isCollapseAllEvent} indicates whether the function was called for collapseAll event
     */
    this.toggleVisibility = function ( node, isCollapseAllEvent, onDoubleclick ) {
        var isHierarchyNode = false, childCount, i, child;
        _isExpandAll = false;
        _isCollapseAll = false;
        if ( node.IsLeaf ) {
            if ( onDoubleclick ) {
                _navigatedNodeId = node.Id;
                node.isNodeNavigated = true;
                _setSelected( node, true );//_selectedNodeId = node.Id;
            } else {
                _expandedNodeId = node.Id;
            }
            _callback( { name: WebCC.Properties.SelectedNode, id: node.Id, isRequestData: false } );
            return;
        }
        else {
            if ( node.IsExpanded ) {
                if ( !isCollapseAllEvent ) {
                    WebCC.Events.fire( 'onCollapse', node.fullPath );
                }
                if ( node.Children ) {
                    _count = 0;
                    childCount = node.Children.length;
                    for ( i = 0; i < childCount; i++ ) {
                        child = node.Children[i];
                        if ( isCollapseAllEvent ) {
                            child.IsExpanded = false;
                        }
                        child.Visible = false;
                    }
                    _deepestNodeWidth = 0;
                    _deepestNode = 0;
                }
                node.IsExpanded = !node.IsExpanded;
                _expandedNodeId = null;
                _tbUpdateRequired = true;
                _setBeforeTraverse();
                _setForUpdate();
                _scrollCount = _nodeHandler.getScrollIndex();//Fix for the issue when the scrollbar handler is not adjusted properly on last node's expand/collapse operation.
                if ( !isCollapseAllEvent && onDoubleclick ) {
                    _navigatedNodeId = node.Id;
                    node.isNodeNavigated = true;
                    _setSelected( node, true );//_selectedNodeId = node.Id;
                }
            }
            else {
                /*** FIXME: If hierarchies > 2 are present, send additional flag in node with sibling information and set isHierarchyNode as true ***/
                //if ( _data.NodePart[0] && node.Id === _data.NodePart[0].Id ) {
                //    isHierarchyNode = true;
                //}
                _isNodeUpdated = true;
                WebCC.Events.fire( 'onExpand', node.fullPath );
                node.IsExpanded = !node.IsExpanded;
                if ( onDoubleclick ) {
                    _navigatedNodeId = node.Id;
                    node.isNodeNavigated = true;
                    _setSelected( node, true ); //_selectedNodeId = node.Id;
                } else {
                    _expandedNodeId = node.Id;
                }
                _tbUpdateRequired = true;
                if ( node.Children ) {
                    childCount = node.Children.length;
                    for ( i = 0; i < childCount; i++ ) {
                        child = node.Children[i];
                        child.Visible = true;
                    }
                    _setBeforeTraverse();
                    _setForUpdate();
                } else {
                    _callback( { name: WebCC.Properties.SelectedNode, id: node.Id, isRequestData: true, isHierarchyNode: isHierarchyNode } );
                }
            }
            _updateParentDims();
        }
    };

    /*
    * Function to handle window resize event of cpm tree control
    * @function
    * @memberOf CPM.App
    * @params{height} height of the control
    * @params{width} width of the control
    */
    this.updateView = function ( height, width ) {
        var treeViewPortHeight = 0, attributes = {};
        _data.URLPart.border.width = width - _data.Left - _data.URLPart.border.paddingRight;
        _ctrlHeight = height;
        _cntrlWidthNew = width;
        _svgParent.setAttribute( 'width', ( _cntrlWidthNew + 'px' ) );
        _data.Width = _cntrlWidthNew;
        _data.stylePropObj = CPM.StyleFactory.getCurrentStyleProps( _data.currentStyle );
        treeViewPortHeight = _urlPartTotalHeight + ( ( _count ) * _getNodeDomHeight() );
        if ( height > _cntrlHeightNew || treeViewPortHeight < _cntrlHeightNew ) {
            _cntrlHeightNew = height;
            _svgParent.setAttribute( 'height', _cntrlHeightNew + 'px' );
            _data.Height = _cntrlHeightNew;
        }
        if ( treeViewPortHeight > height ) {
            _cntrlHeightNew = treeViewPortHeight;
            _svgParent.setAttribute( 'height', _cntrlHeightNew + 'px' );
            _data.Height = _cntrlHeightNew;
        }
        _data.CtrlHeight = _ctrlHeight;
        _data.CtrlWidth = _cntrlWidthNew;
        if ( _toolbar ) {
            _toolbar.updateWidth( _data.CtrlWidth );
        }
        if ( _showBreadCrumb && _breadCrumb ) {
            _breadCrumb.remove();
            _createBCRects();
            if ( _data.URLPart.data.length > 0 ) {
                _updateURLData( _getNodeDataByPath( _selectedNodePath) );
            }
        }
        if ( _showSearchComboBox ) {
            if ( !_isFilterRectsCreated ) {
                _createFilterRects();
            }
            else {
                _updateFilterRects();
            }
        }
        if ( _showSearchComboBox && _createFilter && _filterComboBox ) {
            attributes = _getFilterComboBoxAttributes();
            _filterComboBox.show();
            _filterComboBox.update( attributes, _ctrlHeight, true );
        }
        if ( _createFilter && _data.CtrlWidth < ( ( 2 * CPM.Enums.Constants.searchComboBoxMinWidth ) + ( 3 * CPM.Enums.Constants.searchComboBoxPadding ) ) ) {
            _moveBelow = true;
        } else {
            _moveBelow = false;
        }
        _searchBox.updateWidth( _data.CtrlWidth, _moveBelow );
        _updateBgRects();
        if ( _isAlarmsPresent ) {
            _removeAlarmBgRects();
            _createAlarmBgRects();
        }
        _setForUpdate();
        _scrollCount = _nodeHandler.getScrollIndex();
        //Updating the scrollbars after updating the tree in case the scroll count is changed while updating the tree.
        _createVerticalScrollBar();
        _createHorizontalScrollBar();
    };

    /*
    * Function to handle expandAll toolbar event
    * @function
    * @memberOf CPM.App
    */
    this.expandAll = function () {
        var
            selectedNode,
            paramIds = [0, 1],
            paramValues = [];
        if ( !_toolbar.isExpandAllEnabled() ) {//Do not do ExpandAll if the button is disabled.
            return;
        }
        if ( !_data.NodePart[0] ) {
            return;//Do not do ExpandAll if no data is available.
        }
        if ( _selectedNodeId && _selectedNodeId !== _data.NodePart[0].Id ) {
            selectedNode = _getNodeData( _selectedNodeId );
            paramValues = [CPM.Enums.BrowsingMode.ExpandNode, _selectedNodeId];
        } else {
            selectedNode = _data.NodePart[0];
            if ( _rootNode !== '' ) {
                paramValues = [CPM.Enums.BrowsingMode.ExpandAll, _data.NodePart[0].Id];//To expand only configured rootnode hierarchy
            } else {
                paramValues = [CPM.Enums.BrowsingMode.ExpandNode, ''];
            }
        }
        if ( selectedNode.IsLeaf ) {
            return;//Do not do ExpandAll if a leaf node is selected.
        }
        if ( !_isExpandAll ) {//if not already expanded
            _isExpandAll = true;
            _isCollapseAll = false;
            _isNodeUpdated = true;
            WebCC.Events.fire( 'onExpandAll', _isExpandAll );
            selectedNode.IsFullyExpanded = true;
            if ( !_isExtendedStyle ) {
                _toolbar.setExpandBtnLine( _isExpandAll );
                _toolbar.setCollapseBtnLine( _isCollapseAll );
            }
            if ( _prevNodeSelected ) {
                _tbUpdateRequired = true;
            } else {
                _updateToolbarButtons( selectedNode );
            }

            if ( _isFullDataPresent ) {
                if ( selectedNode.Id !== _data.NodePart[0].Id ) {
                    _expandAllChildren( selectedNode );
                    _isExpandAll = false;
                }
                _setBeforeTraverse();
                if ( !_isNodeInViewport( selectedNode.index ) ) {
                    _resetScrollCount( selectedNode );//If the selected node is outside the VP, reset the scroll index.
                }
                _createVerticalScrollBar();
                _setForUpdate();
                _createHorizontalScrollBar();
            } else {
                selectedNode.Children = [];
                if ( selectedNode.Id === _data.NodePart[0].Id ) {
                    _resetTree();
                    _isFullDataPresent = true;
                }
                WebCC.Extensions.HMI.DomainLogic.sendDLEvent( paramIds, paramValues );
            }
        }
    };

    /*
    * Function to handle collapseAll toolbar event
    * @function
    * @memberOf CPM.App
    */
    this.collapseAll = function () {
        var
            selectedNode;
        if ( !_toolbar.isCollapseAllEnabled() ) {//Do not do CollapseAll if the button is disabled.
            return;
        }
        if ( !_data.NodePart[0] ) {
            return;//Do not do CollapseAll if no data is available.
        }
        if ( _selectedNodeId ) {
            selectedNode = _getNodeData( _selectedNodeId );
        } else {
            selectedNode = _data.NodePart[0];
        }
        if ( selectedNode.IsLeaf ) {
            return;//Do not do CollapseAll if a leaf node is selected.
        }
        if ( !_isCollapseAll ) {
            _isCollapseAll = true;
            _isExpandAll = false;
            WebCC.Events.fire( 'onCollapseAll', _isCollapseAll );
            selectedNode.IsFullyExpanded = false;
            if ( !_isExtendedStyle ) {
                _toolbar.setExpandBtnLine( _isExpandAll );
                _toolbar.setCollapseBtnLine( _isCollapseAll );
            }
            if ( selectedNode.IsExpanded ) {
                this.toggleVisibility( selectedNode, true );
                if ( !_isNodeInViewport( selectedNode.index ) ) {
                    _resetScrollCount( selectedNode );//If the selected node is outside the VP, reset the scroll index.
                }
            } else {
                _isCollapseAll = false;
            }
            if ( !_prevNodeSelected || ( _prevNodeSelected && _selectedFilter !== _options['TBID_NONE'] ) ) { //Enable expandAll button if _prevNodeSelected is not available in the changed filter view (!'None') and collapseAll button is pressed                 
                _updateToolbarButtons( selectedNode );
            }
        }
    };
    this.toggleFilterButton = function () {
        var attributes;
        if ( !_showSearchComboBox && !_isFilterRectsCreated ) {
            _showSearchComboBox = true;
            _data.SearchComboBoxPart.border.height = _searchComboBoxPartHeight = CPM.Enums.Constants.searchBackRectHeight;
            _createFilterRects();
            if ( _createFilter && _filterComboBox ) {
                attributes = _getFilterComboBoxAttributes();
                _filterComboBox.show();
                _filterComboBox.update( attributes, _ctrlHeight, true );
            }
            _searchBox.show();
            _searchBox.updateTopValue( _toolbarHeight + _urlPartTotalHeight );
        } else {
            _showSearchComboBox = false;
            _data.SearchComboBoxPart.border.height = _searchComboBoxPartHeight = 0;
            _removeFilterRects();
            if ( _createFilter && _filterComboBox ) {
                _filterComboBox.hide();
            }
            _searchBox.hide();
        }
        if ( !_isExtendedStyle ) {
            _toolbar.setFilterBtnLine( _showSearchComboBox );
        }
        _updateBgRects();
        if ( _isAlarmsPresent ) {
            _removeAlarmBgRects();
            _createAlarmBgRects();
        }
        _setForUpdate();
    };
    /*
    * Function to handle Filter toolbar event
    * @function 
    * @memberOf CPM.App
    */
    this.filter = function () {
        var selectedNode, navigatedNodePath;
        if ( _selectedFilter === _options['TBID_NODE_PENDINGALARMS'] ) {
            if ( !_data.NodePart[0] ) {
                return;
            }
            if ( _selectedNodeId ) {
                selectedNode = _getNodeData( _selectedNodeId );
                selectedNode.isSelected = false;
                _nodeHandler.setSelectedNode( selectedNode, _data, _isAlarmsPresent, _horizontalLine );
                selectedNode.isSelected = true;
            }
            if ( ( Object.keys( _alarmData ).length === 0 ) || Object.keys( _alarmData.ActiveAlarms ).length === 0 ) {
                _data.URLPart.data = [];
                _data.URLPart.viewportData = [];
                _createBCRects();
                _count = 0;
                _linearDataArray = [];
                if ( _toolbar ) {
                    _toolbar.setExpandBtnOpacity( 0.5 );
                    _toolbar.setCollapseBtnOpacity( 0.5 );
                }
            } else {
                if ( _navigationType === CPM.Enums.NavigationType.Dynamic ) {
                    if ( _navigatedNodeId ) {
                        navigatedNodePath = _getNodeData( _navigatedNodeId ).fullPath;
                        if ( Object.keys( _alarmData.ActiveAlarms ).indexOf( navigatedNodePath ) !== -1 ) {
                            _setBeforeTraverse();
                        } else {
                            _linearDataArray = [];
                        }
                    } else {
                        _setBeforeTraverse();
                    }
                } else {
                    _setBeforeTraverse();
                }
                if ( _toolbar ) {
                    _toolbar.setExpandBtnOpacity( 1 );
                    _toolbar.setCollapseBtnOpacity( 1 );
                }
                if ( selectedNode ) {
                    if ( Object.keys( _alarmData.ActiveAlarms ).indexOf( selectedNode.fullPath ) === -1 ) {
                        _createBCRects();
                    } else {
                        _updateURLData( selectedNode );
                    }
                }
            }
            _createVerticalScrollBar();
            _setForUpdate();
            _createHorizontalScrollBar();
        }
        else if ( _selectedFilter === _options['TBID_NODE_VISUALIZATION'] ) {
            if ( Object.keys( _screenData ).length > 0 ) {
                self.handleScreenData();
            }
            else {
                //clearing the tree before requesting for screen window data
                _data.URLPart.data = [];
                _data.URLPart.viewportData = [];
                _createBCRects();
                _count = 0;
                _linearDataArray = [];
                if ( _toolbar ) {
                    _toolbar.setExpandBtnOpacity( 0.5 );
                    _toolbar.setCollapseBtnOpacity( 0.5 );
                }
                _setForUpdate();
                _createVerticalScrollBar();
                _createHorizontalScrollBar();
                WebCC.Extensions.HMI.DomainLogic.sendDLEvent( [], [CPM.Enums.BrowsingMode.ScreenFilter] );
            }
        }
        else {
            if ( _data.NodePart[0] ) {
                if ( _selectedNodeId ) {
                    selectedNode = _getNodeData( _selectedNodeId );
                    _updateURLData( selectedNode );
                    if ( _toolbar ) {
                        _toolbar.setExpandBtnOpacity( 1 );
                        _toolbar.setCollapseBtnOpacity( 1 );
                    }
                }
                _setBeforeTraverse();
                _setForUpdate();
            }
        }
    };

    /*
    * Function to create new node in the tree
    * @function
    * @memberOf CPM.App
    * @params{node} node to be added to the tree
    */
    this.createNewNode = function ( node ) {
        var parentNode;
        if ( node.Parent === _data.NodePart[0].Name ) {
            parentNode = _data.NodePart[0];
        }
        else {
            parentNode = _searchForNode( _data.NodePart[0], node.Parent, _operation.add );
        }
        if ( parentNode ) {
            if ( parentNode.Children ) {
                parentNode.Children.push( node );
            }
            else {
                parentNode.Children = [];
                parentNode.Children.push( node );
            }
        }
        _count = 0;
        _deepestNodeWidth = 0;
        _deepestNode = 0;
        _traverse( _data.NodePart[0] );

    };

    /*
    * Function to load intial tree nodes whenever received from server
    * @function
    * @memberOf CPM.App
    * @params{rawData} data of the intial nodes to be displayed.
    */
    this.createHierarchyNode = function ( data ) {
        var node = _getDefaultNode();
        node.Name = data.Name;
        node.Id = data.Id;
        node.Children = data.Children;
        _data.NodePart.push( node );
        _count = 0;
        _deepestNodeWidth = 0;
        _deepestNode = 0;
        _updateParentDims();
    };

    /*
    * Function to load intial tree nodes whenever received from server
    * @function
    * @memberOf CPM.App
    * @params{rawData} data of the intial nodes to be displayed.
    */
    this.loadNodes = function ( rawData, errorVal ) {
        var i = 0,
            selectedNode,
            wholePlantNodes,
            parentNode, node, paramIds, paramValues;

        if ( errorVal !== 0 && errorVal !== undefined ) {
            _isRootNodePropertyChanged = false;
            return;
        }

        if ( _isSearchPending ) {
            _isFullDataPresent = true;
            _count = 0;
            _deepestIdx = 1;
            wholePlantNodes = _traverseRawdata( rawData[0] );
            _mergeNodeProps( wholePlantNodes, _data.NodePart[0] );
            _data.NodePart[0] = wholePlantNodes;

            _handleSearchText();
            return;
        }
        if ( !_nodeHeight ) {
            _getNodeDomHeight();
        }

        for ( i = 0; i < rawData.length; i++ ) {
            if ( _expandedNodeId ) {
                parentNode = _getNodeData( _expandedNodeId );
                if ( !parentNode.Children ) {
                    parentNode.Children = [];
                }
                parentNode.Children.push( _traverseRawdata( rawData[i], parentNode ) );
            }
            else if ( _selectedNodeId && !_isRootNodePropertyChanged && _isNodeUpdated ) {
                parentNode = _getNodeData( _selectedNodeId );
                if ( !parentNode.Children ) {
                    parentNode.Children = [];
                }
                parentNode.Children.push( _traverseRawdata( rawData[i], parentNode ) );
            }
            else {
                if ( _isRootNodePropertyChanged ) {
                    _resetTree();
                    _rootNode = WebCC.Properties.RootNode;
                    _data.URLPart.data = [];
                    _data.URLPart.viewportData = [];
                    _createBCRects();
                    _navigatedNodeId = null;
                    _isNodeUpdated = true;
                    _isRootNodePropertyChanged = false;
                }
                _data.NodePart[0] = _traverseRawdata( rawData[i] );
                if ( _searchText && _isNodeUpdated ) {
                    node = _getNodeDataByPath( _rootNode );
                    paramIds = [0, 1];
                    if ( node ) {
                        paramValues = [CPM.Enums.BrowsingMode.ExpandAll, node.Id];
                    } else {
                        paramValues = [CPM.Enums.BrowsingMode.ExpandAll, ''];
                    }
                    _isNodeUpdated = false;
                    WebCC.Extensions.HMI.DomainLogic.sendDLEvent( paramIds, paramValues );
                }
            }
        }
        if ( _expandedNodeId ) {
            _expandedNodeId = null;
        }
        if ( _isExpandAll && _selectedNodeId && _selectedNodeId !== _data.NodePart[0].Id ) {
            selectedNode = _getNodeData( _selectedNodeId );
            selectedNode.IsExpanded = true;//Since we add only child nodes in this case, we have to set the already available selected node 'expanded'.
            _isExpandAll = false;
        }

        _tbUpdateRequired = true;
        _markNodesHavingSearchText();
        _setBeforeTraverse();
        _setForUpdate();
        if ( _isBCSelectionRequest ) {
            _updateURLData( parentNode );
            _isBCSelectionRequest = false;
        }
        if ( selectedNode && !_isNodeInViewport( selectedNode.index ) ) {
            _resetScrollCount( selectedNode );//If the selected node is outside the VP, reset the scroll index.
        }
        _updateParentDims();
        //Breadcrumb update required for scenario when the node selected from breadcrumb is not available with client but received from server in this function.
        if ( _isBCUpdateRequired ) {
            selectedNode = _getNodeData( _prevSelectedBCNodeId );
            selectedNode.isSelected = true;
            _prevNodeSelected.isSelected = false;
            _prevNodeSelected = selectedNode;
            _updateToolbarButtons( _prevNodeSelected );
            _updateURLData( selectedNode );
            WebCC.Properties.SelectedNode = selectedNode.fullPath;
            WebCC.Events.fire( 'onSelectionChanged', selectedNode.fullPath );
            _selectedNodeId = selectedNode.Id;
            if ( _navigationType === CPM.Enums.NavigationType.Dynamic && !selectedNode.IsLeaf ) {
                _setBeforeTraverse();
                _setForUpdate();
            }
            _resetScrollCount( selectedNode );
            _isBCUpdateRequired = false;
        }
        _sendSummaryInfo();
        _addTifLibExpandoProps();
        if ( Object.keys( _screenData ).length === 0 && _selectedFilter && ( Object.keys( _options ).length > 0 && _selectedFilter === _options['TBID_NODE_VISUALIZATION'] ) ) { //Request explicitly to DL for the visualization data if the filter is configured as visualization
            self.filter();
        }
    };

    /*
    * Function to add new nodes to the existing tree nodes
    * @function
    * @memberOf CPM.App
    * @params{data} data of the new nodes to be added.
    * @params{isBufferData} Indicates if the data is to be stored in a buffer array or not.
    */
    this.addNewNodes = function ( data, isBufferData ) {
        var parentId = data.ParentId, parentNode, nodeData, formattedData;
        if ( isBufferData ) {
            _bufferDataArray.push( data );
            if ( !data.MoreFollows ) {
                for ( var i = 0; i < _bufferDataArray.length; i++ ) {
                    parentNode = _getNodeData( parentId );
                    if ( !parentNode.Children ) {
                        parentNode.Children = [];
                    }
                    nodeData = _bufferDataArray[i].DisplayData[0];
                    nodeData.ParentId = parentId;
                    nodeData.Parent = parentNode;
                    nodeData.depth = parentNode.depth + 1;
                    formattedData = _traverseRawdata( nodeData, parentNode );
                    parentNode.Children.push( formattedData );

                }
                _markNodesHavingSearchText();
                _setBeforeTraverse();
                _createVerticalScrollBar();
                _nodeHandler.resetDataArray( _linearDataArray );
                _setForUpdate();
            }
        }
        else {
            if ( parentId ) {
                parentNode = _getNodeData( parentId );
                if ( !parentNode.Children ) {
                    parentNode.Children = [];
                }
                nodeData = data.DisplayData[0];
                nodeData.ParentId = parentId;
                nodeData.Parent = parentNode;
                nodeData.depth = parentNode.depth + 1;
                formattedData = _traverseRawdata( nodeData, parentNode );
                parentNode.Children.push( formattedData );
                _markNodesHavingSearchText();
                _setBeforeTraverse();
                _setForUpdate();
            }
        }
    };

    /*
    * Function to remove a node from the tree
    * @function
    * @memberOf CPM.App
    * @params{nodeName} name of the node to be removed.
    */
    this.removeNode = function ( nodeName ) {
        _searchForNode( _data.NodePart[0], nodeName, _operation.remove );
        _count = 0;
        _deepestNode = 0;
        _deepestNodeWidth = 0;
        _traverse( _data.NodePart[0] );
    };

    /*
    * Function to set the callback function.
    * @function
    * @memberOf CPM.App
    * @params{func} callback function name
    */
    this.setCallback = function ( func ) {
        _callback = func;
    };

    /*
    * Function to load the breadcrumb for the given node.
    * @function
    * @memberOf CPM.App
    * @params{data} selected node data
    */
    this.loadBreadCrumb = function ( data ) {
        var i = 0, crumbNode, maxNodeNameWidth = 0, cNodeNameWidth, crumbData = {},
            // extraPaddingGap = 48,
            length;
        _nodeDomHeight = _getNodeDomHeight();
        //holds children nodes of breadcrumb for a parent node
        _crumbChildren = [];
        //TODO: recheck if condition for expandable and non expandable node
        if ( data ) {
            length = data.length;
            if ( length !== 0 ) {
                for ( i = 0; i < length; i++ ) {
                    crumbNode = _getDefaultNode();
                    crumbNode.fullPath = data[i][2];
                    if ( _selectedFilter && _selectedFilter !== _options['TBID_NONE'] ) {
                        if ( _selectedFilter === _options['TBID_NODE_PENDINGALARMS'] && _alarmData && ( Object.keys( _alarmData.ActiveAlarms ).length > 0 || Object.keys( _alarmData.RemovedAlarms ).length > 0 ) && !( Object.keys( _alarmData.ActiveAlarms ).indexOf( crumbNode.fullPath ) !== -1 || Object.keys( _alarmData.RemovedAlarms ).indexOf( crumbNode.fullPath ) !== -1 ) ) {
                            continue;
                        }
                        else {
                            if ( _selectedFilter === _options['TBID_NODE_VISUALIZATION'] && _screenData && Object.keys( _screenData.ScreenFilter ).length > 0 && ( Object.keys( _screenData.ScreenFilter ).indexOf( crumbNode.fullPath ) === -1 ) ) {
                                continue;
                            }
                        }
                    }
                    crumbNode.Name = data[i][0];
                    crumbNode.Id = data[i][1];

                    crumbNode.bBox = _getTextBBox( crumbNode.Name );
                    crumbNode.isSelected = false;
                    if ( _prevSelectedBCNodeId && _prevSelectedBCNodeId === crumbNode.Id ) {
                        crumbNode.isSelected = true;
                        _prevSelectedCrumbNode = crumbNode;
                        _prevSelectedBCNodeId = crumbNode.Id;
                    }
                    _crumbNodeNameHeight = _getTextBBox( crumbNode.Name ).height;
                    cNodeNameWidth = _getTextBBox( crumbNode.Name ).width;
                    if ( maxNodeNameWidth < cNodeNameWidth ) {
                        maxNodeNameWidth = cNodeNameWidth;
                    }
                    _crumbNodeNameWidth = maxNodeNameWidth;
                    _crumbChildren.push( crumbNode );
                }
                if ( ( _ctrlHeight - _nodeDomHeight - _toolbarHeight ) < ( _crumbChildren.length * _nodeDomHeight ) ) {
                    if ( _isHorizontalScrollbarCreated ) {
                        _crumbHeight = _ctrlHeight - _toolbarHeight - CPM.Enums.Constants.urlHeight - _hScrollbarHeight;
                    } else {
                        _crumbHeight = _ctrlHeight - _toolbarHeight - CPM.Enums.Constants.urlHeight;
                    }
                } else {
                    _crumbHeight = _crumbChildren.length * _nodeDomHeight;
                }

                crumbData.crumbX = _crumbX;
                crumbData.crumbNodeNameWidth = _crumbNodeNameWidth;
                crumbData.crumbHeight = _crumbHeight;
                crumbData.white = _data.white;
                crumbData.grey3 = _data.grey3;
                crumbData.foreColor = _data.ForeColor;
                crumbData.crumbNodeNameHeight = _crumbNodeNameHeight;
                crumbData.SelectionForeColor = _data.SelectionForeColor;
                crumbData.SelectionNodeIconColor = _data.SelectionNodeIconColor;
                crumbData.active = _data.SelectionBackColor;
                crumbData.divParent = _divParent;
                if ( _crumbChildren.length > 0 ) {
                    _createBCOverlay();
                }
                _bcParentGrp = _breadCrumb.createBreadCrumb( _crumbChildren, crumbData, _toolbarHeight, _data.URLPart.imageIconRect.height );

                _breadcrumbGroup = document.getElementById( 'breadcrumbGroup' );
                _breadcrumbGroupMatrix = _breadcrumbGroup.transform.baseVal.getItem( 0 ).matrix;
                // Creating breadcrumb scrollbar after creation of breadcrumb children nodes in the DOM
                if ( ( _ctrlHeight - _nodeDomHeight - _toolbarHeight ) < ( _crumbChildren.length * _nodeDomHeight ) ) {
                    _createBCVerticalScrollBar();
                }
            }
        }
    };

    /*
    * Function to handle alarm summary data
    * @function
    * @memberOf CPM.App
    * @params{data} alarm summary data
    */
    this.handleAlarmData = function ( data ) {
        var selectedNode;
        if ( ( data.ActiveAlarms && data.ActiveAlarms !== null ) || ( data.RemovedAlarms && data.RemovedAlarms !== null ) ) {
            _alarmData = data;
            if ( _selectedFilter === _options.TBID_NODE_PENDINGALARMS ) {
                if ( Object.keys( data.ActiveAlarms ).length === 0 ) {
                    _resetTree();
                    _data.URLPart.data = [];
                    _data.URLPart.viewportData = [];
                    _createBCRects();
                    _count = 0;
                    _linearDataArray = [];
                    if ( _toolbar ) {
                        _toolbar.setExpandBtnOpacity( 0.5 );
                        _toolbar.setCollapseBtnOpacity( 0.5 );
                    }
                    _isAlarmsPresent = false;
                    _removeAlarmBgRects();
                } else {
                    if ( Object.keys( data.RemovedAlarms ).length > 0 && _navigationType === CPM.Enums.NavigationType.Static && _selectedNodeId ) {
                        selectedNode = _getNodeData( _selectedNodeId );
                        if ( data.RemovedAlarms[selectedNode.fullPath] === 0 ) {
                            selectedNode.isSelected = false;
                            _nodeHandler.setSelectedNode( selectedNode, _data, _isAlarmsPresent, _horizontalLine );
                            _selectedNodeId = undefined;
                        }
                    }
                    _setBeforeTraverse();
                    if ( _toolbar ) {
                        _toolbar.setExpandBtnOpacity( 1 );
                        _toolbar.setCollapseBtnOpacity( 1 );
                    }
                    _isAlarmsPresent = true;
                    _removeAlarmBgRects();
                    _createAlarmBgRects();
                }
                _setForUpdate( data );
            } else {
                if ( _alarmData.ActiveAlarms && Object.keys( _alarmData.ActiveAlarms ).length === 0 ) {
                    _isAlarmsPresent = false;
                    _removeAlarmBgRects();
                } else {
                    _isAlarmsPresent = true;
                    _removeAlarmBgRects();
                    _createAlarmBgRects();
                }
                _createHorizontalScrollBar();
                _setHorizontalLineVal();
                _data.SelectionBackColor = _selectionBackColUpdated ? _data.SelectionBackColor : _data.stylePropObj.Control.SelectionBackColor;
                _data.SelectionForeColor = _selectionForeColUpdated ? _data.SelectionForeColor : _data.stylePropObj.Control.SelectionForeColor;
                _nodeHandler.updateAlarmSummary( _alarmData, _data, _isScrollbarCreated, _isAlarmsPresent, _horizontalLine ); // Called on screen load if alarm is raised
            }
        } else {
            _isAlarmsPresent = false;
        }
    };

    /*
    * Function to handle screen window data
    * @function
    * @memberOf CPM.App
    * @params{data} screen window data
    */
    this.handleScreenData = function ( data ) {
        var selectedNode, navigatedNodePath;
        if ( data && data.ScreenFilter !== null ) {
            _screenData = data;
        }
        if ( _selectedFilter !== _options['TBID_NONE'] ) {
            if ( Object.keys( _screenData.ScreenFilter ).length === 0 ) {
                if ( _selectedNodeId ) {
                    selectedNode = _getNodeData( _selectedNodeId );
                    selectedNode.isSelected = false;
                    _nodeHandler.setSelectedNode( selectedNode, _data, _isAlarmsPresent, _horizontalLine );
                    selectedNode.isSelected = true;
                }
                _data.URLPart.data = [];
                _data.URLPart.viewportData = [];
                _createBCRects();
                _count = 0;
                _linearDataArray = [];
                if ( _toolbar ) {
                    _toolbar.setExpandBtnOpacity( 0.5 );
                    _toolbar.setCollapseBtnOpacity( 0.5 );
                }
            } else {
                if ( _toolbar ) {
                    _toolbar.setExpandBtnOpacity( 1 );
                    _toolbar.setCollapseBtnOpacity( 1 );
                }
                if ( _selectedNodeId ) {
                    selectedNode = _getNodeData( _selectedNodeId );
                }
                if ( _navigationType === CPM.Enums.NavigationType.Static ) {
                    if ( selectedNode && Object.keys( _screenData.ScreenFilter ).indexOf( selectedNode.fullPath ) !== -1 ) {
                        selectedNode.isSelected = false;
                        _nodeHandler.setSelectedNode( selectedNode, _data, _isAlarmsPresent, _horizontalLine );
                        selectedNode.isSelected = true;
                    }
                    _setBeforeTraverse();
                } else {
                    if ( _navigatedNodeId ) {
                        navigatedNodePath = _getNodeData( _navigatedNodeId ).fullPath;
                        if ( Object.keys( _screenData.ScreenFilter ).indexOf( navigatedNodePath ) !== -1 ) {
                            _setBeforeTraverse();
                        } else {
                            _linearDataArray = [];
                        }
                    } else {
                        _setBeforeTraverse();
                    }
                }
                if ( selectedNode ) {
                    if ( Object.keys( _screenData.ScreenFilter ).indexOf( selectedNode.fullPath ) === -1 ) {
                        _createBCRects();
                    } else {
                        _updateURLData( selectedNode );
                    }
                }
            }
            _setForUpdate();
            _createVerticalScrollBar();
            _createHorizontalScrollBar();
        }
    };

    /*
    * Function to handle runtime language change event
    * @function
    * @memberOf CPM.App
    * @params{data} language id
    */
    this.handleLanguageChange = function ( languageId ) {
        if ( navigator.userAgent.indexOf( 'Firefox' ) !== -1 ) {
            setTimeout( function () {
                _setFilterText( languageId );
            }, 0 );
        } else {
            _setFilterText( languageId );
        }
    };

    /*
    * Function to disable the toolbar buttons
    * @function
    * @memberOf CPM.App
    */
    this.disableToolbarButtons = function () {
        if ( _toolbar ) {
            _toolbar.setExpandBtnOpacity( 0.5 );
            _toolbar.setCollapseBtnOpacity( 0.5 );
        }
    };
    /*
    * Function to update the CPM control properties
    * @function
    * @memberOf CPM.App
    * @params{data} holds the property name and its value
    */
    this.updateProperties = function ( data ) {
        var node, paramValues, paramIds;
        switch ( data.key ) {
            case 'RootNode':
                if ( data.value !== '' ) {
                    _updateRootNode( data.value );
                }
                else {
                    _rootNode = '';
                    _isRootNodePropertyChanged = true;
                    paramValues = [CPM.Enums.BrowsingMode.Hierarchies];
                    paramIds = [0];
                    WebCC.Extensions.HMI.DomainLogic.sendDLEvent( paramIds, paramValues );
                }
                break;
            case 'SelectedNode':
                _selectedNodePath = data.value;
                node = _getNodeDataByPath( _selectedNodePath );
                if ( node ) {
                    if ( _prevNodeSelected && _prevNodeSelected.fullPath === _selectedNodePath ) {
                        return;
                    }
                    _setSelected( node, false );
                    _resetScrollCount( node );
                }
                break;
            case 'SelectionBackColor':
                if ( data.value !== 0 && _toRGBA( data.value ) !== _toRGBA( _defaultSelectionBackColor ) ) {
                    _data.SelectionBackColor = data.value ? _toRGBA( data.value ) : _data.SelectionBackColor;
                    _selectionBackColUpdated = true;
                    _nodeHandler.updateSelectionBackColor( _data.SelectionBackColor );
                }
                break;
            case 'SelectionForeColor':
                if ( data.value !== 0 && _toRGBA( data.value ) !== _toRGBA( _defaultSelectionForeColor ) ) {
                    _data.SelectionForeColor = data.value ? _toRGBA( data.value ) : _data.SelectionForeColor;
                    _selectionForeColUpdated = true;
                    _nodeHandler.updateSelectionForeColor( _data.SelectionForeColor );
                }
                break;
            case 'Enabled':
                _data.Enabled = data.value;
                if ( _toolbar ) {
                    if ( _data.Enabled ) {
                        _toolbar.setExpandBtnOpacity( 1 );
                        _toolbar.setCollapseBtnOpacity( 1 );
                    } else {
                        _toolbar.setExpandBtnOpacity( 0.5 );
                        _toolbar.setCollapseBtnOpacity( 0.5 );
                    }
                }
                break;
            case 'Filter':
                if ( _createFilter ) {
                    switch ( data.value ) {
                        case CPM.Enums.Filter.NodeWithPendingAlarms:
                            WebCC.Properties.Filter = data.value;
                            _selectedFilter = _options['TBID_NODE_PENDINGALARMS'];
                            break;
                        case CPM.Enums.Filter.NodeWithVisualization:
                            WebCC.Properties.Filter = data.value;
                            _selectedFilter = _options['TBID_NODE_VISUALIZATION'];
                            break;
                        case CPM.Enums.Filter.None:
                            WebCC.Properties.Filter = data.value;
                            _selectedFilter = _options['TBID_NONE'];
                            break;
                        default:
                            break;
                    }
                    _validateFilterCombination();
                    if ( _filterComboBox ) {
                        _filterComboBox.setSelectedOption( _selectedFilter );
                    }
                    self.filter();
                }
                break;
            case 'ShowToolBar':
                _showToolBar = data.value;
                if ( _showToolBar ) {
                    _showToolbarArea();
                } else {
                    _hideToolbarArea();
                }
                _updateTreeComponents();
                break;
            case 'ShowBreadCrumb':
                _showBreadCrumb = data.value;
                if ( _showBreadCrumb ) {
                    _showBreadcrumbArea();
                } else {
                    _hideBreadcrumbArea();
                }
                _updateTreeComponents();
                break;
            case 'NavigationType':
                if ( data ) {
                    _navigationType = data.value;
                    if ( _svgParent && _svgParent.TifProperties ) {
                        _svgParent.TifProperties.item.navigationType = _navigationType;
                    }
                    if ( _selectedNodePath ) {
                        node = _getNodeDataByPath( _selectedNodePath );
                        if ( node ) {
                            if ( _navigationType === CPM.Enums.NavigationType.Dynamic ) {
                                WebCC.Properties.NavigationType = CPM.Enums.NavigationType.Dynamic;
                                if ( !node.IsLeaf ) {
                                    _navigatedNodeId = node.Id;
                                    node.isNodeNavigated = true;
                                    _loadData( node, false );
                                }
                            } else {
                                WebCC.Properties.NavigationType = CPM.Enums.NavigationType.Static;
                                _setBeforeTraverse();
                                _setForUpdate();
                            }
                        }
                    }
                }
                break;
            case 'Companions':
                _setScreenCompanions();
                break;
            default:
                break;
        }
    };
    /*
    * Function to handle style change
    * @function
    * @memberOf CPM.App
    */
    this.handleStyleChange = function ( currentStyle ) {
        _isExtendedStyle = currentStyle.includes( CPM.Enums.StyleName.Extended ) ? true : false;
        _data.currentStyle = currentStyle;
        _data.stylePropObj = CPM.StyleFactory.getCurrentStyleProps( currentStyle );
        _updateToolBarStyles( currentStyle );
        _updateBCStyle();
        if ( _isScrollbarCreated ) {
            _createVerticalScrollBar();
        }
        if ( _isHorizontalScrollbarCreated ) {
            _createHorizontalScrollBar();
        }
        _data.ForeColor = _data.stylePropObj.Control.ForeColor;
        _data.white = _data.stylePropObj.Control.EvenBackColor;
        _data.grey3 = _data.stylePropObj.Control.OddBackColor;
        _data.HorizLineColor = _data.stylePropObj.Control.HorizLineColor;
        _data.AlarmSeperatorLineColor = _data.stylePropObj.Control.AlarmSeperatorLineColor;
        _data.NodeIconColor = _data.stylePropObj.Control.NodeIconColor;
        _data.SelectionNodeIconColor = _data.stylePropObj.Control.SelectionNodeIconColor;
        _data.ExpCollIconColor = _data.stylePropObj.Control.ExpCollIconColor;
        _data.SelectionBackColor = _selectionBackColUpdated ? _data.SelectionBackColor : _data.stylePropObj.Control.SelectionBackColor;
        _data.SelectionForeColor = _selectionForeColUpdated ? _data.SelectionForeColor : _data.stylePropObj.Control.SelectionForeColor;
        _nodeHandler.updateNodeStyle( _data, _isAlarmsPresent );
        _searchBox.updateStyle( _data.stylePropObj, _isExtendedStyle, currentStyle );
        _updateSearchComboBoxStyle();
        _updateComboBoxStyle();
    };
};

var CPM = ( CPM || {} );
CPM.Tree = function () {
    /**
    * Private members.
    */
    var
    /**    
    * @memberOf TreeControl
    * Holds reference to app
    */
    _app = null,
    /**
    * function to create tree control on DOM
    */
    _createTree = function ( options ) {
        _app = new CPM.App();
        _app.createTreeControl( options );
    },
    /**
    * function to expand all nodes
    */
    _expand = function () {
        _app.expandAll();
    },
    /**
    * function to collapse all nodes
    */
    _collapse = function () {
        _app.collapseAll();
    },
    /**
    * function to create new node
    * @param {nodeData} object
    */
    _createNewNode = function ( nodeData ) {
        _app.createNewNode( nodeData );
    },
    /**
    *  function to create Hierarchy node
    * @param {nodeData} object
    */
    _createHierarchyNode = function ( nodeData ) {
        _app.createHierarchyNode( nodeData );
    },
    /**
    * function to add multiple nodes
    * @param {data} object
    */
        _loadNodes = function ( data, errorVal ) {
            _app.loadNodes( data, errorVal );
    },
    /**
    * function to add multiple nodes
    * @param {data} object
    */
    _addNewNodes = function ( data, isBufferData ) {
        _app.addNewNodes( data, isBufferData );
    },
    /**
    * function to remove selected node
    */
    _removeNode = function ( nodeName ) {
        _app.removeNode( nodeName );
    },
    /**
    * function will set callback function that to be called from controller on occuring of event on DOM
    * @param {name} string
    * @param {func} callback
    */
    _on = function ( func ) {
        _app.setCallback( func );
    },
    /**
    * function to update view on resize
    * return bool
    */
    _updateView = function ( height, width ) {
        _app.updateView( height, width );
    },
    /**
    * function to load breadcrumb
     * @param {node} object
    */
    _loadBreadCrumb = function ( node ) {
        _app.loadBreadCrumb( node );
    },
    _handleAlarmData = function ( data ) {
        _app.handleAlarmData( data );
    },
    _handleScreenData = function ( data ) {
        _app.handleScreenData( data );
    },
    _handleLanguageChange = function ( data ) {
        _app.handleLanguageChange( data );
    },
    _disableToolbarButtons = function () {
        _app.disableToolbarButtons();
    },
    _updateProperties = function ( data ) {
        _app.updateProperties( data );
    },
    _handleStyleChange = function ( currentStyle ) {
        _app.handleStyleChange( currentStyle );
    },
    _getEventHandlers = function () {
       return _app.getEventHandlers();
    };

    return {
        createTree: _createTree,
        createHierarchyNode: _createHierarchyNode,
        expand: _expand,
        collapse: _collapse,
        createNewNode: _createNewNode,
        loadNodes: _loadNodes,
        removeNode: _removeNode,
        on: _on,
        updateView: _updateView,
        addNewNodes: _addNewNodes,
        loadBreadCrumb: _loadBreadCrumb,
        updateProperties: _updateProperties,
        handleAlarmData: _handleAlarmData,
        handleScreenData: _handleScreenData,
        handleLanguageChange: _handleLanguageChange,
        disableToolbarButtons: _disableToolbarButtons,
        handleStyleChange: _handleStyleChange,
        getEventHandlers: _getEventHandlers
    };
};
var CPM = ( CPM || {} );
CPM.TreeImplementor = (function () {
    /**
    * Private members.
    */
    var
        /**
        * @memberOf CPM.TreeImplementor
        * Hold reference to tree control
        */
        _tree = null,
        /**
        * @memberOf CPM.TreeImplementor
        * Holds information about offset width
        */
        _offsetWidth = 0,
        /**
        * @memberOf CPM.TreeImplementor
        * Holds information about offset width
        */
        _offsetHeight = 2,
        /**
        * @memberOf CPM.TreeImplementor
        * Holds information about container and directory
        */
        _options = { rootDir: '', svgParent: null, domParent: null, zoom: 0, width: 0, height: 0 },


        // HostListener methods
        /**
        * HostListener function to expand all nodes
        */
        _expand = function () {
            if (_tree != null) {
                _tree.expand();
                return 'expanded';
            }
        },
        /**
        * HostListener function to collapse all nodes
        */
        _collapse = function () {
            if (_tree != null) {
                _tree.collapse();
                return 'collapsed';
            }
        },
        /**
        * HostListener function to create Hierarchy node
        * @param {data} object
        */
        _createHierarchyNode = function (data) {
            var nodeData = {};
            if (data.DisplayNameArray instanceof Array && data.ViewNodeIdArray instanceof Array) {
                nodeData.Name = data.DisplayNameArray[0];
                nodeData.Id = data.ViewNodeIdArray[0];
                _tree.createHierarchyNode(nodeData);
            }
        },
        /**
        * HostListener function to add multiple nodes
        * @param {data} object
        */
        _loadNodes = function ( data, errorVal ) {
            //var st = Date.now();
            _tree.loadNodes( data, errorVal );
        },

        _addNewNodes = function (data, isBreadCrumbReq, isBufferData) {
            if (isBreadCrumbReq) {
                _tree.loadBreadCrumb(data);
            } else {
                _tree.addNewNodes(data, isBufferData);
            }

        },
        /**
        * HostListener function to add node
        * @param {name} string
        * @param {id} string
        * @param {objectType} string
        * @param {isExpanded} bool
        * @param {isLeaf} bool
        * @param {visible} bool
        */
        _addNewNode = function (name, id, objectType) {
            var node = {
                Name: name,
                Id: id,
                ObjectType: objectType,
                //IsExpanded: isExpanded,
                //IsLeaf: isLeaf,
                //Visible: visible,
                //Children: [],
                Parent: WebCC.Properties.SelectedNode
            };
            _tree.loadNodes([node]);
            return name + ' added suceessfully';
        },
        /**
        * HostListener function to remove selected node
        */
        _removeNode = function () {
            var name = WebCC.Properties.SelectedNode;
            _tree.removeNode(name);
            return name + ' removed suceessfully';
        },
        /**
        * Callback to be called from controller on property change
        */
        _propertyChangeCallback = function (args) {
            var paramIds,
                paramValues,
                mode;

            WebCC.Properties.SelectedNode = args.name;
            if (args.isRequestData) {
                if ( args.isHierarchyNode) {
                    mode = CPM.Enums.BrowsingMode.ViewRoot;
                }
                else {
                    mode = CPM.Enums.BrowsingMode.ViewNode;
                }
                paramIds = [CPM.Enums.ObjectCountAttributes.Requested, CPM.Enums.ObjectCountAttributes.TreeOrList, CPM.Enums.ObjectCountAttributes.SystemId, CPM.Enums.ObjectCountAttributes.ObjectId, CPM.Enums.ObjectCountAttributes.SelectedNode, CPM.Enums.ObjectCountAttributes.NameFilter,
                CPM.Enums.ObjectCountAttributes.PropertyFilter, CPM.Enums.ObjectCountAttributes.LanguageId, CPM.Enums.ObjectCountAttributes.BrowsingMode, CPM.Enums.ObjectCountAttributes.SortingMode, CPM.Enums.ObjectCountAttributes.SortByAttribute];
                paramValues = [1, CPM.Enums.View.Tree, 0, undefined, args.id, undefined, undefined, CPM.Enums.Language.English, mode, undefined]; //4 == VIEWROOT
                WebCC.Extensions.HMI.DomainLogic.sendDLEvent(paramIds, paramValues);
            }

        },
        /**
        * function to get iframe width
        * return {height}int
        */
        _getWidth = function () {
            var width = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
            return width;
        },
        /**
        * function to get iframe height
        * return {height}int
        */
        _getHeight = function () {
            var height = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;
            return height;
        },
        /**
        * function to register as a callback. fires on resizing window
        */
        _doResize = function () {
            var width = _getWidth(),
                height = _getHeight();
            _tree.updateView(height - _offsetHeight, width - _offsetWidth);
        },
        // Local methods
        /**
        * function to initialize tree control
        */
        _initialize = function () {
            var iframeElem, iframeElemArray = [], elem, cpmDiv = [];
            if (_tree === null) {
                iframeElemArray = window.parent.document.getElementsByTagName('iFrame');
                try {
                    for (elem in iframeElemArray) {
                        if ( iframeElemArray.hasOwnProperty( elem ) ) {
                            iframeElem = iframeElemArray[elem];
                            //Exception in iPad handled, to avoid firing of resize event for iframe's scrollbar
                            iframeElem.setAttribute('scrolling', 'no');
                            if (iframeElem.contentDocument) {
                                cpmDiv = iframeElem.contentDocument.getElementsByClassName('cpmDiv')[0];
                                if (cpmDiv) {
                                    iframeElem.style.position = '';
                                }
                            }
                        }
                    }
                }
                catch (exec) {
                    //Swac exception only in IE.
                }
                _options.svgParent = document.getElementById('Main_SVG');
                _options.domParent = document.getElementById('CPM_Main_Div');
                _options.divParent = document.getElementById('divParent');
                _options.width = _getWidth();
                _options.height = _getHeight() - _offsetHeight;
                _options.svgParent.setAttribute('width', (_options.width - _offsetWidth));
                _options.svgParent.setAttribute('height', (_options.height));
                _options.divParent.setAttribute('width', (_options.width + 4) + 'px');
                _options.divParent.setAttribute('height', (_options.height + 4) + 'px');
                _options.SelectionBackColor = WebCC.Properties.SelectionBackColor;
                _options.SelectionForeColor = WebCC.Properties.SelectionForeColor;
                _options.SelectedNodePath = WebCC.Properties.SelectedNode;
                _options.NavigationType = WebCC.Properties.NavigationType;
                _options.Companions = WebCC.Properties.Companions;
                _options.Filter = WebCC.Properties.Filter;
                _options.rtoId = WebCC._internal.containerInfo.name;
                _options.Enabled = WebCC.Extensions.HMI.Properties.Enabled;
                _options.ShowBreadCrumb = WebCC.Properties.ShowBreadCrumb;
                _options.ShowToolBar = WebCC.Properties.ShowToolBar;
                _options.RootNode = WebCC.Properties.RootNode;
                _options.svgParent.setAttribute('data-rtoid', _options.rtoId);
                _tree = new CPM.Tree();
                _tree.createTree(_options);
                window.addEventListener('resize', _doResize);
                _tree.on(_propertyChangeCallback);
            }
        },
        _propChange = function (data) {
            _tree.updateProperties(data);
        },
        _handleAlarmData = function (data) {
            _tree.handleAlarmData(data);
        },
        _handleScreenData = function (data) {
            _tree.handleScreenData(data);
        },
        _disableToolbarButtons = function () {
            _tree.disableToolbarButtons();
        },
        _handleLanguageChange = function (data) {
            _tree.handleLanguageChange(data);
        },
        _handleStyleChange = function (currentStyle) {
            if (currentStyle) { //Work around added for now, if a particular style is set in ES, switching from other style to ES set style in prepending device name as eg. HMI_RT_1::ExtendedStyle
                if (currentStyle.indexOf(':') !== -1) {
                    currentStyle = currentStyle.split('::')[1];
                }
                if (_tree !== null) {
                    _tree.handleStyleChange(currentStyle);
                }
                _options.currentStyle = currentStyle;
            }
        };

    return {
        Local: {
            Initialize: _initialize,
            createHierarchyNode: _createHierarchyNode,
            loadNodes: _loadNodes,
            addNewNodes: _addNewNodes,
            propChange: _propChange,
            HandleAlarmData: _handleAlarmData,
            HandleScreenData: _handleScreenData,
            HandleLanguageChange: _handleLanguageChange,
            DisableToolbarButtons: _disableToolbarButtons,
            HandleStyleChange: _handleStyleChange
        },
        HostListener: {
            //////////
            // API
            expand: _expand,
            collapse: _collapse,
            addNewNode: _addNewNode,
            removeNode: _removeNode,
            //////////
            // EVENTS ("Subscribable": an object with at least a subscribe-function, which accepts one argument)
            events: ['onSelectionChanged', 'onExpand', 'onExpandAll', 'onCollapse', 'onCollapseAll'],
            //////////
            properties: {
                RootNode: '',
                SelectedNode: '',
                SelectionBackColor: 0,
                SelectionForeColor: 0,
                Companions: [
                    //{
                    //    'ControlType': 'AlarmControl',
                    //    'ControlRef': 'AlarmControl',
                    //    CompanionConfig: {
                    //        ShowAlarmSummary: true,
                    //        AlarmClassFilter: 'AlarmClassName = \'CPMAlarm\''
                    //    }
                    //}
                ],
                Filter: 0,
                ShowToolBar: true,
                ShowBreadCrumb: true,
                NavigationType: 0
            }
        }
    };
}());

var initializeControl = function (result) {
    if (result) {
        try { //Added try catch block to avoid the control going complately blank.
            WebCC.Extensions.HMI.DomainLogic.onDLSendData.subscribe(function (value) {
                var typeReceived = value.data.id, paramIds, paramValues;
                switch (typeReceived) {
                    case CPM.Enums.DataRecievedType.SetViewPort:
                        paramIds = [0];
                        paramValues = [CPM.Enums.BrowsingMode.Hierarchies];
                        WebCC.Extensions.HMI.DomainLogic.sendDLEvent(paramIds, paramValues);
                        break;
                    case CPM.Enums.DataRecievedType.Hierarchies: //Heirarchies data
                        if (value.data.data.DisplayNameArray.length > 1) {
                            CPM.TreeImplementor.Local.createHierarchyNode(value.data.data);
                        }
                        else {
                            if (value.data.data.DisplayNameArray.length === 0) {//No tree configured. Disable the toolbar buttons in this case.
                                CPM.TreeImplementor.Local.DisableToolbarButtons();
                            }
                            paramIds = [CPM.Enums.ObjectCountAttributes.Requested, CPM.Enums.ObjectCountAttributes.TreeOrList, CPM.Enums.ObjectCountAttributes.SystemId, CPM.Enums.ObjectCountAttributes.ObjectId, CPM.Enums.ObjectCountAttributes.SelectedNode, CPM.Enums.ObjectCountAttributes.NameFilter,
                            CPM.Enums.ObjectCountAttributes.PropertyFilter, CPM.Enums.ObjectCountAttributes.LanguageId, CPM.Enums.ObjectCountAttributes.BrowsingMode, CPM.Enums.ObjectCountAttributes.SortingMode, CPM.Enums.ObjectCountAttributes.SortByAttribute];
                            paramValues = [1, CPM.Enums.View.Tree, 0, undefined, value.data.data.ItemIdArray[0], undefined, undefined, CPM.Enums.Language.English, CPM.Enums.BrowsingMode.ViewRoot, undefined]; //4 == VIEWROOT
                            WebCC.Extensions.HMI.DomainLogic.sendDLEvent(paramIds, paramValues);
                        }
                        break;
                    case CPM.Enums.DataRecievedType.RootOrNode: //ViewRoot or ViewNodes data
                    case CPM.Enums.DataRecievedType.ExpandAll:
                    case CPM.Enums.DataRecievedType.ExpandAllForNode:
                        if (value.data.data.DisplayData !== null) {
                            if (typeReceived === CPM.Enums.DataRecievedType.ExpandAllForNode) {
                                //Here we receive the selected node data also which is already loaded on UI. So we take only its children(available at index 6) and load them.
                                CPM.TreeImplementor.Local.loadNodes(value.data.data.DisplayData[0][6]);
                            } else {
                                CPM.TreeImplementor.Local.loadNodes(value.data.data.DisplayData);
                            }
                            CPM.TreeImplementor.Local.propChange({ key: 'Companions', value: WebCC.Properties.Companions });
                            CPM.TreeImplementor.Local.propChange({ key: 'SelectionBackColor', value: WebCC.Properties.SelectionBackColor });
                            CPM.TreeImplementor.Local.propChange({ key: 'SelectedNode', value: WebCC.Properties.SelectedNode });
                            CPM.TreeImplementor.Local.propChange({ key: 'SelectionForeColor', value: WebCC.Properties.SelectionForeColor });
                        }
                        else {
                            CPM.TreeImplementor.Local.loadNodes( value.data.data.DisplayData, value.data.data.Error );
                        }
                        break;
                    case CPM.Enums.DataRecievedType.Scroll:
                        if (value.data.data.DisplayData !== null) {
                            CPM.TreeImplementor.Local.addNewNodes(value.data.data, false, true);
                        }
                        break;
                    case CPM.Enums.DataRecievedType.NodeCount: //Object Count
                        paramIds = [CPM.Enums.DataAttributes.Requested, CPM.Enums.DataAttributes.TreeOrList, CPM.Enums.DataAttributes.StartIndex, CPM.Enums.DataAttributes.EndIndex];
                        paramValues = [8, CPM.Enums.View.List, 0, value.data.data.ObjectCount];
                        WebCC.Extensions.HMI.DomainLogic.sendDLEvent(paramIds, paramValues);
                        break;
                    case CPM.Enums.DataRecievedType.BreadCrumbData: //ViewRoot or ViewNodes data
                        if (value.data.data.DisplayData !== null) {
                            CPM.TreeImplementor.Local.addNewNodes(value.data.data.DisplayData, true);
                        }
                        break;
                    case CPM.Enums.DataRecievedType.AlarmSummary:
                        if (value.data.data !== null) {
                            CPM.TreeImplementor.Local.HandleAlarmData(value.data.data);
                        }
                        break;
                    case CPM.Enums.DataRecievedType.ScreenWindowNode:
                        if (value.data.data && value.data.data.ScreenFilter !== null) {
                            CPM.TreeImplementor.Local.HandleScreenData(value.data.data);
                        }
                        break;
                    case CPM.Enums.DataRecievedType.LanguageChange:
                        if (value.data.data && value.data.data.LanguageId !== null) {
                            CPM.TreeImplementor.Local.HandleLanguageChange(value.data.data.LanguageId);
                        }
                        break;
                    default:
                        break;
                }
            });

            WebCC.onPropertyChanged.subscribe( CPM.TreeImplementor.Local.propChange);
            WebCC.Extensions.HMI.Properties.onPropertyChanged.subscribe( CPM.TreeImplementor.Local.propChange);
            CPM.TreeImplementor.Local.HandleStyleChange(WebCC.Extensions.HMI.Style.Name);
            WebCC.Extensions.HMI.Style.onChanged.subscribe( CPM.TreeImplementor.Local.HandleStyleChange);
            //First time ask for all Hierarchies
            var paramIds, paramValues;


            paramIds = [0];
            paramValues = [14];
            WebCC.Extensions.HMI.DomainLogic.sendDLEvent(paramIds, paramValues);

            CPM.TreeImplementor.Local.Initialize();
        }
        catch (error) {
           // console.log(error);
        }
    }
};
// Lifecycle
/**
* WebCC initialization. onsucess,control will initialize.
*/
WebCC.start(
    initializeControl,
    CPM.TreeImplementor.HostListener,
    ['HMI', 'X_Textbib', 'X_SiemensFont'],
    // timeout
    10000
);